-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_omdpclkhxujtokyltezemwaaaudjukecsslb` (`primaryOwnerId`),
  CONSTRAINT `fk_aoyjmxfejdlqqvlduabxltutlqrdosvneuoe` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_omdpclkhxujtokyltezemwaaaudjukecsslb` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rkbzlqrxtvqgcdjpmzoorujfqqjdmuysvqoz` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_kwjvjgzmcciktqkakzbgwnqydqiimvayacld` (`dateRead`),
  KEY `fk_ndhovomaytzwpnsdjygflffofmtryszawdgx` (`pluginId`),
  CONSTRAINT `fk_gvlywafhnkhbvwhsdstswsxzfiypbbuctcuz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ndhovomaytzwpnsdjygflffofmtryszawdgx` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jmeovdooejhygmxamkylatqfjomhegwjupjk` (`sessionId`,`volumeId`),
  KEY `idx_efxwxfjexehxtendxrrypslncqhqxypjzhkk` (`volumeId`),
  CONSTRAINT `fk_hwbmvyssbrwafvcpffnvfglkxcgybhjthepu` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pngzsbjoddryzncipmlrlhqjqksdceondgss` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rpntmhxphjhmpvxdilwennzxasruvvwiumnj` (`filename`,`folderId`),
  KEY `idx_lwttguqrrzsqgkguamwpkarazbqbdogvobbg` (`folderId`),
  KEY `idx_egiijdympejndwpggtrvvvyuxqafunlscbfd` (`volumeId`),
  KEY `fk_shgbqkrphwkuelcwijxffbzgsvecydihqzbw` (`uploaderId`),
  CONSTRAINT `fk_nlsnhsjnlqaigfpzieuqdimamlkpfprydalr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_shgbqkrphwkuelcwijxffbzgsvecydihqzbw` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vbmpldbhkjnyhodgvthmwjeftxzuioftzieg` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vpzbzagcpexwniihkvmtghwtcyxewtpgxogc` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_rcshrywzbbrnjduvfbtdcjmihlokubqbpcbi` (`siteId`),
  CONSTRAINT `fk_mkotzpzvrvpmvwmgicjiinbgueoppsimxkye` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rcshrywzbbrnjduvfbtdcjmihlokubqbpcbi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_taqgczrtilkxplblkggcgihpkjhtutxndjfn` (`userId`),
  CONSTRAINT `fk_taqgczrtilkxplblkggcgihpkjhtutxndjfn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_avfsornskxcnxqehtimbzmtgbgzvfoqdawco` (`groupId`),
  KEY `fk_sivmwhgfigkepikytjmeizmcscpoktkdimeu` (`parentId`),
  CONSTRAINT `fk_djbvelvoywmcjqauuoxclxqqlniujkutidix` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jitdndwfvpybhxmzzxktsazdcujlyxyalwqi` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sivmwhgfigkepikytjmeizmcscpoktkdimeu` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zpouckasytgxsjrjspvpehzzsdslippoaaxo` (`name`),
  KEY `idx_dngpefthbcqfkxizcsgpddobgleaxuoehbmx` (`handle`),
  KEY `idx_twnhmjdvglcjhzjlnhexjhsuqqesbvyfximl` (`structureId`),
  KEY `idx_ikjzmquxfiqarejkfaykgjhzjtszbyzjbfht` (`fieldLayoutId`),
  KEY `idx_kmezayxznskrbxidtmroftdkauiytrlzbshl` (`dateDeleted`),
  CONSTRAINT `fk_sfkeiixymqjpjuzkcueytsspitlghsyrfzyj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zrtopvstaponvsptoywrsafxbkkcurbitxdi` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_brvgrdcvgupijuekxgiudvbwpsfgmmwrrxpb` (`groupId`,`siteId`),
  KEY `idx_swjnhmfkulzbqvqftlzxbtwqysgkexwgykqi` (`siteId`),
  CONSTRAINT `fk_dywpxmtqftgbxrwygveczowyxtxsxhlujcdr` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eghhuamiamchlnfoabslvglnmteefwetzhzh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_josmllmygrnikjbnerortxvdczrpmxahhfhh` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_dujdbpfxeafhcboyxtuoibypcbmczukjahrl` (`siteId`),
  KEY `fk_fxbmepsjrogbcyvjwyckflodyaknfxotyqet` (`userId`),
  CONSTRAINT `fk_dujdbpfxeafhcboyxtuoibypcbmczukjahrl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fxbmepsjrogbcyvjwyckflodyaknfxotyqet` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_mgzvbqmuirwduxohfwjagzhklrgtdypwuxbt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_nsmyzmrplwgilbkeaesdrgxulbkbmxxrrfam` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_alrozyknkrqjhirvbnapwyfnawnrnuucntge` (`siteId`),
  KEY `fk_kprqawvzlclrhiywfgxtxqqkulowqdzcobvk` (`fieldId`),
  KEY `fk_xcnfcgxiofzdxghmkmljhkohufkwvapruiiu` (`userId`),
  CONSTRAINT `fk_alrozyknkrqjhirvbnapwyfnawnrnuucntge` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kprqawvzlclrhiywfgxtxqqkulowqdzcobvk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nkkketheggipgpuspuagvqklcfoluqwaprck` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xcnfcgxiofzdxghmkmljhkohufkwvapruiiu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_catalogpricing`
--

DROP TABLE IF EXISTS `commerce_catalogpricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_catalogpricing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` decimal(14,4) DEFAULT NULL,
  `purchasableId` int NOT NULL,
  `storeId` int DEFAULT NULL,
  `catalogPricingRuleId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `isPromotionalPrice` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `hasUpdatePending` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kyfpfkvjuzeqgcndmfrscxtbizzsafqznfwx` (`purchasableId`),
  KEY `idx_dtzryfecvbwsktlgiwlrmbdofradhdlzlfsq` (`storeId`),
  KEY `idx_gnccwuurtuttncnzxalxsqzertvwpovjsuwl` (`catalogPricingRuleId`),
  KEY `idx_kdsakzgbpmusnhucwqcfqvxudhxdkcermkld` (`userId`),
  CONSTRAINT `fk_jyjuenxescfmohdgaqgjodkhsbpmphzqfbxj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_luwkekuwweahnfhtxtkgkcfvdeegwhtbcjhk` FOREIGN KEY (`catalogPricingRuleId`) REFERENCES `commerce_catalogpricingrules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sbfrdxbgohbrdxgkugornrfsoclhvlrfohtq` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zpqlybtzatexqirvuyfkqpvlsbcebhmolrka` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_catalogpricingrules`
--

DROP TABLE IF EXISTS `commerce_catalogpricingrules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_catalogpricingrules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `storeId` int NOT NULL,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `apply` enum('toPercent','toFlat','byPercent','byFlat') NOT NULL,
  `applyAmount` decimal(14,4) NOT NULL,
  `applyPriceType` enum('price','promotionalPrice') NOT NULL,
  `purchasableCondition` text,
  `customerCondition` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `isPromotionalPrice` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `metadata` text,
  PRIMARY KEY (`id`),
  KEY `idx_pccoicxrsfvgcnapsqtehazhawzfdfjzvfjg` (`storeId`),
  CONSTRAINT `fk_optuxqafrkdfpckxvyfubluhokchsmfqfabb` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_catalogpricingrules_users`
--

DROP TABLE IF EXISTS `commerce_catalogpricingrules_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_catalogpricingrules_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catalogPricingRuleId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xyfgjbfklpmhgsgjdywbtuiiqfctngwczxmx` (`catalogPricingRuleId`),
  KEY `idx_yzbqrociqkpfumofspahjpjqjabdsdtqnisv` (`userId`),
  CONSTRAINT `fk_ceatngmydbmbkgbtfzkscfoeclbxmqxajovy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_joxmelbshsvjaygtlxipifbsfkvkgayuzbsz` FOREIGN KEY (`catalogPricingRuleId`) REFERENCES `commerce_catalogpricingrules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_coupons`
--

DROP TABLE IF EXISTS `commerce_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_coupons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `discountId` int NOT NULL,
  `uses` int NOT NULL DEFAULT '0',
  `maxUses` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lravkcpeuaqphohdazljuqzntgnnmoivwkwr` (`discountId`),
  KEY `idx_ewunvgqneaxlttqusmlwuykpimbspvqxgbdw` (`code`),
  CONSTRAINT `fk_pfhsutcfrpvfddavkbdjrzcfvqchgiirjklf` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_customer_discountuses`
--

DROP TABLE IF EXISTS `commerce_customer_discountuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_customer_discountuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `customerId` int NOT NULL,
  `uses` int unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lwcrunncttqaiazklbgvhsmdinrqkuzfdlir` (`customerId`,`discountId`),
  KEY `idx_qrpcsecxbxqapsaknrkibszyxdodtynuttjq` (`discountId`),
  CONSTRAINT `fk_wasdtgippuzyxfxifaibwgsedhfyadpjczqb` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ywtucjsfloxirlohbwtsynivlngametblniv` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_customers`
--

DROP TABLE IF EXISTS `commerce_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customerId` int NOT NULL,
  `primaryBillingAddressId` int DEFAULT NULL,
  `primaryShippingAddressId` int DEFAULT NULL,
  `primaryPaymentSourceId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jfwqekoaskypalnxocouabeejmjwxihaoppe` (`customerId`),
  KEY `idx_pxprvawkhbpvfqrhmfabivvtfpuzcixmngck` (`primaryBillingAddressId`),
  KEY `idx_bszrsismjondigzwkjtuztfuvnpywckwaonh` (`primaryShippingAddressId`),
  KEY `idx_otaxdmiwnbvswpmnisyothnviksdsnpatuvj` (`primaryPaymentSourceId`),
  CONSTRAINT `fk_coqhbkapgrfwmqtnogmqzdafejcmzatztepg` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gwqbgzxxpmvzphduqklplioqlyxpneicjvmu` FOREIGN KEY (`primaryBillingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mhavjyeayxncngvhqvsivwezujuqvxnbumus` FOREIGN KEY (`primaryPaymentSourceId`) REFERENCES `commerce_paymentsources` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vxzpxiiqbbakraslwtlycrfejwtkwwpyttbo` FOREIGN KEY (`primaryShippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_discount_categories`
--

DROP TABLE IF EXISTS `commerce_discount_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_discount_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `categoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_upwtsotizzrvhukawmvauwqyhtcoudcmfzsu` (`discountId`,`categoryId`),
  KEY `idx_lzfuotfertylmyuqjlzgndtoufumxmojysxc` (`categoryId`),
  CONSTRAINT `fk_lyjpidkdzjkdhcuhwmkizfchqfcqgmcvbwlz` FOREIGN KEY (`categoryId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zrripzecwfkgilfjwahcadxblsxfcwoirzck` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_discount_purchasables`
--

DROP TABLE IF EXISTS `commerce_discount_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_discount_purchasables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `purchasableId` int NOT NULL,
  `purchasableType` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_btcdczdlbhgswvqqnfuiamnkrktbbteaekgb` (`discountId`,`purchasableId`),
  KEY `idx_khfqbfuosprskxgjxjyiwsjmtimgyhpyjcom` (`purchasableId`),
  CONSTRAINT `fk_blgopknbnygqguistqiwmevmthtpxifajhqo` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nexntbjyixeuszlkuzojgqsrdzzvqghoskpo` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_discounts`
--

DROP TABLE IF EXISTS `commerce_discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_discounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL,
  `description` text,
  `couponFormat` varchar(20) NOT NULL DEFAULT '######',
  `orderCondition` text,
  `customerCondition` text,
  `shippingAddressCondition` text,
  `billingAddressCondition` text,
  `perUserLimit` int unsigned NOT NULL DEFAULT '0',
  `perEmailLimit` int unsigned NOT NULL DEFAULT '0',
  `totalDiscountUses` int unsigned NOT NULL DEFAULT '0',
  `totalDiscountUseLimit` int unsigned NOT NULL DEFAULT '0',
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `purchaseQty` int NOT NULL DEFAULT '0',
  `purchaseTotal` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `maxPurchaseQty` int NOT NULL DEFAULT '0',
  `baseDiscount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `perItemDiscount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `percentDiscount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `percentageOffSubject` enum('original','discounted') NOT NULL,
  `excludeOnPromotion` tinyint(1) NOT NULL DEFAULT '0',
  `hasFreeShippingForMatchingItems` tinyint(1) NOT NULL DEFAULT '0',
  `hasFreeShippingForOrder` tinyint(1) NOT NULL DEFAULT '0',
  `allPurchasables` tinyint(1) NOT NULL DEFAULT '0',
  `purchasableIds` text,
  `allCategories` tinyint(1) NOT NULL DEFAULT '0',
  `categoryIds` text,
  `appliedTo` enum('matchingLineItems','allLineItems') NOT NULL DEFAULT 'matchingLineItems',
  `categoryRelationshipType` enum('element','sourceElement','targetElement') NOT NULL DEFAULT 'element',
  `orderConditionFormula` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `stopProcessing` tinyint(1) NOT NULL DEFAULT '0',
  `ignorePromotions` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_svckyduorfjoendvhunstekfpemaiwjkxnxf` (`dateFrom`),
  KEY `idx_mpeckahrihxkqewjhhvxxduhjotesgujtuhs` (`dateTo`),
  KEY `idx_aigejefdpvhscxmxumtcnpjfzfnhfywnrxdn` (`storeId`),
  CONSTRAINT `fk_fcdnyiiuulorighmvsbiqazuuehnlnyjjdkg` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_donations`
--

DROP TABLE IF EXISTS `commerce_donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_donations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_oyismnmpokfmjmpfvlqussedxwhdvrlwlbkg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_email_discountuses`
--

DROP TABLE IF EXISTS `commerce_email_discountuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_email_discountuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `email` varchar(255) NOT NULL,
  `uses` int unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_szqgvpxaidjbbvitgavmywmjfniyypbfvqvv` (`email`,`discountId`),
  KEY `idx_ffumxyxumyfndswqryxppfmaitcmmpxseexa` (`discountId`),
  CONSTRAINT `fk_ihyqszdpbmhjgsztoonxouftftjwkkyembyn` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_emails`
--

DROP TABLE IF EXISTS `commerce_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `senderAddress` varchar(255) DEFAULT NULL,
  `senderName` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `recipientType` enum('customer','custom') DEFAULT 'custom',
  `to` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `replyTo` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `templatePath` varchar(255) NOT NULL,
  `plainTextTemplatePath` varchar(255) DEFAULT NULL,
  `pdfId` int DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ehczxpwmwpflhsucqkilhczkqouqyhihdchl` (`pdfId`),
  KEY `idx_nfmftswwtimutbtwzwmiuwolsenazfgyisfa` (`storeId`),
  CONSTRAINT `fk_ehczxpwmwpflhsucqkilhczkqouqyhihdchl` FOREIGN KEY (`pdfId`) REFERENCES `commerce_pdfs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gecqcneljneeqlqzpzxgipjrfbdxyxvecjyu` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_gateways`
--

DROP TABLE IF EXISTS `commerce_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_gateways` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `settings` text,
  `paymentType` enum('authorize','purchase') NOT NULL DEFAULT 'purchase',
  `isFrontendEnabled` varchar(500) NOT NULL DEFAULT '1',
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hvmthncrykbysokdfcnddsphxrpacmxgyrxe` (`handle`),
  KEY `idx_wfsoqpsxmxnatnvmzitwepbfcuszxzatpqcb` (`isArchived`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_inventoryitems`
--

DROP TABLE IF EXISTS `commerce_inventoryitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_inventoryitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchasableId` int NOT NULL,
  `countryCodeOfOrigin` varchar(255) DEFAULT NULL,
  `administrativeAreaCodeOfOrigin` varchar(255) DEFAULT NULL,
  `harmonizedSystemCode` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mpdyqykqxdtbyrsssmzdyfxpouztuxvevqmf` (`purchasableId`),
  CONSTRAINT `fk_qelapwsckombaubfkpmcihqebfsxzwsynqqn` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_inventorylocations`
--

DROP TABLE IF EXISTS `commerce_inventorylocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_inventorylocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `addressId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_iepuhmuheetcielkhurrphzjzbzpuccpdswe` (`addressId`),
  CONSTRAINT `fk_iepuhmuheetcielkhurrphzjzbzpuccpdswe` FOREIGN KEY (`addressId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_inventorylocations_stores`
--

DROP TABLE IF EXISTS `commerce_inventorylocations_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_inventorylocations_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventoryLocationId` int NOT NULL,
  `storeId` int NOT NULL,
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_lqvwhevbeggnpopvuzolygrhysdrurlfntmk` (`inventoryLocationId`),
  KEY `fk_rptdtbdmypoxgsqhidygkaijyxnvbohcfmng` (`storeId`),
  CONSTRAINT `fk_lqvwhevbeggnpopvuzolygrhysdrurlfntmk` FOREIGN KEY (`inventoryLocationId`) REFERENCES `commerce_inventorylocations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rptdtbdmypoxgsqhidygkaijyxnvbohcfmng` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_inventorytransactions`
--

DROP TABLE IF EXISTS `commerce_inventorytransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_inventorytransactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventoryLocationId` int NOT NULL,
  `inventoryItemId` int NOT NULL,
  `movementHash` varchar(255) NOT NULL,
  `quantity` int NOT NULL,
  `type` enum('available','reserved','damaged','safety','qualityControl','committed','fulfilled','incoming') NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `transferId` int DEFAULT NULL,
  `lineItemId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yolcpujafkghupcedzgnmvqmctwapwdnicip` (`inventoryItemId`),
  KEY `idx_bbuuikyandupolioyylbbajawztslfdpunta` (`transferId`),
  KEY `idx_xkqovtwhzcwfufgbalzofhdgzpugcsjvxpds` (`lineItemId`),
  KEY `idx_gsgyvfgsbdqsrgelynnqajbnzpyfozjcrrwv` (`userId`),
  KEY `fk_hvvdfsozwajazkqtxevllxrygkywkhwswkzx` (`inventoryLocationId`),
  CONSTRAINT `fk_hvvdfsozwajazkqtxevllxrygkywkhwswkzx` FOREIGN KEY (`inventoryLocationId`) REFERENCES `commerce_inventorylocations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iuutswhdfbilxzqyuwlcrgfqlwdabawppstu` FOREIGN KEY (`inventoryItemId`) REFERENCES `commerce_inventoryitems` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kjixcigsyfwspcypvysrhbzijazasvvjudyv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vtzxhubuvhhriydrkezgqivkxxnylmdpabak` FOREIGN KEY (`transferId`) REFERENCES `commerce_transfers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yddaxzpdcnmgzuljzufphxlnuufpihdabpvh` FOREIGN KEY (`lineItemId`) REFERENCES `commerce_lineitems` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_lineitems`
--

DROP TABLE IF EXISTS `commerce_lineitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_lineitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `purchasableId` int DEFAULT NULL,
  `taxCategoryId` int NOT NULL,
  `shippingCategoryId` int NOT NULL,
  `description` text,
  `options` text,
  `optionsSignature` varchar(255) NOT NULL,
  `price` decimal(14,4) unsigned NOT NULL,
  `promotionalPrice` decimal(14,4) unsigned DEFAULT NULL,
  `promotionalAmount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `salePrice` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `sku` varchar(255) DEFAULT NULL,
  `weight` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `height` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `length` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `width` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `subtotal` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `total` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `qty` int unsigned NOT NULL,
  `note` text,
  `privateNote` text,
  `snapshot` longtext,
  `lineItemStatusId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_khzwmduiiipzvqucldtouqfalocmrriusrop` (`orderId`,`purchasableId`,`optionsSignature`),
  KEY `idx_rmusnugypgqltsxpvqajscbatfufgmbixhnw` (`purchasableId`),
  KEY `idx_lfwonzfiouexwjpaskesoiyheqdkbixojkcn` (`taxCategoryId`),
  KEY `idx_xcvnaomnbvtrdpjcduysvdihvhfqkfhxeikk` (`shippingCategoryId`),
  CONSTRAINT `fk_iwnnhyyvxhvaeckbbavpyzwjkswialepuoph` FOREIGN KEY (`purchasableId`) REFERENCES `elements` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_xcmbchdccvyyivpylgswhnykzokswwazmyku` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_xmnemnfehqpgneffnlawwwvcrpatjetyxwcm` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zycxtvolacauypyrgbnkzriigkccczspdqjg` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_lineitemstatuses`
--

DROP TABLE IF EXISTS `commerce_lineitemstatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_lineitemstatuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hfunpzlfyujcsludabwycupwljqirbqnufeg` (`storeId`),
  CONSTRAINT `fk_ristrbaksorlkhuejlnqxetsttnxvvzblmxh` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderadjustments`
--

DROP TABLE IF EXISTS `commerce_orderadjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderadjustments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `lineItemId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(14,4) NOT NULL,
  `included` tinyint(1) NOT NULL DEFAULT '0',
  `isEstimated` tinyint(1) NOT NULL DEFAULT '0',
  `sourceSnapshot` longtext,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mndugowlugnblhiccrtflemskrzxeskutulq` (`orderId`),
  CONSTRAINT `fk_vbtksblbzrfoygmdlcqgyqgtvwqgelokkzio` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderhistories`
--

DROP TABLE IF EXISTS `commerce_orderhistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderhistories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `userId` int DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `prevStatusId` int DEFAULT NULL,
  `newStatusId` int DEFAULT NULL,
  `message` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtkqoqmnukqzkrgwmdzdcpzlfihokbodbxrw` (`orderId`),
  KEY `idx_iiejqexoigoaxedwaxrcthdrqznqiphnxgcx` (`prevStatusId`),
  KEY `idx_ngrjpoqjcyaiifcnfhncelaickkypgrwvnmy` (`newStatusId`),
  KEY `idx_ygsdtfyxcjueaevfqvmpkvxrjnpzjpyhczyc` (`userId`),
  CONSTRAINT `fk_gleepsoaebqcbrqokfinedodzumkzkmfldax` FOREIGN KEY (`userId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ktggvansquvymxzbmgubwxuijjzjrewqdvro` FOREIGN KEY (`prevStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_ltzndrhgnaskqvcpjoryqmehhikdrhgxigig` FOREIGN KEY (`newStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_pioojewufkzvkdccicldkjlzrbegoakwcaer` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_ordernotices`
--

DROP TABLE IF EXISTS `commerce_ordernotices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_ordernotices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `message` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mzqqogxsdsmzjviqyyvqwnnwezzavlzfuttf` (`orderId`),
  CONSTRAINT `fk_hylvpstzukvomnxmwiwvcpihxolsnetfoqca` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orders`
--

DROP TABLE IF EXISTS `commerce_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orders` (
  `id` int NOT NULL,
  `storeId` int NOT NULL DEFAULT '1',
  `billingAddressId` int DEFAULT NULL,
  `shippingAddressId` int DEFAULT NULL,
  `estimatedBillingAddressId` int DEFAULT NULL,
  `estimatedShippingAddressId` int DEFAULT NULL,
  `sourceShippingAddressId` int DEFAULT NULL,
  `sourceBillingAddressId` int DEFAULT NULL,
  `gatewayId` int DEFAULT NULL,
  `paymentSourceId` int DEFAULT NULL,
  `customerId` int DEFAULT NULL,
  `orderStatusId` int DEFAULT NULL,
  `number` varchar(32) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `couponCode` varchar(255) DEFAULT NULL,
  `itemTotal` decimal(14,4) DEFAULT '0.0000',
  `itemSubtotal` decimal(14,4) DEFAULT '0.0000',
  `totalQty` int unsigned DEFAULT NULL,
  `total` decimal(14,4) DEFAULT '0.0000',
  `totalPrice` decimal(14,4) DEFAULT '0.0000',
  `totalPaid` decimal(14,4) DEFAULT '0.0000',
  `totalDiscount` decimal(14,4) DEFAULT '0.0000',
  `totalTax` decimal(14,4) DEFAULT '0.0000',
  `totalTaxIncluded` decimal(14,4) DEFAULT '0.0000',
  `totalShippingCost` decimal(14,4) DEFAULT '0.0000',
  `paidStatus` enum('paid','partial','unpaid','overPaid') DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `orderCompletedEmail` varchar(255) DEFAULT NULL,
  `isCompleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateOrdered` datetime DEFAULT NULL,
  `datePaid` datetime DEFAULT NULL,
  `dateAuthorized` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `paymentCurrency` varchar(255) DEFAULT NULL,
  `lastIp` varchar(255) DEFAULT NULL,
  `orderLanguage` varchar(12) NOT NULL,
  `origin` enum('web','cp','remote') NOT NULL DEFAULT 'web',
  `message` text,
  `registerUserOnOrderComplete` tinyint(1) NOT NULL DEFAULT '0',
  `saveBillingAddressOnOrderComplete` tinyint(1) NOT NULL DEFAULT '0',
  `saveShippingAddressOnOrderComplete` tinyint(1) NOT NULL DEFAULT '0',
  `recalculationMode` enum('all','none','adjustmentsOnly') NOT NULL DEFAULT 'all',
  `returnUrl` text,
  `cancelUrl` text,
  `shippingMethodHandle` varchar(255) NOT NULL DEFAULT '',
  `shippingMethodName` varchar(255) NOT NULL DEFAULT '',
  `orderSiteId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `totalWeight` decimal(14,4) unsigned DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mhuzkqmzdeecsyvucvtvzdmqwtsukagprvvx` (`number`),
  KEY `idx_qxyslfoswwyxlpxhetoxwlvnvvpciseqhoqo` (`reference`),
  KEY `idx_thrwhroavjbxugifyasrbqojxbctihckgevy` (`billingAddressId`),
  KEY `idx_rtsukunqenulunbwoqwrnhvivkiywoooodvj` (`shippingAddressId`),
  KEY `idx_ckvwvxbzidpmyihmvtbuixxvczdsfctrlamb` (`estimatedBillingAddressId`),
  KEY `idx_ulevwzgpptybwkskfftboiflpudnzqgxpulq` (`estimatedShippingAddressId`),
  KEY `idx_gynssuoorrrarwddnpcawaqywdidadhgrxoo` (`sourceBillingAddressId`),
  KEY `idx_xuttsvkyhzowcufhetighmqxbncgfztjxwxv` (`sourceShippingAddressId`),
  KEY `idx_vspdejfmcuqfhboumctzqaxzcrvkdapuryhr` (`gatewayId`),
  KEY `idx_wijlypfapxbyijdvxldkxswxvlohwvutrauv` (`customerId`),
  KEY `idx_uaotcrxiaeedaunkarcglvsrzoosxqgvcdqx` (`orderStatusId`),
  KEY `idx_xqppaeabjnbccnszuqxqdjtttyvjantatwkt` (`email`),
  KEY `fk_xpzsbdceiwslzpyabeduphdubhwvdhrqymjc` (`paymentSourceId`),
  KEY `idx_zaovlmoktsnmxjqoidpywtpwquhaqcizwcmk` (`storeId`),
  CONSTRAINT `fk_ekshyzqzzejkdndmgmmpzskvzqvztiejtxqy` FOREIGN KEY (`shippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hsnrduoekmlpqkyqjaqsmrtuotisumybsuvv` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pijbjlwojzatfywkdazbfkzzkiierllvicmn` FOREIGN KEY (`orderStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_rktafvsdnnaeskyluehzgbhhsxozyalfkxbh` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rpyebniyxzwgtisktokczvrtdytnftzudlwe` FOREIGN KEY (`estimatedBillingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tntchralpdrjaqjghvjlfpimdlvhpduxwkhl` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wduqzlwadzhdmzatltrpmopczdxcempbyhom` FOREIGN KEY (`billingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xdvckcrlcpgovrvzyeqesaawpdzteqlgmyee` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xpzsbdceiwslzpyabeduphdubhwvdhrqymjc` FOREIGN KEY (`paymentSourceId`) REFERENCES `commerce_paymentsources` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ycnlqnnqmwenglagtzijbnxayxavtyhvfpsj` FOREIGN KEY (`estimatedShippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderstatus_emails`
--

DROP TABLE IF EXISTS `commerce_orderstatus_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderstatus_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderStatusId` int NOT NULL,
  `emailId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_radsjjxahvrzjyytpxjylzaaduonlyaulgey` (`orderStatusId`),
  KEY `idx_jladdtykfqekxvwrhmfakkrmpodrksflboda` (`emailId`),
  CONSTRAINT `fk_bctxbtorlzhjlfhgyqdimmvfrvnqqlrmvart` FOREIGN KEY (`emailId`) REFERENCES `commerce_emails` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cclwtdynqlyihzkqebqesyvbyegcesrjfnfr` FOREIGN KEY (`orderStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderstatuses`
--

DROP TABLE IF EXISTS `commerce_orderstatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderstatuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `description` varchar(255) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wpzxuawfxxojzkrtdbbfbgxrjuifaxqziibc` (`storeId`),
  CONSTRAINT `fk_ewcatqhplielxfckypnlpytmpuzckmmkopai` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_paymentcurrencies`
--

DROP TABLE IF EXISTS `commerce_paymentcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_paymentcurrencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL DEFAULT '1',
  `iso` varchar(3) NOT NULL,
  `rate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_emxkcvvzqvghaiawynmwpwpanrtbusvardnd` (`storeId`),
  KEY `idx_mvbjclfjyewfyrefwpcqxxtxhyymtoumqnvo` (`iso`),
  CONSTRAINT `fk_gwnldazmcbkgzhxbffniyexxebxfzkhgzugu` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_paymentsources`
--

DROP TABLE IF EXISTS `commerce_paymentsources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_paymentsources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customerId` int NOT NULL,
  `gatewayId` int NOT NULL,
  `token` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `response` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_jlmavggwohmhimkdljxspvusxpeamopaeaik` (`customerId`),
  KEY `fk_ukmvolptmmugvjbxjrarkeewcsbztbxszhog` (`gatewayId`),
  CONSTRAINT `fk_jlmavggwohmhimkdljxspvusxpeamopaeaik` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ukmvolptmmugvjbxjrarkeewcsbztbxszhog` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_pdfs`
--

DROP TABLE IF EXISTS `commerce_pdfs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_pdfs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `templatePath` varchar(255) NOT NULL,
  `fileNameFormat` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int DEFAULT NULL,
  `paperOrientation` varchar(255) DEFAULT 'portrait',
  `paperSize` varchar(255) DEFAULT 'letter',
  PRIMARY KEY (`id`),
  KEY `idx_rwuvmbzthhvvtgubtoqfnfhrnyqqzgcxkown` (`handle`),
  KEY `idx_rhectagnuucpezbauhjxigbtragzmdfntdbw` (`storeId`),
  CONSTRAINT `fk_bamkbrfavebhjcaisdyouhpyevbcwmetcdok` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_plans`
--

DROP TABLE IF EXISTS `commerce_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gatewayId` int DEFAULT NULL,
  `planInformationId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `planData` text,
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  `dateArchived` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `sortOrder` int DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hciuaqrvbpnhfhnpymrrahauikwpdzcprktf` (`handle`),
  KEY `idx_tbtiedpreusfxvhfrpsglccbksjsiavfordo` (`gatewayId`),
  KEY `idx_ppfoxhatdglzrafmkxujuxeduldrvmcoypdm` (`reference`),
  KEY `fk_tkykrcsaqmfdhkdaiuytzsoxrpjdhkuvzfyc` (`planInformationId`),
  CONSTRAINT `fk_ptscpeyxqcwbpvzyecovyltluxwvcymvryxr` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tkykrcsaqmfdhkdaiuytzsoxrpjdhkuvzfyc` FOREIGN KEY (`planInformationId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_products`
--

DROP TABLE IF EXISTS `commerce_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_products` (
  `id` int NOT NULL,
  `typeId` int DEFAULT NULL,
  `defaultVariantId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `defaultSku` varchar(255) DEFAULT NULL,
  `defaultPrice` decimal(14,4) DEFAULT NULL,
  `defaultHeight` decimal(14,4) DEFAULT NULL,
  `defaultLength` decimal(14,4) DEFAULT NULL,
  `defaultWidth` decimal(14,4) DEFAULT NULL,
  `defaultWeight` decimal(14,4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iuexqvtxkujvsxgqsixafjxcxbqhrbxxsgjk` (`typeId`),
  KEY `idx_exoylbcrcwagzoxhtsuuowunrxeinwarwkmy` (`postDate`),
  KEY `idx_zavlwfqllmjrqzcdmjzojmxjcbvmnjlzizwj` (`expiryDate`),
  CONSTRAINT `fk_qxpplptdhtndzmhupwoqazuspdvromoyndbz` FOREIGN KEY (`typeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xemresjabzrqrdbdrcnpykbumgvbfbrtkrye` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes`
--

DROP TABLE IF EXISTS `commerce_producttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `variantFieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `hasDimensions` tinyint(1) NOT NULL DEFAULT '0',
  `hasVariantTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `variantTitleFormat` varchar(255) NOT NULL,
  `hasProductTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `productTitleFormat` varchar(255) DEFAULT NULL,
  `skuFormat` varchar(255) DEFAULT NULL,
  `descriptionFormat` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `maxVariants` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kwlwccutmiavktwovnyzsexcpyllslqzixkb` (`handle`),
  KEY `idx_flrwldhaxnjbkgrnhqcbxsjmveqmxrdnukjc` (`fieldLayoutId`),
  KEY `idx_jlwiszkjbaqehdociietyblbelsjyrpwyctc` (`variantFieldLayoutId`),
  CONSTRAINT `fk_gdbxpkrbzzpbknpihddmwwihrbgrqyhhbmpx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yoocflldhnjywnenzknjslovgvzqkgpkilqy` FOREIGN KEY (`variantFieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes_shippingcategories`
--

DROP TABLE IF EXISTS `commerce_producttypes_shippingcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes_shippingcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productTypeId` int NOT NULL,
  `shippingCategoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dtrgxluwsdmtafprxwlabsequpzcsoqfzqbp` (`productTypeId`,`shippingCategoryId`),
  KEY `idx_cbokbqmxjbmyvrvgowmxytuiobpiurkghdhx` (`shippingCategoryId`),
  CONSTRAINT `fk_jzwdymltzzuvmlycxntwugrqctsdlbicqukt` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yggpxdwfjkdsffnedhmtnauvrexuuiydtxun` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes_sites`
--

DROP TABLE IF EXISTS `commerce_producttypes_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productTypeId` int NOT NULL,
  `siteId` int NOT NULL,
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_brhjqnjrffrrfikfmvnoibdptjvxwcrdtoax` (`productTypeId`,`siteId`),
  KEY `idx_nzvphtvibheluhjjgkazlteixfzqdwnsxkbh` (`siteId`),
  CONSTRAINT `fk_laswmvzsjstwaivumyftvadmergfzctngwsq` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nbevyyzhflivvaqnyqwgqemhbuwojlviachy` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes_taxcategories`
--

DROP TABLE IF EXISTS `commerce_producttypes_taxcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes_taxcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productTypeId` int NOT NULL,
  `taxCategoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_epjkpnpjcugxkrvbmvfulqtfuwgokuloezyz` (`productTypeId`,`taxCategoryId`),
  KEY `idx_immbwjfuivdjqfqutkdlxqxvjfgtedmamxgw` (`taxCategoryId`),
  CONSTRAINT `fk_hpjulzvbgkjimkloptziwavyeobzvdsqkpfe` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wmlwksfbknutdiflxwilvbyduwxoazwwktwi` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_purchasables`
--

DROP TABLE IF EXISTS `commerce_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_purchasables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `width` decimal(14,4) DEFAULT NULL,
  `height` decimal(14,4) DEFAULT NULL,
  `length` decimal(14,4) DEFAULT NULL,
  `weight` decimal(14,4) DEFAULT NULL,
  `taxCategoryId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_umvlujubabdtxjwisxqwjkfzkheihqcejrnp` (`sku`),
  KEY `fk_ljueoqxswkqsftxsobsxbisfrnmnyimbvmnn` (`taxCategoryId`),
  CONSTRAINT `fk_ljueoqxswkqsftxsobsxbisfrnmnyimbvmnn` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`),
  CONSTRAINT `fk_uvsxopednmgfovwfafflqqgtxldvgjhiduhs` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_purchasables_stores`
--

DROP TABLE IF EXISTS `commerce_purchasables_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_purchasables_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchasableId` int NOT NULL,
  `storeId` int NOT NULL,
  `basePrice` decimal(14,4) DEFAULT NULL,
  `basePromotionalPrice` decimal(14,4) DEFAULT NULL,
  `promotable` tinyint(1) NOT NULL DEFAULT '0',
  `availableForPurchase` tinyint(1) NOT NULL DEFAULT '1',
  `freeShipping` tinyint(1) NOT NULL DEFAULT '1',
  `stock` int DEFAULT NULL,
  `inventoryTracked` tinyint(1) NOT NULL DEFAULT '0',
  `minQty` int DEFAULT NULL,
  `maxQty` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `shippingCategoryId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ldqezkepxeksxplsvkjoeeqnsrtrokrtqiqq` (`storeId`),
  KEY `fk_hnzrvaicyzbmomgmdhrgblunlihtxapobvxy` (`shippingCategoryId`),
  KEY `fk_kcmwgxclqvlkqxffojcfyamqxnepjmvhcdzo` (`purchasableId`),
  CONSTRAINT `fk_hnzrvaicyzbmomgmdhrgblunlihtxapobvxy` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`),
  CONSTRAINT `fk_hzkktmuvesskkuycerbtfciuebtehypztegk` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kcmwgxclqvlkqxffojcfyamqxnepjmvhcdzo` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ldqezkepxeksxplsvkjoeeqnsrtrokrtqiqq` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sale_categories`
--

DROP TABLE IF EXISTS `commerce_sale_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sale_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `saleId` int NOT NULL,
  `categoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_afdgwtjxrkfamftpfxkrhiywdnappyjcmmuw` (`saleId`,`categoryId`),
  KEY `idx_lgbgbyxpfgvmakepwuzmkaylfojiljgsmpjt` (`categoryId`),
  CONSTRAINT `fk_lvirxblnwrgcnavlwwvbzxiiktdrgntssjud` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_utcyilpsvktnroeuwaohaeriautuknxemquk` FOREIGN KEY (`categoryId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sale_purchasables`
--

DROP TABLE IF EXISTS `commerce_sale_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sale_purchasables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `saleId` int NOT NULL,
  `purchasableId` int NOT NULL,
  `purchasableType` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qbzgboajgqgtqccxlvydlwbpdsyirectjrhq` (`saleId`,`purchasableId`),
  KEY `idx_fqybfeseuodvxwrvlzopeknezuuldmuuveqo` (`purchasableId`),
  CONSTRAINT `fk_ikefnuangaecaunsolxtdxrketzatbetgaze` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nsfcqptkdvuggdogyjublvcpkebrshopqbqt` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sale_usergroups`
--

DROP TABLE IF EXISTS `commerce_sale_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sale_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `saleId` int NOT NULL,
  `userGroupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fsphhsleplpvsnhebioiqbunsvyaiybbnbek` (`saleId`,`userGroupId`),
  KEY `idx_kslfglwffylamlxylmanyelwmybetnczpiev` (`userGroupId`),
  CONSTRAINT `fk_azpbjewwuasbtewuhnfvaaaetvzjdgefuyid` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ujqwvjguijgpacakpdqgxxkgbrocyoksohqg` FOREIGN KEY (`userGroupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sales`
--

DROP TABLE IF EXISTS `commerce_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `apply` enum('toPercent','toFlat','byPercent','byFlat') NOT NULL,
  `applyAmount` decimal(14,4) NOT NULL,
  `allGroups` tinyint(1) NOT NULL DEFAULT '0',
  `allPurchasables` tinyint(1) NOT NULL DEFAULT '0',
  `allCategories` tinyint(1) NOT NULL DEFAULT '0',
  `categoryRelationshipType` enum('element','sourceElement','targetElement') NOT NULL DEFAULT 'element',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `ignorePrevious` tinyint(1) NOT NULL DEFAULT '0',
  `stopProcessing` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingcategories`
--

DROP TABLE IF EXISTS `commerce_shippingcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_patzxjhycohlneswrndhbnvbbuetwznyegen` (`storeId`),
  CONSTRAINT `fk_lpybdsicplvxmnmvammwdogwebsowbhugset` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingmethods`
--

DROP TABLE IF EXISTS `commerce_shippingmethods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingmethods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int NOT NULL,
  `orderCondition` text,
  PRIMARY KEY (`id`),
  KEY `idx_mftcdcyabbajnennxbttvxhqclarticdymxe` (`storeId`),
  KEY `idx_rflefsrurmrxcbicdkhdouluhzlivaykwalh` (`name`),
  CONSTRAINT `fk_dwyuhsppaxmmssaxlvzsailzsxlrjhfqdhkt` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingrule_categories`
--

DROP TABLE IF EXISTS `commerce_shippingrule_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingrule_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shippingRuleId` int DEFAULT NULL,
  `shippingCategoryId` int DEFAULT NULL,
  `condition` enum('allow','disallow','require') NOT NULL,
  `perItemRate` decimal(14,4) DEFAULT NULL,
  `weightRate` decimal(14,4) DEFAULT NULL,
  `percentageRate` decimal(14,4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oskpkqklqmsxatpmzklusoszwjqkgvrwmwlx` (`shippingRuleId`),
  KEY `idx_dhempazjaokssmahjkcyyfdzyedfubvmxlms` (`shippingCategoryId`),
  CONSTRAINT `fk_gknyqzybbzpnncycvhslpfodgxuyynwwwlaj` FOREIGN KEY (`shippingRuleId`) REFERENCES `commerce_shippingrules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_skfgzqpvneacycdoowcxiqwdnagvwamkerxn` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingrules`
--

DROP TABLE IF EXISTS `commerce_shippingrules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingrules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shippingZoneId` int DEFAULT NULL,
  `methodId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `priority` int NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `orderConditionFormula` text,
  `baseRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `perItemRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `weightRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `percentageRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `minRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `maxRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `orderCondition` text,
  PRIMARY KEY (`id`),
  KEY `idx_utgeoyiewwqigywgjcoxyyovrhevhuwuhgrs` (`name`),
  KEY `idx_zsvcjywbscvsiwqtymfosihbljrkzpmqybjs` (`methodId`),
  CONSTRAINT `fk_wwlpvqbfftdebpmfhutvvffntqrnompuzjre` FOREIGN KEY (`methodId`) REFERENCES `commerce_shippingmethods` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingzones`
--

DROP TABLE IF EXISTS `commerce_shippingzones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingzones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `condition` text,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_thokxgiehgnmzkasfgwsjmysajwfwxsgpnkn` (`storeId`),
  KEY `idx_rdzlmdoctvtyjugtvrhbgidxziipnqbfqlsq` (`name`),
  CONSTRAINT `fk_odkgdhxxuiukgtauhkascfnpluzmxtmvuwfh` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_site_stores`
--

DROP TABLE IF EXISTS `commerce_site_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_site_stores` (
  `siteId` int NOT NULL,
  `storeId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`siteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_stores`
--

DROP TABLE IF EXISTS `commerce_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `autoSetNewCartAddresses` tinyint(1) NOT NULL DEFAULT '0',
  `autoSetCartShippingMethodOption` tinyint(1) NOT NULL DEFAULT '0',
  `autoSetPaymentSource` tinyint(1) NOT NULL DEFAULT '0',
  `allowEmptyCartOnCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `allowCheckoutWithoutPayment` tinyint(1) NOT NULL DEFAULT '0',
  `allowPartialPaymentOnCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `requireShippingAddressAtCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `requireBillingAddressAtCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `requireShippingMethodSelectionAtCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `useBillingAddressForTax` tinyint(1) NOT NULL DEFAULT '0',
  `validateOrganizationTaxIdAsVatId` tinyint(1) NOT NULL DEFAULT '0',
  `orderReferenceFormat` varchar(255) DEFAULT NULL,
  `freeOrderPaymentStrategy` varchar(255) DEFAULT 'complete',
  `minimumTotalPriceStrategy` varchar(255) DEFAULT 'default',
  `name` varchar(255) NOT NULL DEFAULT '',
  `handle` varchar(255) NOT NULL DEFAULT '',
  `primary` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `currency` varchar(255) NOT NULL DEFAULT 'USD',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_storesettings`
--

DROP TABLE IF EXISTS `commerce_storesettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_storesettings` (
  `id` int NOT NULL,
  `locationAddressId` int DEFAULT NULL,
  `countries` text,
  `marketAddressCondition` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_agvhrcpmlyjsyexzgnixcmtrtiopwcjbtokb` (`locationAddressId`),
  CONSTRAINT `fk_agvhrcpmlyjsyexzgnixcmtrtiopwcjbtokb` FOREIGN KEY (`locationAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_udynsvbbkhhcwcirnpzgxpuuegdaieenprtm` FOREIGN KEY (`id`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_subscriptions`
--

DROP TABLE IF EXISTS `commerce_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `planId` int DEFAULT NULL,
  `gatewayId` int DEFAULT NULL,
  `orderId` int DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `subscriptionData` text,
  `trialDays` int NOT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `hasStarted` tinyint(1) NOT NULL DEFAULT '1',
  `isSuspended` tinyint(1) NOT NULL DEFAULT '0',
  `dateSuspended` datetime DEFAULT NULL,
  `isCanceled` tinyint(1) NOT NULL DEFAULT '0',
  `dateCanceled` datetime DEFAULT NULL,
  `isExpired` tinyint(1) NOT NULL DEFAULT '0',
  `dateExpired` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xtciuyxmsldibhgvcbusbgtzemhskyemnvhx` (`reference`),
  KEY `idx_vruxvhufcpdyhvkzmdrjbskyzssfycdopvsl` (`userId`),
  KEY `idx_umpvudelsixqkowabmpyojlvkztjjvjxqpyh` (`planId`),
  KEY `idx_wbwqstmhuoypdfzkormseqbskdwxsmweuvxk` (`gatewayId`),
  KEY `idx_eyynjcsdgfjttxuzfdurdsiwzaiubleojppb` (`nextPaymentDate`),
  KEY `idx_qgqpnyaqtdpbvnrvlshyzmaizrzclorhjaam` (`dateCreated`),
  KEY `idx_ojvtxckmrqedzudivpanxqfqifrclofsqnpv` (`dateExpired`),
  KEY `fk_cdhyksvqcnadjbwrbcvtpynbsrolpjmytmrf` (`orderId`),
  CONSTRAINT `fk_cdhyksvqcnadjbwrbcvtpynbsrolpjmytmrf` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cfwsrmwugmahvxcahdaxgqbrsduhqdrhraev` FOREIGN KEY (`planId`) REFERENCES `commerce_plans` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_djnphayqspakgshgovduwtboignhrrhwvhsg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_fiifpimxxtriuxvvghkuwykchivmvaekiump` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_zpuabdnnnoyvxpnavdmpsdozxndiuruoumqx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_taxcategories`
--

DROP TABLE IF EXISTS `commerce_taxcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_taxcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_taxrates`
--

DROP TABLE IF EXISTS `commerce_taxrates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_taxrates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `taxZoneId` int DEFAULT NULL,
  `isEverywhere` tinyint(1) NOT NULL DEFAULT '1',
  `taxCategoryId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `rate` decimal(14,10) NOT NULL,
  `include` tinyint(1) NOT NULL DEFAULT '0',
  `isVat` tinyint(1) NOT NULL DEFAULT '0',
  `removeIncluded` tinyint(1) NOT NULL DEFAULT '0',
  `removeVatIncluded` tinyint(1) NOT NULL DEFAULT '0',
  `taxable` enum('purchasable','price','shipping','price_shipping','order_total_shipping','order_total_price') NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wenniozjmayzcoetmttgyvfwoxnyhhmjgptp` (`taxZoneId`),
  KEY `idx_ykstldccrrifpkxyjrtbwebsokhsvilbcija` (`taxCategoryId`),
  KEY `idx_pohrfkkhsvbjhoqrweepvqaiozsyijnhbwaq` (`storeId`),
  CONSTRAINT `fk_hdcdmmahxkhfilrfhycoltampmnzjgbmscqn` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_htppxnxafbzgivdmdjgsmacxlnnkwwnmcezc` FOREIGN KEY (`taxZoneId`) REFERENCES `commerce_taxzones` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_sbjfsfnzstgncpydqjiqwevnkxubgfhbcrul` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_taxzones`
--

DROP TABLE IF EXISTS `commerce_taxzones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_taxzones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `condition` text,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `storeId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zjyqdlvhwusejkoayblmowpnevcudvzgzmjn` (`storeId`),
  KEY `idx_pdhztmlvohjtbrduizdqbowiomkrmaowraax` (`name`),
  CONSTRAINT `fk_biypyfryfpftlrhgtalrluifpafdgfrasdtl` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_transactions`
--

DROP TABLE IF EXISTS `commerce_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `gatewayId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `type` enum('authorize','capture','purchase','refund') NOT NULL,
  `amount` decimal(14,4) DEFAULT NULL,
  `paymentAmount` decimal(14,4) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `paymentCurrency` varchar(255) DEFAULT NULL,
  `paymentRate` decimal(14,4) DEFAULT NULL,
  `status` enum('pending','redirect','success','failed','processing') NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `message` text,
  `note` mediumtext,
  `response` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uucebunxztjedduuxpcbkccvbswcnvotpyoo` (`parentId`),
  KEY `idx_jkapntitabzpuppzahrssqkvihonunoalfpv` (`gatewayId`),
  KEY `idx_dajtwkuvzyzpwbckltueninqvgyxrbqfyyol` (`orderId`),
  KEY `idx_berunudtlnojiespnpcyzndtdkczzxqwxysh` (`userId`),
  KEY `idx_pxdnbsldrlbuwuxdxrnyuobwhlqvexhlkwpm` (`hash`),
  CONSTRAINT `fk_ceiilysfoljxciaymjeewisnnrbswdiiyuxh` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_gnwpadzefcdeofvequggdsymrbkjaqpdjgqo` FOREIGN KEY (`parentId`) REFERENCES `commerce_transactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mbhexavgrknxisohpnkyhnvhhyovdqytbttb` FOREIGN KEY (`userId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zpumziafjhuizynwfazxekqmmcnladkmajod` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_transfers`
--

DROP TABLE IF EXISTS `commerce_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_transfers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transferStatus` enum('draft','pending','partial','received') NOT NULL,
  `originLocationId` int DEFAULT NULL,
  `destinationLocationId` int DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iuhqybglipggueurbqklqzvbxwqazsqhrlax` (`originLocationId`),
  KEY `idx_bspjobrbqolaabcrggoadfwicjcooafmxymz` (`destinationLocationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_transfers_inventoryitems`
--

DROP TABLE IF EXISTS `commerce_transfers_inventoryitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_transfers_inventoryitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transferId` int NOT NULL,
  `inventoryItemId` int NOT NULL,
  `quantity` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kgsaewwnlhbulfxikujmezxtikzhmfpxxzqn` (`inventoryItemId`),
  KEY `idx_zwffpvqcsbzlwkcwcfmwejivobzvggtcafhq` (`transferId`),
  CONSTRAINT `fk_dlgpdbjloigbywpvazmumoktbncnretvzgpr` FOREIGN KEY (`inventoryItemId`) REFERENCES `commerce_inventoryitems` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_efeahrjgafcfdptaiksjzgmgfqheeczmzcan` FOREIGN KEY (`transferId`) REFERENCES `commerce_inventoryitems` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_variants`
--

DROP TABLE IF EXISTS `commerce_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_variants` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `deletedWithProduct` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_voihcnojcrzzenmxoiosjfskfamhvaditjsr` (`primaryOwnerId`),
  CONSTRAINT `fk_ckhxrgjpilsipznkeusgksclskitamnjivby` FOREIGN KEY (`primaryOwnerId`) REFERENCES `commerce_products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gkoazxjvipujbkqxhkznxaujobzkijhytnwb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_fhifyjgyovrmmhiiumkdzxgtrrjozjotfcdp` (`userId`),
  CONSTRAINT `fk_fhifyjgyovrmmhiiumkdzxgtrrjozjotfcdp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tionxxlvellnmbvgslpimikzdyibviehnlcr` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_zaxmlgnktzlqpkvwnyufuoqwoxkehjzfibhz` (`creatorId`,`provisional`),
  KEY `idx_pmwomeesgkzmgzhslzvahlvxsempkzupydlz` (`saved`),
  KEY `fk_sgmsdfibshftvtuftgsezikpcgfpmbwivrgd` (`canonicalId`),
  CONSTRAINT `fk_sgmsdfibshftvtuftgsezikpcgfpmbwivrgd` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wlaerjmgrxncpbmmrglzustxhfaasczoxpxf` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_jncvcofslponiblzgdqjlawnxhzdufdetnoc` (`elementId`,`timestamp`,`userId`),
  KEY `fk_ibgpvzmlmspbjxyuxndlfkixuuqsrdmsmtxt` (`userId`),
  KEY `fk_oivjmapmfarrnhurcreyonfhtsdinepisonq` (`siteId`),
  KEY `fk_hgcbsorzwagcsrwmttglotvyfgvkydmwnkyd` (`draftId`),
  CONSTRAINT `fk_hgcbsorzwagcsrwmttglotvyfgvkydmwnkyd` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ibgpvzmlmspbjxyuxndlfkixuuqsrdmsmtxt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oivjmapmfarrnhurcreyonfhtsdinepisonq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_puubrtkfwivpdiundwbrcensoijhwvrxvfqz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wnxaxyvfaoitwmcppabsgfsjyjdmxroxiydz` (`dateDeleted`),
  KEY `idx_pyimnggagpnvuvwphsdyhnxyxukeoxvnfvrq` (`fieldLayoutId`),
  KEY `idx_bitibcijrzirqjaqssnkbmpawtlgtlfhptor` (`type`),
  KEY `idx_igukgzuxycmjuobvutyolaaqsxokzmewdluv` (`enabled`),
  KEY `idx_tglgpbxzebvgyrczyhxvalyvwwnzyjpkwuye` (`canonicalId`),
  KEY `idx_jcacoyigwhpijqnxguajayfuusgfltfwwbaq` (`archived`,`dateCreated`),
  KEY `idx_phhccxizsbzvxtnpvjfyiyrwqizkavgulwqu` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_aszcownkuevopucfewfnyjadkuszkkgfqzaf` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_thrxlhygbetjprnnguwebwmlaqtpkvruilvd` (`draftId`),
  KEY `fk_friwnezsiwdkreztahkqnffpypgoflewsqpq` (`revisionId`),
  CONSTRAINT `fk_aymtgskztveestzasfzxejmgubzbaabvqlgu` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_friwnezsiwdkreztahkqnffpypgoflewsqpq` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rhuwgnwpsaclntsgtiqvokbnmxpfujoparkb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_thrxlhygbetjprnnguwebwmlaqtpkvruilvd` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_qrioeajalgipayilxashsohsuybtfqrrpqof` (`timestamp`),
  CONSTRAINT `fk_ojwmwmjfkgczxhbjyazaoddqpnfiuxgvtyop` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_jkobkdaqbtjzimntliowywjmsxkybnjijswl` (`ownerId`),
  CONSTRAINT `fk_grypvkxbouoscizulncnkzendctxsjvpqufs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jkobkdaqbtjzimntliowywjmsxkybnjijswl` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mhkxwahkniglpxbuvbpptcvlquppxzlbmbhb` (`elementId`,`siteId`),
  KEY `idx_mtuqbnsmnndmvssxrxwfinitaplvmwmckfnn` (`siteId`),
  KEY `idx_lnrupmnowskobvfizjookxecqwdckwabysfc` (`slug`,`siteId`),
  KEY `idx_dxgmxdkeiortbnombizgsfebtrkqunqtzhsa` (`enabled`),
  KEY `idx_vfiybhbenbkkldrizmatqcddttrmpdjcztpr` (`uri`,`siteId`),
  KEY `idx_nmtjxzryefspljwnmebnvtrqyoubctztvjxe` (`title`,`siteId`),
  CONSTRAINT `fk_iohsrkfdyiushxdlumjqwhrlmnyuhszisnvi` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vjyadjtzwueojuzgoiqvqfjizehfhoqjalbd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lajyhoazmiidcjhfsljqvtwgwjbmhiofubcr` (`postDate`),
  KEY `idx_yemnfazgajbqpdbckwlzwmfgtcktruleywas` (`expiryDate`),
  KEY `idx_chyqraxkwppdwerjteyxdvrxlloxghzpdgsz` (`sectionId`),
  KEY `idx_mcznnqdshqsgekjstcdinghgazvlzpalgowt` (`typeId`),
  KEY `fk_pfmbbwznxyrmzxvgasfzwpzjabtqzxzqsxge` (`parentId`),
  KEY `idx_iobundcjywvgvmmgcyoimjehtofgdnopegma` (`primaryOwnerId`),
  KEY `idx_qmbtfzbyrnkdwpirtmhsppofnslmdelqjzqe` (`fieldId`),
  CONSTRAINT `fk_gownyhopgxlvzabobjuvhcrhxpxdthpnhoha` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oerhnczllnpjzeoejndsgzwbezdnknibunqf` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pfmbbwznxyrmzxvgasfzwpzjabtqzxzqsxge` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pndrrwngkfjzqyztjpcpkphnhjdupvyrkgbt` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rcxszdrirrinwcznzghrpredfvaggjrflszi` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tueyoqctxdtlmyrmcpulpbsohoycxdlkqytk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_tlspviyianeuvhhqtxsmwbfmwthjqgtdskoj` (`authorId`),
  KEY `idx_duegdwnayjvooxdzdcdyoxtisepyrehifoxn` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_rjhwgjgyaxbfiijgnyjmuvxcvabekixaekuy` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zpprvqyzjsrfdtibqmnnguwgeykstiskwcjq` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ocefsodrinpsjtqogoxiffassmeqlqmprnub` (`fieldLayoutId`),
  KEY `idx_dkrgntobfzoritgfufkkdyjtjjjqygsxbzgh` (`dateDeleted`),
  CONSTRAINT `fk_tvjgdltalrtxtdszsrlnnneotrhduathunjy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ksiaesddbaqywyggjaexhcvttmokswineoae` (`dateDeleted`),
  KEY `idx_fqmtlyfndokvzomffrzctdyhqcctfzubwlui` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usaqhgsduhpnsjzgeyhrjqvoqqfbtpuwphti` (`handle`,`context`),
  KEY `idx_bfbrwavdwulrijminmtmqejknjzjtasnoico` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ewdlosjjndmtihkpsjqelkldgeuhxbhuamiq` (`name`),
  KEY `idx_tkxcajvkgvfcxiswchlcooqubedhmwsmfnvu` (`handle`),
  KEY `idx_hmjzmzvztfsihbewbsthkqdoqjfhquehfmwq` (`fieldLayoutId`),
  KEY `idx_sjjwrjzocmivxnzhzjhsdwpjegzyfycqgtck` (`sortOrder`),
  CONSTRAINT `fk_zamaxcmzamnvkfaahpouskrgshmjutnijdtf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zcrqypxyoppnpszyfssaogrjvyqvrjhmvaqf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uktunsdabtcxotpixnlfxaduxfskenlmqyvj` (`accessToken`),
  UNIQUE KEY `idx_ebafogjkljnmuticdtoydxprbgxrukoszmlj` (`name`),
  KEY `fk_qkteafljfdamkhwecmglnadzazbiqlifrclj` (`schemaId`),
  CONSTRAINT `fk_qkteafljfdamkhwecmglnadzazbiqlifrclj` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uttpkxutejvwjeuufeefcvgoqdzrndandryo` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qrdrdqfzyxecudlhhthelnsahusckbtuzrau` (`name`),
  KEY `idx_fhfpkympnoqdqlchuqzqrpoihhnkabvtmomg` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aljopkljybuvzmmnnafiucwlwgkigswqsfre` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zbfrpggkblyenfxhjpximazhzwsldnzgghwt` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_wllgrbhhthkafuvlrahqxblxgstqcpvdbqjh` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_htapnewjxdilenhqysjktkqntvlvksynjigx` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=405 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_wmiojnyxgtkukzytvqtehqljrspbungazyfi` (`userId`),
  CONSTRAINT `fk_wmiojnyxgtkukzytvqtehqljrspbungazyfi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_plnyjihwfedwfnaoyfpdrjceasuoouudfosk` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_adiljshhijjqporzqypnsfuvmpjatyqpdvge` (`sourceId`),
  KEY `idx_ppjgtuskqetfbkcylvhegwzajczkicknlfos` (`targetId`),
  KEY `idx_ukmslfmgnbxpngorvptpofyrlmibfjwcaael` (`sourceSiteId`),
  CONSTRAINT `fk_apbzygczgkjxylifddbaoagmdmhhpcqnvwmd` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gykaotjwnovgnwsrmjoteemtytkzmvjvokzg` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xrhtozqkxewpdxbzxtwmkygziyzgxcbcmlgp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yxuhrcisimofuloztqvaskcoygkdixasijjn` (`canonicalId`,`num`),
  KEY `fk_zsqfmsnhiwojtpuvbahenaloahbaoonldikc` (`creatorId`),
  CONSTRAINT `fk_vsxjdadtdhfachcpfwnjbdhhemikyvqwvvhx` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zsqfmsnhiwojtpuvbahenaloahbaoonldikc` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_ugvkmmdbpvklmuzpjvkqpbhsatskzubpybwk` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zffikwzzuhnobtzdymuxauzdwxzjhshtdtex` (`handle`),
  KEY `idx_cmsdnldiugbrkuqtntdwtymlppngpikehdcr` (`name`),
  KEY `idx_tfdbjvkszcgeavjiaunwynynpnkoimisdjqo` (`structureId`),
  KEY `idx_gnlswlzprahnoklwbzmgqkoilxwkiiixxxhq` (`dateDeleted`),
  CONSTRAINT `fk_evxxfoptoixnskelkawxmdbxjhbtbkzcyver` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_rldftaalbohyiljxzhhfkibceaffkghopdyi` (`typeId`),
  CONSTRAINT `fk_ajtomlxkbzqekhpdvpioddvcqtiuaqgxdqle` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rldftaalbohyiljxzhhfkibceaffkghopdyi` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fctrbtmhdzkxwxwcggzlsjvluosphzvwdxvx` (`sectionId`,`siteId`),
  KEY `idx_vvgezucwfuathjzonqktfjodfkgwpklhjxus` (`siteId`),
  CONSTRAINT `fk_cfyxhcwauvhvhbfpiqdbcjswzpzpklqqmlxl` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pbtojqwarxfwjqzqqbvdfdwckpgrdwnhumth` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bfcqoyfgnlvrkkkhlrevmgffwidflmkhzbyr` (`uid`),
  KEY `idx_rsshsykjeajywjjvowkujifjdsidwrmiyvxc` (`token`),
  KEY `idx_itbartkjlobyrqacekrlqyrwiftwavzxtcen` (`dateUpdated`),
  KEY `idx_ayabagxsajlaleyhjakfeeiluxjfbysmoyix` (`userId`),
  CONSTRAINT `fk_xzvbzspwausgtwggzjglpipgejiocxhtriom` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wqzkvnpkcxbolkwinfrwpqakpeizbxvmfqgh` (`userId`,`message`),
  CONSTRAINT `fk_rbbxoqvaebvjqiauzrzcjzuqwrbshsnkhpzv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_itueugtnvwfftrlpimecrakhwahhgetigzsw` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_feuwdqmefmpvfytgmiijbzkmlmuqugqbvyqi` (`dateDeleted`),
  KEY `idx_plewtipawsiizxayqxkpwhockvknlginxust` (`handle`),
  KEY `idx_bpnkrvmocmvhvfmoahxlqrapwqbmhrhblaig` (`sortOrder`),
  KEY `fk_wmqsnbhiqbowlltjhvqqwpoddvsprhradwhk` (`groupId`),
  CONSTRAINT `fk_wmqsnbhiqbowlltjhvqqwpoddvsprhradwhk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sprig_playgrounds`
--

DROP TABLE IF EXISTS `sprig_playgrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sprig_playgrounds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `component` text,
  `variables` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nanilqgxqrdamgissajeltzitvwajkyedufv` (`structureId`,`elementId`),
  KEY `idx_dmzrktoezygrytpnxljduevqgekktvdcxezh` (`root`),
  KEY `idx_fwtkeikvofwpjgwqnnngrcwdoqimdwqojevl` (`lft`),
  KEY `idx_vcpnzgrvwhjydoodmoxwzdjgawrcgmohnotk` (`rgt`),
  KEY `idx_wcjzxcltrsacecamapcbtgydxipnuegsrsns` (`level`),
  KEY `idx_zdgytrfutiqnlcpipkpjdnbptntllyhpmtqn` (`elementId`),
  CONSTRAINT `fk_jrvmfrvycdfubsduytgbivbifdhqchtkgahk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hctwsjlszjjviazwdnofhuodjzpdbykyapad` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_htcldouhwkwviugnwxxotvdsgxbhsbohlmpy` (`key`,`language`),
  KEY `idx_jegxahggdqfcbyxpnkfwpjhetmiqyglazacu` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bysreezqreelxraxnkcblctmpkpjuervxxsv` (`name`),
  KEY `idx_trjgybcbmgcmvyjkshjwpgpfjurbovxlpeya` (`handle`),
  KEY `idx_tiwzpftfiwkrgbktpjsytllaqlbgyxvbjnak` (`dateDeleted`),
  KEY `fk_hrswoxeaxoreukwxnmhmricgghrdywaphpqy` (`fieldLayoutId`),
  CONSTRAINT `fk_hrswoxeaxoreukwxnmhmricgghrdywaphpqy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fbyxwncptjowczqzeedlzonjolmpzsgvsthc` (`groupId`),
  CONSTRAINT `fk_mfuzdgczjlhzarbfowzacmmdsmdmhukpxqoi` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ynwkldiakiehyywivuelyzdguugjvreitfui` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dntdamhbqfzbencctbucqkbezxonaiiufeju` (`token`),
  KEY `idx_ewrffzjdjrpcexncpnmuavcylgvmaouvwuit` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cptiahjawcafqcmhzlscsypzsafxbnfpptni` (`handle`),
  KEY `idx_hnvvgmpmdffylcoanftjlwgriybkmmeajxps` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hkebqotdrztoppyrmgvbfeuvkvemogfsegen` (`groupId`,`userId`),
  KEY `idx_csgruiscubjupnlcshwnuyuphnecywbliawy` (`userId`),
  CONSTRAINT `fk_ctwqlzlnxejxfkwdbuwvtclfpavnilmnupwh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_snpylbufmvqndhvbphqryclqfrpgewghxtli` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lluwljrlthdfdaqpdchaavaiddpbqszoglay` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fmlsthjrhkolswqegknbdmrdevomvbjfzkfl` (`permissionId`,`groupId`),
  KEY `idx_lbelccoeubxhjrrlnqfzdihdsoigmxxvgbny` (`groupId`),
  CONSTRAINT `fk_kdxycummdcumdgddxfmojlporwqmsdbuvsrw` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sairdgxsyyihrhzutvkudmxbmisjpcwzcams` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zwxmltpzvftrkfkvqqdfmzcuniavuevxwxgn` (`permissionId`,`userId`),
  KEY `idx_wadsxzurhuhabeliurosvcbjrisrscdnntub` (`userId`),
  CONSTRAINT `fk_wvaymyjdhmkzfnmfrbmysnurlxrswxgcpoqt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yhazsbuugvtsocutiongmkyfyeovbojodwpt` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_dlgahrmshacmektipimtmougolqtlrimkbqd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pnskxyujpdleqtuoddycjaorodgzgxkupcsk` (`active`),
  KEY `idx_ifwnjrlbspyzwbphxnttawrymomildttokmq` (`locked`),
  KEY `idx_ngxhynjkuiycshkcekszpvugwjqjhvyazewe` (`pending`),
  KEY `idx_azsoicivcgtngneujfwvolspayyozvsggjbk` (`suspended`),
  KEY `idx_egktoroonoybhocdarpqanfhmisfrjblvewb` (`verificationCode`),
  KEY `idx_zxfcxolwynjuqhqxzdoohczcfywhrkmychpc` (`email`),
  KEY `idx_vlntgfaefbuzxzfqlfndtvqyyqxvolokblkx` (`username`),
  KEY `fk_zatrbynmpyyticaomlgplwypxdxcjquyhvfu` (`photoId`),
  CONSTRAINT `fk_cwlafkwlunsylbpjxadcmqwklaigwoeiooah` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zatrbynmpyyticaomlgplwypxdxcjquyhvfu` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nqkwyqbvszspopzmyotfxpmnjdbglkkgamxo` (`name`,`parentId`,`volumeId`),
  KEY `idx_ppthhmesigkuuqctnrkibfqmbebechzgozdw` (`parentId`),
  KEY `idx_blygecpjhwjehbfhfpehvvqorrtyvvjvbatl` (`volumeId`),
  CONSTRAINT `fk_njvovyplshhxekpwemydqxdpdkxnupaiqkwv` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sippjpvxvzdqmxvskmtqsvnxtcjjvcxsmagb` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_objiqjduygvshcgxfzdkbvyhxgygtigsqvac` (`name`),
  KEY `idx_bbphddptmmqeqohootuongxpvxlohckihhug` (`handle`),
  KEY `idx_grjybfqtizlswhxtfrucvzljxhrcuibskbdv` (`fieldLayoutId`),
  KEY `idx_kybofihxradpwhppuechcnzdejhkjecjmuae` (`dateDeleted`),
  CONSTRAINT `fk_nmhzwpmnbfdqmzxnhoggpdgryiomgoxwundv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_rktwkwoepgpthdymetbaxddjsfzsyhcabslc` (`userId`),
  CONSTRAINT `fk_rktwkwoepgpthdymetbaxddjsfzsyhcabslc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hyabrwudbtoglpapzbgqnyqvqcirpunhdfbr` (`userId`),
  CONSTRAINT `fk_dfavlmbxucsodihcrjowpfytyltbueptiixd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-15 17:25:03
-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `addresses` VALUES
(14,NULL,NULL,'US',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-02-18 01:48:33','2024-02-18 01:48:33');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES
(21,1,1,1,'shopping-cart-page-01-product-01.jpg','image',NULL,1280,1280,51552,NULL,NULL,NULL,'2024-02-18 02:01:36','2024-02-18 02:01:36','2024-02-18 02:01:36'),
(22,1,1,1,'shopping-cart-page-01-product-02.jpg','image',NULL,1280,1280,29576,NULL,NULL,NULL,'2024-02-18 02:01:36','2024-02-18 02:01:36','2024-02-18 02:01:36'),
(23,1,1,1,'shopping-cart-page-01-product-03.jpg','image',NULL,1280,1280,15074,NULL,NULL,NULL,'2024-02-18 02:01:36','2024-02-18 02:01:36','2024-02-18 02:01:36');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES
(1,1,'email','2024-01-13 02:21:53',0,1),
(1,1,'fullName','2024-01-12 18:16:52',0,1),
(2,1,'postDate','2024-01-12 15:12:11',0,1),
(2,1,'slug','2024-01-12 01:00:33',0,1),
(2,1,'title','2024-01-12 01:00:33',0,1),
(2,1,'uri','2024-01-12 01:00:33',0,1),
(4,1,'postDate','2024-01-12 15:12:05',0,1),
(4,1,'slug','2024-01-12 01:00:44',0,1),
(4,1,'title','2024-01-12 01:00:43',0,1),
(4,1,'uri','2024-01-12 01:00:44',0,1),
(6,1,'postDate','2024-01-12 01:00:52',0,1),
(6,1,'slug','2024-01-12 01:00:52',0,1),
(6,1,'title','2024-01-12 01:00:50',0,1),
(6,1,'uri','2024-01-12 01:00:52',0,1),
(39,1,'postDate','2024-05-15 07:47:03',0,1),
(39,1,'slug','2024-05-15 07:46:26',0,1),
(39,1,'title','2024-05-15 07:46:26',0,1),
(39,1,'uri','2024-05-15 07:46:26',0,1),
(40,1,'postDate','2024-05-15 07:46:46',0,1),
(40,1,'slug','2024-05-15 07:46:45',0,1),
(40,1,'title','2024-05-15 07:46:59',0,1),
(40,1,'uri','2024-05-15 07:46:45',0,1),
(46,1,'postDate','2024-05-15 13:25:58',0,1),
(46,1,'slug','2024-05-15 13:25:58',0,1),
(46,1,'title','2024-05-15 13:25:58',0,1),
(46,1,'uri','2024-05-15 13:25:58',0,1),
(50,1,'postDate','2024-05-15 13:26:19',0,1),
(50,1,'slug','2024-05-15 13:26:10',0,1),
(50,1,'title','2024-05-15 13:26:10',0,1),
(50,1,'uri','2024-05-15 13:26:10',0,1),
(51,1,'postDate','2024-05-15 13:26:16',0,1),
(51,1,'slug','2024-05-15 13:26:16',0,1),
(51,1,'title','2024-05-15 13:26:16',0,1),
(51,1,'uri','2024-05-15 13:26:16',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES
(15,1,3,'9993725b-6c75-43ae-aaaf-cf374499f2f4','2024-05-12 20:27:12',0,1),
(15,1,5,'22de9eb7-2bce-4648-bcba-8a9a3e40b061','2024-05-15 07:47:08',0,1),
(15,1,6,'89927820-c649-4415-836e-5e969370d306','2024-05-15 14:51:20',0,1),
(17,1,3,'9993725b-6c75-43ae-aaaf-cf374499f2f4','2024-05-12 20:27:23',0,1),
(19,1,3,'9993725b-6c75-43ae-aaaf-cf374499f2f4','2024-05-12 20:27:52',0,1),
(39,1,4,'1668e7f7-53b1-4a9f-a4a1-36a0b320791f','2024-05-15 13:26:01',0,1),
(50,1,4,'1668e7f7-53b1-4a9f-a4a1-36a0b320791f','2024-05-15 13:26:19',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_catalogpricing`
--

LOCK TABLES `commerce_catalogpricing` WRITE;
/*!40000 ALTER TABLE `commerce_catalogpricing` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_catalogpricing` VALUES
(1,0.0000,13,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:48:26','2024-02-18 01:48:26','e2a728cb-069e-49a5-a615-2ffd2f1a1324',0),
(2,32.0000,16,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:49:28','2024-05-12 20:08:39','fcf6aae2-050c-4872-9679-5b8ce0861347',0),
(3,50.0000,18,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:50:11','2024-05-12 20:08:39','a730bf4c-11e2-40fb-8a8f-bbd85887e72f',0),
(4,35.0000,20,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:50:31','2024-05-12 20:08:39','16fc91d8-453e-4c43-bc9d-e21ea59b8f9e',0),
(5,35.0000,31,1,NULL,NULL,NULL,NULL,0,'2024-02-20 13:50:49','2024-05-12 20:08:39','a8679a27-fb8a-4e39-a300-fbcb91fdf6e3',0),
(6,0.0000,13,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:48:26','2024-02-18 01:48:26','ef0558b7-f6cf-4e36-aea1-3b45320ce4c8',0),
(7,32.0000,16,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:49:28','2024-05-12 20:20:55','811ab774-b4fd-43f3-a29e-b07bd0861d40',0),
(8,50.0000,18,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:50:11','2024-05-12 20:20:55','5fd68a70-2d64-4182-983d-010446b8eeb8',0),
(9,35.0000,20,1,NULL,NULL,NULL,NULL,0,'2024-02-18 01:50:31','2024-05-12 20:20:55','bfb673c4-f13b-4758-9b5a-d1adb57f2cce',0),
(10,35.0000,31,1,NULL,NULL,NULL,NULL,0,'2024-02-20 13:50:49','2024-05-12 20:20:55','31c71f18-5b3c-4eb7-b5c4-4dc178afde53',0);
/*!40000 ALTER TABLE `commerce_catalogpricing` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_catalogpricingrules`
--

LOCK TABLES `commerce_catalogpricingrules` WRITE;
/*!40000 ALTER TABLE `commerce_catalogpricingrules` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_catalogpricingrules` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_catalogpricingrules_users`
--

LOCK TABLES `commerce_catalogpricingrules_users` WRITE;
/*!40000 ALTER TABLE `commerce_catalogpricingrules_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_catalogpricingrules_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_coupons`
--

LOCK TABLES `commerce_coupons` WRITE;
/*!40000 ALTER TABLE `commerce_coupons` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_coupons` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_customer_discountuses`
--

LOCK TABLES `commerce_customer_discountuses` WRITE;
/*!40000 ALTER TABLE `commerce_customer_discountuses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_customer_discountuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_customers`
--

LOCK TABLES `commerce_customers` WRITE;
/*!40000 ALTER TABLE `commerce_customers` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_customers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_discount_categories`
--

LOCK TABLES `commerce_discount_categories` WRITE;
/*!40000 ALTER TABLE `commerce_discount_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_discount_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_discount_purchasables`
--

LOCK TABLES `commerce_discount_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_discount_purchasables` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_discount_purchasables` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_discounts`
--

LOCK TABLES `commerce_discounts` WRITE;
/*!40000 ALTER TABLE `commerce_discounts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_discounts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_donations`
--

LOCK TABLES `commerce_donations` WRITE;
/*!40000 ALTER TABLE `commerce_donations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_donations` VALUES
(13,'DONATION-CC4','2024-02-18 01:48:26','2024-02-18 01:48:26','d4151140-750c-46db-abd8-545fd039f982');
/*!40000 ALTER TABLE `commerce_donations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_email_discountuses`
--

LOCK TABLES `commerce_email_discountuses` WRITE;
/*!40000 ALTER TABLE `commerce_email_discountuses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_email_discountuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_emails`
--

LOCK TABLES `commerce_emails` WRITE;
/*!40000 ALTER TABLE `commerce_emails` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_emails` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_gateways`
--

LOCK TABLES `commerce_gateways` WRITE;
/*!40000 ALTER TABLE `commerce_gateways` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_gateways` VALUES
(1,'craft\\commerce\\gateways\\Dummy','Dummy','dummy',NULL,'purchase','1',0,NULL,99,'2024-02-18 01:48:26','2024-02-18 01:48:26','78d705b6-3fee-471b-9451-847caf510cde');
/*!40000 ALTER TABLE `commerce_gateways` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_inventoryitems`
--

LOCK TABLES `commerce_inventoryitems` WRITE;
/*!40000 ALTER TABLE `commerce_inventoryitems` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_inventoryitems` VALUES
(1,13,NULL,NULL,NULL,'2024-05-12 20:20:57','2024-05-12 20:20:57','1d4c259e-b574-437c-a70f-43c13e6903e2'),
(2,16,NULL,NULL,NULL,'2024-05-12 20:20:57','2024-05-12 20:20:57','e442f888-f149-4f7f-8ca7-de223859b20d'),
(3,18,NULL,NULL,NULL,'2024-05-12 20:20:57','2024-05-12 20:20:57','3519fb1a-21c1-4fd7-ad10-7bd2e2cf7731'),
(4,20,NULL,NULL,NULL,'2024-05-12 20:20:57','2024-05-12 20:20:57','405ce802-d771-4b75-9409-e9dc58853ea5'),
(5,31,NULL,NULL,NULL,'2024-05-12 20:20:57','2024-05-12 20:20:57','18d505d7-54ea-48fb-8b97-187558ac378b');
/*!40000 ALTER TABLE `commerce_inventoryitems` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_inventorylocations`
--

LOCK TABLES `commerce_inventorylocations` WRITE;
/*!40000 ALTER TABLE `commerce_inventorylocations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_inventorylocations` VALUES
(1,'default','Default',14,'2024-05-12 20:20:57','2024-05-12 20:20:57',NULL,'533da2b3-7b1d-48f2-bd30-42fa13238841');
/*!40000 ALTER TABLE `commerce_inventorylocations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_inventorylocations_stores`
--

LOCK TABLES `commerce_inventorylocations_stores` WRITE;
/*!40000 ALTER TABLE `commerce_inventorylocations_stores` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_inventorylocations_stores` VALUES
(1,1,1,1,'2024-05-12 20:20:57','2024-05-12 20:20:57','645cdf98-f9c2-4be7-b11a-8f5a5d2a4a4a');
/*!40000 ALTER TABLE `commerce_inventorylocations_stores` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_inventorytransactions`
--

LOCK TABLES `commerce_inventorytransactions` WRITE;
/*!40000 ALTER TABLE `commerce_inventorytransactions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_inventorytransactions` VALUES
(1,1,1,'69e7ed5c79a4b7c298e7d25343111eb6',0,'available','count',NULL,NULL,NULL,'2024-05-12 20:20:57','a14471fb-cccf-4071-9866-2e4b580e41dd'),
(2,1,2,'d43bece23503c660e1790808aaa9d540',100,'available','count',NULL,NULL,NULL,'2024-05-12 20:20:57','a5d44968-fcbb-462f-abf1-00dd396d840d'),
(3,1,3,'be2ccabbe9cf70e40d45b3f0904b12f3',0,'available','count',NULL,NULL,NULL,'2024-05-12 20:20:57','3cad356c-f033-4e40-af35-6df8213121d5'),
(4,1,4,'008339a30513de072d9fca722c399ba5',50,'available','count',NULL,NULL,NULL,'2024-05-12 20:20:57','8acdfa0b-0348-424b-a75d-6676103200af'),
(5,1,5,'c5b31bddfa1326b3175473a4c14200ae',100,'available','count',NULL,NULL,NULL,'2024-05-12 20:20:57','8b7678c5-4221-4142-9433-652dd72d97b5');
/*!40000 ALTER TABLE `commerce_inventorytransactions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_lineitems`
--

LOCK TABLES `commerce_lineitems` WRITE;
/*!40000 ALTER TABLE `commerce_lineitems` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_lineitems` VALUES
(19,24,20,1,1,'Nomad Tumbler - Nomad Tumbler','[]','d751713988987e9331980363e24189ce',35.0000,NULL,0.0000,35.0000,'003',0.0000,0.0000,0.0000,0.0000,210.0000,252.0000,6,'','','{\"productId\":19,\"isDefault\":true,\"price\":35,\"sortOrder\":1,\"width\":0,\"height\":0,\"length\":0,\"weight\":0,\"stock\":50,\"hasUnlimitedStock\":false,\"minQty\":null,\"maxQty\":null,\"deletedWithProduct\":false,\"id\":20,\"tempId\":null,\"draftId\":null,\"revisionId\":null,\"isProvisionalDraft\":false,\"uid\":\"79d30fe9-776c-4f71-a1b7-d90db74ca8cd\",\"siteSettingsId\":20,\"fieldLayoutId\":null,\"contentId\":19,\"enabled\":true,\"archived\":false,\"siteId\":1,\"title\":\"Nomad Tumbler\",\"slug\":null,\"uri\":null,\"dateCreated\":\"2024-02-17T17:50:31-08:00\",\"dateUpdated\":\"2024-02-18T05:58:45-08:00\",\"dateLastMerged\":null,\"dateDeleted\":null,\"trashed\":false,\"validatingRelatedElement\":false,\"isNewForSite\":false,\"canonicalId\":20,\"isDraft\":false,\"isRevision\":false,\"isUnpublishedDraft\":false,\"ref\":null,\"status\":\"enabled\",\"structureId\":null,\"url\":\"https:\\/\\/sprig-training.ddev.site\\/products\\/nomad-tumbler?variant=20\",\"isAvailable\":true,\"isPromotable\":true,\"shippingCategoryId\":1,\"sku\":\"003\",\"taxCategoryId\":1,\"product\":{\"postDate\":\"2024-02-17T17:50:00-08:00\",\"expiryDate\":null,\"typeId\":1,\"taxCategoryId\":1,\"shippingCategoryId\":1,\"promotable\":true,\"freeShipping\":false,\"availableForPurchase\":true,\"defaultVariantId\":20,\"defaultSku\":\"003\",\"defaultPrice\":35,\"defaultHeight\":0,\"defaultLength\":0,\"defaultWidth\":0,\"defaultWeight\":0,\"taxCategory\":null,\"name\":null,\"id\":19,\"tempId\":null,\"draftId\":null,\"revisionId\":null,\"isProvisionalDraft\":false,\"uid\":\"2d807b48-d51c-4839-b8f3-9af9360a5353\",\"siteSettingsId\":19,\"fieldLayoutId\":3,\"contentId\":18,\"enabled\":true,\"archived\":false,\"siteId\":1,\"title\":\"Nomad Tumbler\",\"slug\":\"nomad-tumbler\",\"uri\":\"products\\/nomad-tumbler\",\"dateCreated\":\"2024-02-17T17:50:31-08:00\",\"dateUpdated\":\"2024-02-17T18:02:11-08:00\",\"dateLastMerged\":null,\"dateDeleted\":null,\"trashed\":false,\"validatingRelatedElement\":false,\"isNewForSite\":false,\"canonicalId\":19,\"isDraft\":false,\"isRevision\":false,\"isUnpublishedDraft\":false,\"ref\":null,\"status\":\"live\",\"structureId\":null,\"url\":\"https:\\/\\/sprig-training.ddev.site\\/products\\/nomad-tumbler\"},\"onSale\":false,\"cpEditUrl\":\"#\",\"description\":\"Nomad Tumbler - Nomad Tumbler\",\"purchasableId\":20,\"options\":[],\"sales\":[]}',NULL,'2024-02-18 14:35:47','2024-02-20 02:54:16','66d1a1fc-8b52-4739-80c2-3293c78d9c1c'),
(20,24,16,1,1,'Basic Tee - Basic Tee','[]','d751713988987e9331980363e24189ce',32.0000,NULL,0.0000,32.0000,'001',0.0000,0.0000,0.0000,0.0000,32.0000,38.4000,1,'','','{\"productId\":15,\"isDefault\":true,\"price\":32,\"sortOrder\":1,\"width\":0,\"height\":0,\"length\":0,\"weight\":0,\"stock\":100,\"hasUnlimitedStock\":false,\"minQty\":null,\"maxQty\":null,\"deletedWithProduct\":false,\"id\":16,\"tempId\":null,\"draftId\":null,\"revisionId\":null,\"isProvisionalDraft\":false,\"uid\":\"3b129011-3ed9-4662-964b-239dc8000525\",\"siteSettingsId\":16,\"fieldLayoutId\":null,\"contentId\":15,\"enabled\":true,\"archived\":false,\"siteId\":1,\"title\":\"Basic Tee\",\"slug\":null,\"uri\":null,\"dateCreated\":\"2024-02-17T17:49:28-08:00\",\"dateUpdated\":\"2024-02-18T05:59:33-08:00\",\"dateLastMerged\":null,\"dateDeleted\":null,\"trashed\":false,\"validatingRelatedElement\":false,\"isNewForSite\":false,\"canonicalId\":16,\"isDraft\":false,\"isRevision\":false,\"isUnpublishedDraft\":false,\"ref\":null,\"status\":\"enabled\",\"structureId\":null,\"url\":\"https:\\/\\/sprig-training.ddev.site\\/products\\/basic-tee?variant=16\",\"isAvailable\":true,\"isPromotable\":true,\"shippingCategoryId\":1,\"sku\":\"001\",\"taxCategoryId\":1,\"product\":{\"postDate\":\"2024-02-17T17:50:00-08:00\",\"expiryDate\":null,\"typeId\":1,\"taxCategoryId\":1,\"shippingCategoryId\":1,\"promotable\":true,\"freeShipping\":false,\"availableForPurchase\":true,\"defaultVariantId\":16,\"defaultSku\":\"001\",\"defaultPrice\":32,\"defaultHeight\":0,\"defaultLength\":0,\"defaultWidth\":0,\"defaultWeight\":0,\"taxCategory\":null,\"name\":null,\"id\":15,\"tempId\":null,\"draftId\":null,\"revisionId\":null,\"isProvisionalDraft\":false,\"uid\":\"aef04d6b-6604-43bd-adbd-4c640444c244\",\"siteSettingsId\":15,\"fieldLayoutId\":3,\"contentId\":14,\"enabled\":true,\"archived\":false,\"siteId\":1,\"title\":\"Basic Tee\",\"slug\":\"basic-tee\",\"uri\":\"products\\/basic-tee\",\"dateCreated\":\"2024-02-17T17:49:28-08:00\",\"dateUpdated\":\"2024-02-18T05:59:33-08:00\",\"dateLastMerged\":null,\"dateDeleted\":null,\"trashed\":false,\"validatingRelatedElement\":false,\"isNewForSite\":false,\"canonicalId\":15,\"isDraft\":false,\"isRevision\":false,\"isUnpublishedDraft\":false,\"ref\":null,\"status\":\"live\",\"structureId\":null,\"url\":\"https:\\/\\/sprig-training.ddev.site\\/products\\/basic-tee\"},\"onSale\":false,\"cpEditUrl\":\"#\",\"description\":\"Basic Tee - Basic Tee\",\"purchasableId\":16,\"options\":[],\"sales\":[]}',NULL,'2024-02-19 14:16:02','2024-02-20 02:54:16','5d385e71-595c-4b73-adf6-6cc87744830f'),
(21,35,20,1,1,'Nomad Tumbler - Nomad Tumbler','[]','d751713988987e9331980363e24189ce',35.0000,NULL,0.0000,35.0000,'003',0.0000,0.0000,0.0000,0.0000,175.0000,210.0000,5,'','','{\"productId\":19,\"isDefault\":true,\"price\":35,\"sortOrder\":1,\"width\":0,\"height\":0,\"length\":0,\"weight\":0,\"stock\":50,\"hasUnlimitedStock\":false,\"minQty\":null,\"maxQty\":null,\"deletedWithProduct\":false,\"id\":20,\"tempId\":null,\"draftId\":null,\"revisionId\":null,\"isProvisionalDraft\":false,\"uid\":\"79d30fe9-776c-4f71-a1b7-d90db74ca8cd\",\"siteSettingsId\":20,\"fieldLayoutId\":6,\"contentId\":19,\"enabled\":true,\"archived\":false,\"siteId\":1,\"title\":\"Nomad Tumbler\",\"slug\":null,\"uri\":null,\"dateCreated\":\"2024-02-17T17:50:31-08:00\",\"dateUpdated\":\"2024-02-20T05:49:56-08:00\",\"dateLastMerged\":null,\"dateDeleted\":null,\"trashed\":false,\"validatingRelatedElement\":false,\"isNewForSite\":false,\"canonicalId\":20,\"isDraft\":false,\"isRevision\":false,\"isUnpublishedDraft\":false,\"ref\":null,\"status\":\"enabled\",\"structureId\":null,\"url\":\"https:\\/\\/sprig-training.ddev.site\\/products\\/nomad-tumbler?variant=20\",\"isAvailable\":true,\"isPromotable\":true,\"shippingCategoryId\":1,\"sku\":\"003\",\"taxCategoryId\":1,\"product\":{\"postDate\":\"2024-02-17T17:50:00-08:00\",\"expiryDate\":null,\"typeId\":1,\"taxCategoryId\":1,\"shippingCategoryId\":1,\"promotable\":true,\"freeShipping\":false,\"availableForPurchase\":true,\"defaultVariantId\":20,\"defaultSku\":\"003\",\"defaultPrice\":35,\"defaultHeight\":0,\"defaultLength\":0,\"defaultWidth\":0,\"defaultWeight\":0,\"taxCategory\":null,\"name\":null,\"id\":19,\"tempId\":null,\"draftId\":null,\"revisionId\":null,\"isProvisionalDraft\":false,\"uid\":\"2d807b48-d51c-4839-b8f3-9af9360a5353\",\"siteSettingsId\":19,\"fieldLayoutId\":3,\"contentId\":18,\"enabled\":true,\"archived\":false,\"siteId\":1,\"title\":\"Nomad Tumbler\",\"slug\":\"nomad-tumbler\",\"uri\":\"products\\/nomad-tumbler\",\"dateCreated\":\"2024-02-17T17:50:31-08:00\",\"dateUpdated\":\"2024-02-17T18:02:11-08:00\",\"dateLastMerged\":null,\"dateDeleted\":null,\"trashed\":false,\"validatingRelatedElement\":false,\"isNewForSite\":false,\"canonicalId\":19,\"isDraft\":false,\"isRevision\":false,\"isUnpublishedDraft\":false,\"ref\":null,\"status\":\"live\",\"structureId\":null,\"url\":\"https:\\/\\/sprig-training.ddev.site\\/products\\/nomad-tumbler\"},\"onSale\":false,\"cpEditUrl\":\"#\",\"description\":\"Nomad Tumbler - Nomad Tumbler\",\"purchasableId\":20,\"options\":[],\"sales\":[]}',NULL,'2024-02-20 15:39:03','2024-05-12 19:51:11','d54599d5-0241-461d-91d1-8529aa487a79');
/*!40000 ALTER TABLE `commerce_lineitems` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_lineitemstatuses`
--

LOCK TABLES `commerce_lineitemstatuses` WRITE;
/*!40000 ALTER TABLE `commerce_lineitemstatuses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_lineitemstatuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderadjustments`
--

LOCK TABLES `commerce_orderadjustments` WRITE;
/*!40000 ALTER TABLE `commerce_orderadjustments` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_orderadjustments` VALUES
(287,24,20,'tax','VAT','20%',6.4000,0,1,'{\"id\":1,\"name\":\"VAT\",\"code\":null,\"rate\":0.2,\"include\":false,\"removeIncluded\":false,\"removeVatIncluded\":false,\"isVat\":false,\"taxable\":\"price\",\"taxCategoryId\":1,\"isLite\":false,\"taxZoneId\":null,\"dateCreated\":\"2024-02-18T05:59:14-08:00\",\"dateUpdated\":\"2024-02-18T06:10:41-08:00\"}','2024-02-20 02:54:16','2024-02-20 02:54:16','72ab35cd-e696-4ba5-83cc-28e2c0ec7707'),
(288,24,19,'tax','VAT','20%',42.0000,0,1,'{\"id\":1,\"name\":\"VAT\",\"code\":null,\"rate\":0.2,\"include\":false,\"removeIncluded\":false,\"removeVatIncluded\":false,\"isVat\":false,\"taxable\":\"price\",\"taxCategoryId\":1,\"isLite\":false,\"taxZoneId\":null,\"dateCreated\":\"2024-02-18T05:59:14-08:00\",\"dateUpdated\":\"2024-02-18T06:10:41-08:00\"}','2024-02-20 02:54:16','2024-02-20 02:54:16','4dd0958f-3801-4713-af49-bae62212ef66'),
(372,35,21,'tax','VAT','20%',35.0000,0,1,'{\"id\":1,\"name\":\"VAT\",\"code\":null,\"rate\":0.2,\"include\":false,\"removeIncluded\":false,\"removeVatIncluded\":false,\"isVat\":false,\"taxable\":\"price\",\"taxCategoryId\":1,\"isLite\":false,\"taxZoneId\":null,\"dateCreated\":\"2024-02-18T05:59:14-08:00\",\"dateUpdated\":\"2024-02-18T06:10:41-08:00\"}','2024-05-12 19:51:10','2024-05-12 19:51:10','2ff7060c-d7a1-4ca7-a266-fec62699415e');
/*!40000 ALTER TABLE `commerce_orderadjustments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderhistories`
--

LOCK TABLES `commerce_orderhistories` WRITE;
/*!40000 ALTER TABLE `commerce_orderhistories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_orderhistories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_ordernotices`
--

LOCK TABLES `commerce_ordernotices` WRITE;
/*!40000 ALTER TABLE `commerce_ordernotices` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_ordernotices` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orders`
--

LOCK TABLES `commerce_orders` WRITE;
/*!40000 ALTER TABLE `commerce_orders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_orders` VALUES
(24,1,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL,'2ad073f27e61ec9415dd089d229b3eab',NULL,NULL,290.4000,242.0000,7,290.4000,290.4000,0.0000,0.0000,48.4000,0.0000,0.0000,'unpaid','support@putyourlightson.com',NULL,0,NULL,NULL,NULL,'USD','USD','192.168.166.1','en-US','web',NULL,0,0,0,'all',NULL,NULL,'','',1,'2024-02-18 02:26:41','2024-02-20 02:54:16','7497a131-98cb-4a6f-b708-3a5277a3cb1e',0.0000),
(35,1,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL,'188d68f4059df6d83747de07503873f5',NULL,NULL,210.0000,175.0000,5,210.0000,210.0000,0.0000,0.0000,35.0000,0.0000,0.0000,'unpaid','support@putyourlightson.com',NULL,0,NULL,NULL,NULL,'USD','USD','192.168.228.1','en-US','web',NULL,0,0,0,'all',NULL,NULL,'','',1,'2024-02-20 15:39:03','2024-05-12 19:51:10','0afe62b5-1f05-4f43-8141-b170cb1d99ae',0.0000);
/*!40000 ALTER TABLE `commerce_orders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderstatus_emails`
--

LOCK TABLES `commerce_orderstatus_emails` WRITE;
/*!40000 ALTER TABLE `commerce_orderstatus_emails` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_orderstatus_emails` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderstatuses`
--

LOCK TABLES `commerce_orderstatuses` WRITE;
/*!40000 ALTER TABLE `commerce_orderstatuses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_orderstatuses` VALUES
(1,'New','new','green',NULL,NULL,99,1,'2024-02-18 01:48:26','2024-02-18 01:48:26','a5992712-f8e7-40f9-a127-2b87b50eb960',1);
/*!40000 ALTER TABLE `commerce_orderstatuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_paymentcurrencies`
--

LOCK TABLES `commerce_paymentcurrencies` WRITE;
/*!40000 ALTER TABLE `commerce_paymentcurrencies` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_paymentcurrencies` VALUES
(1,1,'USD',1.0000,'2024-02-18 01:48:26','2024-02-18 01:48:26','ae71a8a5-738f-4b7a-8063-6b8625ac534c');
/*!40000 ALTER TABLE `commerce_paymentcurrencies` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_paymentsources`
--

LOCK TABLES `commerce_paymentsources` WRITE;
/*!40000 ALTER TABLE `commerce_paymentsources` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_paymentsources` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_pdfs`
--

LOCK TABLES `commerce_pdfs` WRITE;
/*!40000 ALTER TABLE `commerce_pdfs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_pdfs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_plans`
--

LOCK TABLES `commerce_plans` WRITE;
/*!40000 ALTER TABLE `commerce_plans` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_plans` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_products`
--

LOCK TABLES `commerce_products` WRITE;
/*!40000 ALTER TABLE `commerce_products` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_products` VALUES
(15,1,16,'2024-02-18 01:50:00',NULL,'001-1',32.0000,0.0000,0.0000,0.0000,0.0000,'2024-02-18 01:49:28','2024-05-15 14:51:20','cf4f1c47-1650-4da7-8a61-92bb7f3f228f'),
(17,1,18,'2024-02-18 01:50:00',NULL,'002',50.0000,0.0000,0.0000,0.0000,0.0000,'2024-02-18 01:50:11','2024-05-12 20:27:23','292a459c-b62f-469e-a258-b46db216def0'),
(19,1,20,'2024-02-18 01:50:00',NULL,'003',35.0000,0.0000,0.0000,0.0000,0.0000,'2024-02-18 01:50:31','2024-05-12 20:27:52','4610f773-9c0e-4ca3-99ff-0414f2033f32');
/*!40000 ALTER TABLE `commerce_products` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes`
--

LOCK TABLES `commerce_producttypes` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_producttypes` VALUES
(1,3,6,'Products','products',0,0,0,'{product.title}',1,'','','{product.title} - {title}','2024-02-18 01:49:10','2024-02-20 13:49:56','76ceebcf-6e96-4ed0-8792-e33851d9b8f1',NULL);
/*!40000 ALTER TABLE `commerce_producttypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes_shippingcategories`
--

LOCK TABLES `commerce_producttypes_shippingcategories` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_shippingcategories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_producttypes_shippingcategories` VALUES
(1,1,1,'2024-02-18 13:58:45','2024-02-18 13:58:45','4eec97a3-977e-45ea-8d45-011aac0470f3');
/*!40000 ALTER TABLE `commerce_producttypes_shippingcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes_sites`
--

LOCK TABLES `commerce_producttypes_sites` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_producttypes_sites` VALUES
(1,1,1,'products/{slug}','',1,'2024-02-18 01:49:10','2024-02-18 01:49:10','0bf11e9a-03e8-4a0e-aa46-e5b48aa29f4c');
/*!40000 ALTER TABLE `commerce_producttypes_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes_taxcategories`
--

LOCK TABLES `commerce_producttypes_taxcategories` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_taxcategories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_producttypes_taxcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_purchasables`
--

LOCK TABLES `commerce_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_purchasables` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_purchasables` VALUES
(13,'DONATION-CC4','Donation','2024-02-18 01:48:26','2024-02-18 01:48:26','aec9a605-5cad-4802-8df4-ca8caba75162',NULL,NULL,NULL,NULL,NULL),
(16,'001-1','Basic Tee - Basic Tee','2024-02-18 01:49:28','2024-05-12 20:20:55','39f6d82a-3567-4905-b32d-b57b292ddb9a',0.0000,0.0000,0.0000,0.0000,1),
(18,'002','Daily Journal - Daily Journal','2024-02-18 01:50:11','2024-05-12 20:20:55','a1d54fb4-7f45-40dc-b265-f81bd339e633',0.0000,0.0000,0.0000,0.0000,1),
(20,'003','Nomad Tumbler - Nomad Tumbler','2024-02-18 01:50:31','2024-05-12 20:20:55','2fdfc91c-bc30-411b-b6f2-5e44cb38b465',0.0000,0.0000,0.0000,0.0000,1),
(31,'001-2','Basic Tee - Basic Tee','2024-02-20 13:50:49','2024-05-12 20:20:55','3eff071c-9f28-4631-8598-05816bc1dd9d',0.0000,0.0000,0.0000,0.0000,1);
/*!40000 ALTER TABLE `commerce_purchasables` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_purchasables_stores`
--

LOCK TABLES `commerce_purchasables_stores` WRITE;
/*!40000 ALTER TABLE `commerce_purchasables_stores` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_purchasables_stores` VALUES
(1,16,1,32.0000,NULL,1,1,0,100,1,NULL,NULL,'2024-02-18 01:49:28','2024-05-12 20:20:57','0b6cf4f0-703d-4fd9-a611-97347e511dfb',1),
(2,31,1,35.0000,NULL,1,1,0,100,1,NULL,NULL,'2024-02-20 13:50:49','2024-05-12 20:20:57','0764f7a3-6e74-496d-9a1b-0ceba494cea3',1),
(3,18,1,50.0000,NULL,1,0,0,0,1,NULL,NULL,'2024-02-18 01:50:11','2024-05-12 20:20:57','e39b3566-8b06-4f60-8c21-228cd7f94f86',1),
(4,20,1,35.0000,NULL,1,1,0,50,1,NULL,NULL,'2024-02-18 01:50:31','2024-05-12 20:20:57','393d46e8-ca5c-455c-8f0d-447ee0a08aab',1),
(5,13,1,0.0000,NULL,0,1,1,NULL,1,NULL,NULL,'2024-05-12 20:20:55','2024-05-12 20:20:57','639d2a77-c98b-4d0b-91ea-8b45455dc0ff',NULL);
/*!40000 ALTER TABLE `commerce_purchasables_stores` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sale_categories`
--

LOCK TABLES `commerce_sale_categories` WRITE;
/*!40000 ALTER TABLE `commerce_sale_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sale_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sale_purchasables`
--

LOCK TABLES `commerce_sale_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_sale_purchasables` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sale_purchasables` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sale_usergroups`
--

LOCK TABLES `commerce_sale_usergroups` WRITE;
/*!40000 ALTER TABLE `commerce_sale_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sale_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sales`
--

LOCK TABLES `commerce_sales` WRITE;
/*!40000 ALTER TABLE `commerce_sales` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sales` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingcategories`
--

LOCK TABLES `commerce_shippingcategories` WRITE;
/*!40000 ALTER TABLE `commerce_shippingcategories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_shippingcategories` VALUES
(1,'General','general','',1,NULL,'2024-02-18 01:48:26','2024-05-12 20:20:56','fe84ad3a-1b3a-4657-960d-068d26937cfa',1);
/*!40000 ALTER TABLE `commerce_shippingcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingmethods`
--

LOCK TABLES `commerce_shippingmethods` WRITE;
/*!40000 ALTER TABLE `commerce_shippingmethods` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_shippingmethods` VALUES
(1,'Free Shipping','freeShipping',1,'2024-02-18 01:48:26','2024-05-12 20:20:56','0063ac3a-0d8e-4e0d-ae6c-78ecd9ccda6c',1,NULL);
/*!40000 ALTER TABLE `commerce_shippingmethods` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingrule_categories`
--

LOCK TABLES `commerce_shippingrule_categories` WRITE;
/*!40000 ALTER TABLE `commerce_shippingrule_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_shippingrule_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingrules`
--

LOCK TABLES `commerce_shippingrules` WRITE;
/*!40000 ALTER TABLE `commerce_shippingrules` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_shippingrules` VALUES
(1,NULL,1,'Free Everywhere','All countries, free shipping',0,1,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,'2024-02-18 01:48:26','2024-02-18 01:48:26','fbbea4d9-35b7-45a2-bf6a-109ef018a78e',NULL);
/*!40000 ALTER TABLE `commerce_shippingrules` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingzones`
--

LOCK TABLES `commerce_shippingzones` WRITE;
/*!40000 ALTER TABLE `commerce_shippingzones` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_shippingzones` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_site_stores`
--

LOCK TABLES `commerce_site_stores` WRITE;
/*!40000 ALTER TABLE `commerce_site_stores` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_site_stores` VALUES
(1,1,'2024-05-12 20:20:56','2024-05-12 20:20:56','bd3a4e55-c4e4-473f-8a85-dd23d31febdf');
/*!40000 ALTER TABLE `commerce_site_stores` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_stores`
--

LOCK TABLES `commerce_stores` WRITE;
/*!40000 ALTER TABLE `commerce_stores` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_stores` VALUES
(1,'2024-02-18 01:48:26','2024-05-12 20:20:57','e7b0d812-496a-462a-b37a-b6ecee3ba260',0,0,0,0,0,0,0,0,0,0,0,'{{number[:7]}}','complete','default','Primary Store','primaryStore',1,99,'USD');
/*!40000 ALTER TABLE `commerce_stores` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_storesettings`
--

LOCK TABLES `commerce_storesettings` WRITE;
/*!40000 ALTER TABLE `commerce_storesettings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_storesettings` VALUES
(1,14,'[\"US\"]',NULL,'2024-05-12 20:20:56','2024-05-12 20:20:56','a2b65071-cbf7-480b-88a2-f198db1604dc');
/*!40000 ALTER TABLE `commerce_storesettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_subscriptions`
--

LOCK TABLES `commerce_subscriptions` WRITE;
/*!40000 ALTER TABLE `commerce_subscriptions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_taxcategories`
--

LOCK TABLES `commerce_taxcategories` WRITE;
/*!40000 ALTER TABLE `commerce_taxcategories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_taxcategories` VALUES
(1,'General','general',NULL,1,NULL,'2024-02-18 01:48:26','2024-02-18 01:48:26','cd9006b3-93e4-43a3-96f7-3eca583c65b5');
/*!40000 ALTER TABLE `commerce_taxcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_taxrates`
--

LOCK TABLES `commerce_taxrates` WRITE;
/*!40000 ALTER TABLE `commerce_taxrates` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_taxrates` VALUES
(1,NULL,1,1,'VAT','',0.2000000000,0,0,0,0,'price','2024-02-18 13:59:14','2024-02-18 14:10:41','eaa40052-e625-4e0a-8140-4bb13b688bd2',1);
/*!40000 ALTER TABLE `commerce_taxrates` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_taxzones`
--

LOCK TABLES `commerce_taxzones` WRITE;
/*!40000 ALTER TABLE `commerce_taxzones` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_taxzones` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_transactions`
--

LOCK TABLES `commerce_transactions` WRITE;
/*!40000 ALTER TABLE `commerce_transactions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_transactions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_transfers`
--

LOCK TABLES `commerce_transfers` WRITE;
/*!40000 ALTER TABLE `commerce_transfers` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_transfers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_transfers_inventoryitems`
--

LOCK TABLES `commerce_transfers_inventoryitems` WRITE;
/*!40000 ALTER TABLE `commerce_transfers_inventoryitems` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_transfers_inventoryitems` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_variants`
--

LOCK TABLES `commerce_variants` WRITE;
/*!40000 ALTER TABLE `commerce_variants` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_variants` VALUES
(16,15,1,0,'2024-02-18 01:49:28','2024-02-20 13:52:28','f74ab776-fa05-40dd-993d-be377e36e6ed'),
(18,17,1,0,'2024-02-18 01:50:11','2024-02-20 13:49:56','230bef6a-a4c8-4fbb-bcef-0f1ebf9e3afa'),
(20,19,1,0,'2024-02-18 01:50:31','2024-02-20 13:49:56','c992a642-382f-4632-aaee-f485b70cb04b'),
(31,15,0,0,'2024-02-20 13:50:49','2024-02-20 13:52:28','8e771f09-5603-485e-801b-a7e41196a819');
/*!40000 ALTER TABLE `commerce_variants` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES
(6,NULL,1,0,'First draft',NULL,0,NULL,0),
(12,40,1,1,'Draft 1','',1,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES
(1,1,1,NULL,'view','2024-05-15 07:48:25'),
(2,1,1,NULL,'save','2024-01-12 15:12:11'),
(4,1,1,NULL,'edit','2024-01-12 15:12:04'),
(4,1,1,NULL,'save','2024-01-12 15:12:05'),
(6,1,1,NULL,'save','2024-01-12 01:00:52'),
(15,1,1,NULL,'edit','2024-05-15 14:51:19'),
(15,1,1,NULL,'save','2024-05-15 14:51:20'),
(15,1,1,NULL,'view','2024-05-15 16:04:05'),
(17,1,1,NULL,'edit','2024-05-12 20:27:23'),
(17,1,1,NULL,'save','2024-05-12 20:27:23'),
(17,1,1,NULL,'view','2024-05-12 20:27:24'),
(19,1,1,NULL,'edit','2024-05-12 20:27:52'),
(19,1,1,NULL,'save','2024-05-12 20:27:52'),
(19,1,1,NULL,'view','2024-05-12 20:32:39'),
(21,1,1,NULL,'view','2024-05-15 07:39:30'),
(32,1,1,NULL,'view','2024-02-20 15:20:50'),
(39,1,1,NULL,'edit','2024-05-15 13:26:00'),
(39,1,1,NULL,'save','2024-05-15 13:26:01'),
(39,1,1,NULL,'view','2024-05-15 16:04:07'),
(40,1,1,NULL,'edit','2024-05-15 07:47:00'),
(40,1,1,NULL,'save','2024-05-15 07:46:59'),
(46,1,1,NULL,'save','2024-05-15 13:25:58'),
(50,1,1,NULL,'save','2024-05-15 13:26:19'),
(50,1,1,NULL,'view','2024-05-15 13:26:19'),
(51,1,1,NULL,'save','2024-05-15 13:26:16');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES
(1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-01-12 00:57:57','2024-02-20 16:29:42',NULL,NULL,NULL,'fb14500c-2493-4528-8791-c04378420b9e'),
(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-12 01:00:19','2024-01-12 15:12:11',NULL,NULL,NULL,'8b413064-4ad3-48f3-a393-440eccdb678e'),
(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-01-12 01:00:36','2024-01-12 01:00:36',NULL,NULL,NULL,'c9c6ff36-237e-4358-ad0f-c7913795e8c1'),
(4,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-12 01:00:36','2024-01-12 15:12:05',NULL,NULL,NULL,'6455b74a-78ce-407e-ae41-2fe7f455510c'),
(5,4,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-01-12 01:00:44','2024-01-12 01:00:44',NULL,NULL,NULL,'795c1bcc-5ab5-4f18-bd59-ac6708e6effe'),
(6,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-01-12 01:00:44','2024-01-12 01:00:52',NULL,NULL,NULL,'833ee01b-3e7a-4aec-9ba3-0d172f008642'),
(7,6,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-01-12 01:00:52','2024-01-12 01:00:52',NULL,NULL,NULL,'93eb2a31-0c5b-4814-9b50-46eb6ca0c3b1'),
(9,4,NULL,4,1,'craft\\elements\\Entry',1,0,'2024-01-12 15:12:05','2024-01-12 15:12:05',NULL,NULL,NULL,'c2918659-d835-493a-ab10-4e1a2490ca19'),
(10,2,NULL,5,1,'craft\\elements\\Entry',1,0,'2024-01-12 15:12:11','2024-01-12 15:12:11',NULL,NULL,NULL,'c2917c00-8fbc-48d5-a7f4-ce51a4515a96'),
(13,NULL,NULL,NULL,NULL,'craft\\commerce\\elements\\Donation',1,0,'2024-02-18 01:48:26','2024-02-18 01:48:26',NULL,NULL,NULL,'e2eb6acf-b28d-4da5-8ba2-7774be747181'),
(14,NULL,NULL,NULL,NULL,'craft\\elements\\Address',1,0,'2024-02-18 01:48:33','2024-02-18 01:48:33',NULL,NULL,NULL,'20e849cf-10d2-4731-b11f-22741a6572b3'),
(15,NULL,NULL,NULL,3,'craft\\commerce\\elements\\Product',1,0,'2024-02-18 01:49:28','2024-05-15 14:51:20',NULL,NULL,NULL,'aef04d6b-6604-43bd-adbd-4c640444c244'),
(16,NULL,NULL,NULL,6,'craft\\commerce\\elements\\Variant',1,0,'2024-02-18 01:49:28','2024-02-20 13:52:28',NULL,NULL,NULL,'3b129011-3ed9-4662-964b-239dc8000525'),
(17,NULL,NULL,NULL,3,'craft\\commerce\\elements\\Product',1,0,'2024-02-18 01:50:11','2024-05-12 20:27:23',NULL,NULL,NULL,'9094b2ed-70ea-468c-9b5f-2d3c678a2105'),
(18,NULL,NULL,NULL,6,'craft\\commerce\\elements\\Variant',1,0,'2024-02-18 01:50:11','2024-02-20 13:49:56',NULL,NULL,NULL,'d48bc4d4-6092-42e6-a57c-aa0db6486264'),
(19,NULL,NULL,NULL,3,'craft\\commerce\\elements\\Product',1,0,'2024-02-18 01:50:31','2024-05-12 20:27:52',NULL,NULL,NULL,'2d807b48-d51c-4839-b8f3-9af9360a5353'),
(20,NULL,NULL,NULL,6,'craft\\commerce\\elements\\Variant',1,0,'2024-02-18 01:50:31','2024-02-20 13:49:56',NULL,NULL,NULL,'79d30fe9-776c-4f71-a1b7-d90db74ca8cd'),
(21,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2024-02-18 02:01:36','2024-02-18 02:01:36',NULL,NULL,NULL,'7f00268e-cfb7-4ff2-be72-ce2732f589e9'),
(22,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2024-02-18 02:01:36','2024-02-18 02:01:36',NULL,NULL,NULL,'9c4cf794-e77f-4b69-ba93-51a2c16fd215'),
(23,NULL,NULL,NULL,5,'craft\\elements\\Asset',1,0,'2024-02-18 02:01:36','2024-02-18 02:01:36',NULL,NULL,NULL,'c26f1f20-44f7-4390-8da7-63ce49e507dc'),
(24,NULL,NULL,NULL,2,'craft\\commerce\\elements\\Order',1,0,'2024-02-18 02:26:41','2024-02-20 02:54:16',NULL,'2024-02-20 13:46:43',NULL,'d7055081-ecad-41c5-b50e-7cb4e72fdbb8'),
(25,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-02-18 14:52:15','2024-02-18 14:52:15',NULL,'2024-02-18 15:13:33',NULL,'beb73cca-5471-40ae-97b9-9dba1f672c30'),
(26,25,NULL,7,1,'craft\\elements\\Entry',1,0,'2024-02-18 14:52:15','2024-02-18 14:52:15',NULL,'2024-02-18 15:13:33',NULL,'1da3b993-e29b-4ba9-bf46-ea0c768e12f0'),
(27,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-02-18 14:52:52','2024-02-18 14:52:52',NULL,'2024-02-18 15:13:33',NULL,'4dbbde25-d6f0-4194-ab47-ff8e256e0351'),
(28,27,NULL,8,1,'craft\\elements\\Entry',1,0,'2024-02-18 14:52:52','2024-02-18 14:52:52',NULL,'2024-02-18 15:13:33',NULL,'5a537254-71db-4d8f-8f83-b168ef5358a9'),
(29,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-02-18 14:53:46','2024-02-18 14:53:46',NULL,'2024-02-18 15:19:29',NULL,'44658bc6-3b34-427b-8f00-67d6498a0c59'),
(30,29,NULL,9,1,'craft\\elements\\Entry',1,0,'2024-02-18 14:53:46','2024-02-18 14:53:46',NULL,'2024-02-18 15:19:29',NULL,'b7a082f6-f5d3-4e52-bb6e-6bf5e1160054'),
(31,NULL,NULL,NULL,6,'craft\\commerce\\elements\\Variant',1,0,'2024-02-20 13:50:49','2024-02-20 13:52:28',NULL,NULL,NULL,'e8574ef8-6b57-4348-81ed-e11374edb600'),
(32,NULL,6,NULL,1,'craft\\elements\\Entry',1,0,'2024-02-20 15:11:25','2024-02-20 15:11:25',NULL,NULL,NULL,'2e11daa0-e444-46bc-a748-410c3020353c'),
(33,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-02-20 15:20:34','2024-02-20 15:20:34',NULL,NULL,NULL,'3db82847-7497-4307-8b67-faf246aa9f71'),
(34,33,NULL,10,1,'craft\\elements\\Entry',1,0,'2024-02-20 15:20:34','2024-02-20 15:20:34',NULL,NULL,NULL,'eb5e3fd1-ad39-409a-b84c-c76634565651'),
(35,NULL,NULL,NULL,2,'craft\\commerce\\elements\\Order',1,0,'2024-02-20 15:39:03','2024-05-12 19:51:10',NULL,NULL,NULL,'fd52a44c-70d9-4995-9f51-f4a648c35920'),
(39,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2024-05-15 07:46:20','2024-05-15 13:26:01',NULL,NULL,NULL,'1288d780-4666-46e9-b6dc-91cb4f3f0169'),
(40,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2024-05-15 07:46:28','2024-05-15 07:46:59',NULL,NULL,NULL,'93001158-1edc-421e-9e28-f87609fde444'),
(41,40,NULL,11,8,'craft\\elements\\Entry',1,0,'2024-05-15 07:46:46','2024-05-15 07:46:46',NULL,NULL,NULL,'05299e86-ce4e-475f-a78b-2685cd60de2e'),
(42,40,NULL,12,8,'craft\\elements\\Entry',1,0,'2024-05-15 07:46:59','2024-05-15 07:46:59',NULL,NULL,NULL,'aee1767d-9537-470a-9f28-e34ac93f876f'),
(43,40,12,NULL,8,'craft\\elements\\Entry',1,0,'2024-05-15 07:47:00','2024-05-15 07:47:00',NULL,NULL,NULL,'4032db35-c1c1-4e69-afc8-4be8ed1af75c'),
(44,39,NULL,13,7,'craft\\elements\\Entry',1,0,'2024-05-15 07:47:03','2024-05-15 07:47:03',NULL,NULL,NULL,'99aa76c1-9c2f-4109-836f-2fff189459b4'),
(46,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2024-05-15 13:25:49','2024-05-15 13:25:58',NULL,NULL,NULL,'a6cb1185-080c-4fd6-ae12-f3e9f2771afa'),
(47,46,NULL,14,8,'craft\\elements\\Entry',1,0,'2024-05-15 13:25:58','2024-05-15 13:25:58',NULL,NULL,NULL,'d29af301-7bf9-4479-afac-529af6be446c'),
(49,39,NULL,15,7,'craft\\elements\\Entry',1,0,'2024-05-15 13:26:01','2024-05-15 13:26:01',NULL,NULL,NULL,'de0c8a4e-91e6-44e9-8a2f-77dc4f045b08'),
(50,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2024-05-15 13:26:03','2024-05-15 13:26:19',NULL,NULL,NULL,'c695c9fa-87f7-4f56-a085-2c51bb823e56'),
(51,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2024-05-15 13:26:12','2024-05-15 13:26:16',NULL,NULL,NULL,'8135e6ed-fc32-4c07-be4f-1e17dbc2dced'),
(52,51,NULL,16,8,'craft\\elements\\Entry',1,0,'2024-05-15 13:26:16','2024-05-15 13:26:16',NULL,NULL,NULL,'2c396ffa-f0bc-421c-877f-b4465fdd53f5'),
(53,50,NULL,17,7,'craft\\elements\\Entry',1,0,'2024-05-15 13:26:19','2024-05-15 13:26:19',NULL,NULL,NULL,'3290947c-6a74-4f33-90e7-6732aeef2503');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_owners` VALUES
(16,15,1),
(18,17,1),
(20,19,1),
(31,15,2);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES
(1,1,1,NULL,NULL,NULL,NULL,1,'2024-01-12 00:57:57','2024-01-12 00:57:57','1fd9caa5-3fd3-4a96-9f40-2c57f1c0e42f'),
(2,2,1,'Introducing Blitz Diagnostics','introducing-blitz-diagnostics','articles/introducing-blitz-diagnostics',NULL,1,'2024-01-12 01:00:19','2024-01-12 01:00:33','a5114fd0-0ab5-4ef2-9371-53a4405c8d8a'),
(3,3,1,'Introducing Blitz Diagnostics','introducing-blitz-diagnostics','articles/introducing-blitz-diagnostics',NULL,1,'2024-01-12 01:00:36','2024-01-12 01:00:36','6a63f1a8-e8ff-4abd-aec4-f100cbc2be36'),
(4,4,1,'Queue Runners and Custom Queues in Craft CMS','queue-runners-and-custom-queues-in-craft-cms','articles/queue-runners-and-custom-queues-in-craft-cms',NULL,1,'2024-01-12 01:00:36','2024-01-12 01:00:44','c0e53b1b-8588-4a9c-a33e-15ce08274c55'),
(5,5,1,'Queue Runners and Custom Queues in Craft CMS','queue-runners-and-custom-queues-in-craft-cms','articles/queue-runners-and-custom-queues-in-craft-cms',NULL,1,'2024-01-12 01:00:44','2024-01-12 01:00:44','16a3ddb7-0c51-4866-9a12-62a1464b1b66'),
(6,6,1,'htmx has a JavaScript API, btw','htmx-has-a-javascript-api-btw','articles/htmx-has-a-javascript-api-btw',NULL,1,'2024-01-12 01:00:44','2024-01-12 01:00:52','f8757ea4-3176-414e-a837-977a3ebb79d4'),
(7,7,1,'htmx has a JavaScript API, btw','htmx-has-a-javascript-api-btw','articles/htmx-has-a-javascript-api-btw',NULL,1,'2024-01-12 01:00:52','2024-01-12 01:00:52','13d30fec-a63d-4261-be72-b39e48b388b9'),
(9,9,1,'Queue Runners and Custom Queues in Craft CMS','queue-runners-and-custom-queues-in-craft-cms','articles/queue-runners-and-custom-queues-in-craft-cms',NULL,1,'2024-01-12 15:12:05','2024-01-12 15:12:05','88fa443d-8253-4f86-98d9-822533554faf'),
(10,10,1,'Introducing Blitz Diagnostics','introducing-blitz-diagnostics','articles/introducing-blitz-diagnostics',NULL,1,'2024-01-12 15:12:11','2024-01-12 15:12:11','5722b4eb-94e8-4d8f-87d3-438791934916'),
(13,13,1,NULL,NULL,NULL,NULL,1,'2024-02-18 01:48:26','2024-02-18 01:48:26','212f5679-2410-4622-9e2d-3ba44a30ab25'),
(14,14,1,'Store',NULL,NULL,NULL,1,'2024-02-18 01:48:33','2024-02-18 01:48:33','ad3c1a99-20f2-4e17-98cf-7fce895b0925'),
(15,15,1,'Basic Tee','basic-tee','products/basic-tee','{\"89927820-c649-4415-836e-5e969370d306\": [\"cotton\", \"elastic\"], \"9993725b-6c75-43ae-aaaf-cf374499f2f4\": \"yellow\"}',1,'2024-02-18 01:49:28','2024-05-15 14:51:20','a25290a2-1de4-4606-b206-e599acbd78ed'),
(16,16,1,'Basic Tee',NULL,NULL,'{\"6976c542-7895-445e-a7cc-984f83edc4db\": \"Yellow\"}',1,'2024-02-18 01:49:28','2024-02-18 01:49:28','836f9c24-2ab0-462c-8ddb-937ad67ed6b8'),
(17,17,1,'Daily Journal','daily-journal','products/daily-journal','{\"9993725b-6c75-43ae-aaaf-cf374499f2f4\": \"black\"}',1,'2024-02-18 01:50:11','2024-05-12 20:27:23','8d7ccbd1-ea87-4f01-87c2-00b6658351ef'),
(18,18,1,'Daily Journal',NULL,NULL,NULL,1,'2024-02-18 01:50:11','2024-02-18 01:50:11','b5bf3a9c-189c-4338-8cab-a8d7e7f37a2a'),
(19,19,1,'Nomad Tumbler','nomad-tumbler','products/nomad-tumbler','{\"9993725b-6c75-43ae-aaaf-cf374499f2f4\": \"white\"}',1,'2024-02-18 01:50:31','2024-05-12 20:27:52','ed6796c9-b2d6-4b92-9f50-47bb98d90a4c'),
(20,20,1,'Nomad Tumbler',NULL,NULL,NULL,1,'2024-02-18 01:50:31','2024-02-18 01:50:31','52e6222a-9d71-4407-911e-689974a71ce1'),
(21,21,1,'Shopping cart page 01 product 01',NULL,NULL,NULL,1,'2024-02-18 02:01:36','2024-02-18 02:01:36','37bb423f-63c6-4861-875b-066c360603d0'),
(22,22,1,'Shopping cart page 01 product 02',NULL,NULL,NULL,1,'2024-02-18 02:01:36','2024-02-18 02:01:36','207aac04-3fee-4453-9f0a-d18cd0de7b90'),
(23,23,1,'Shopping cart page 01 product 03',NULL,NULL,NULL,1,'2024-02-18 02:01:36','2024-02-18 02:01:36','848b4ac4-ebaa-4b67-bf67-4b1b2672c3ad'),
(24,24,1,NULL,NULL,NULL,NULL,1,'2024-02-18 02:26:41','2024-02-18 02:26:41','14b8c203-be2b-42d4-bb2d-312822cb56c2'),
(25,25,1,'sd','sd','articles/sd',NULL,1,'2024-02-18 14:52:15','2024-02-18 14:52:15','3fa1a9f0-09a8-4449-a12d-743fb297b748'),
(26,26,1,'sd','sd','articles/sd',NULL,1,'2024-02-18 14:52:15','2024-02-18 14:52:15','f6c4a024-1549-4504-8774-ae7e082b0874'),
(27,27,1,'sd','sd-2','articles/sd-2',NULL,1,'2024-02-18 14:52:52','2024-02-18 14:52:52','75de2a4b-6025-4f04-adb9-ee7e6b8a588c'),
(28,28,1,'sd','sd-2','articles/sd-2',NULL,1,'2024-02-18 14:52:52','2024-02-18 14:52:52','7a1b21c0-551e-4246-958f-0e158eeb602a'),
(29,29,1,'www','www','articles/www',NULL,1,'2024-02-18 14:53:46','2024-02-18 14:53:46','7af944cd-aa0c-4ee4-8609-696dcdbfd4e8'),
(30,30,1,'www','www','articles/www',NULL,1,'2024-02-18 14:53:46','2024-02-18 14:53:46','3da04629-6390-4b12-876a-9fefe3264a69'),
(31,31,1,'Basic Tee',NULL,NULL,'{\"6976c542-7895-445e-a7cc-984f83edc4db\": \"Blue\"}',1,'2024-02-20 13:50:49','2024-02-20 13:50:49','2a65a14f-2155-4785-a7dd-c474ea0c3c4e'),
(32,32,1,NULL,'__temp_yssakckqgqgfmndqnvbziqqpzsqroysjekwn','articles/__temp_yssakckqgqgfmndqnvbziqqpzsqroysjekwn',NULL,1,'2024-02-20 15:11:25','2024-02-20 15:11:25','f559103a-5204-47ab-9836-ea8dd9fbcd87'),
(33,33,1,'Hola','hola','articles/hola','{\"11208a81-822c-4a1f-9082-cf5377d61a06\": \"ABC\"}',1,'2024-02-20 15:20:34','2024-02-20 15:20:34','24766987-3363-4a20-81e7-43abf551cbdf'),
(34,34,1,'Hola','hola','articles/hola','{\"11208a81-822c-4a1f-9082-cf5377d61a06\": \"ABC\"}',1,'2024-02-20 15:20:34','2024-02-20 15:20:34','3b7cc595-0e98-41d4-8b94-5b21e41ac5a0'),
(35,35,1,NULL,NULL,NULL,NULL,1,'2024-02-20 15:39:03','2024-02-20 15:39:03','99ee9c8f-a7ef-403c-a206-8c112808bc84'),
(39,39,1,'No Name','no-name','brands/no-name',NULL,1,'2024-05-15 07:46:20','2024-05-15 07:46:26','51022eeb-d4da-41dd-b489-80bc9a6a7660'),
(40,40,1,'France','paris-france','locations/paris-france',NULL,1,'2024-05-15 07:46:28','2024-05-15 07:46:59','3f0bf8e2-4246-4764-ad21-fd7b40705112'),
(41,41,1,'Paris, France','paris-france','locations/paris-france',NULL,1,'2024-05-15 07:46:46','2024-05-15 07:46:46','de42400b-79da-4563-aeab-f6f97f8cb648'),
(42,42,1,'France','paris-france','locations/paris-france',NULL,1,'2024-05-15 07:46:59','2024-05-15 07:46:59','2f3724ac-c2f8-4091-9ef9-07070acf38b4'),
(43,43,1,'France','paris-france','locations/paris-france',NULL,1,'2024-05-15 07:47:00','2024-05-15 07:47:00','f944543d-cb3f-443c-a370-65630bee9520'),
(44,44,1,'No Name','no-name','brands/no-name',NULL,1,'2024-05-15 07:47:03','2024-05-15 07:47:03','9f26c115-905f-4537-bf1f-e341710b6a18'),
(46,46,1,'Poland','poland','locations/poland',NULL,1,'2024-05-15 13:25:49','2024-05-15 13:25:58','cf9b9373-5464-422d-b715-5cc13d386981'),
(47,47,1,'Poland','poland','locations/poland',NULL,1,'2024-05-15 13:25:58','2024-05-15 13:25:58','fae92fe5-2694-49f0-a8da-7b7d2fcd37af'),
(49,49,1,'No Name','no-name','brands/no-name',NULL,1,'2024-05-15 13:26:01','2024-05-15 13:26:01','57120f7d-5dab-4a88-a61c-626d51e87cf7'),
(50,50,1,'Fashionista','fashionista','brands/fashionista',NULL,1,'2024-05-15 13:26:03','2024-05-15 13:26:10','8ecfd097-1565-449a-a4e5-0ad610dc7c80'),
(51,51,1,'Italy','italy','locations/italy',NULL,1,'2024-05-15 13:26:12','2024-05-15 13:26:16','c6b03697-5ab3-4884-a548-de01d7cecc5b'),
(52,52,1,'Italy','italy','locations/italy',NULL,1,'2024-05-15 13:26:16','2024-05-15 13:26:16','386bb1f0-f659-4a55-9d82-8ea8a31e2539'),
(53,53,1,'Fashionista','fashionista','brands/fashionista',NULL,1,'2024-05-15 13:26:19','2024-05-15 13:26:19','2daaaace-88b4-4ce4-bb2e-10300c6e444c');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES
(2,1,NULL,NULL,NULL,1,'2024-01-12 01:02:00',NULL,NULL,'2024-01-12 01:00:19','2024-01-12 15:12:11'),
(3,1,NULL,NULL,NULL,1,'2024-01-12 01:00:00',NULL,NULL,'2024-01-12 01:00:36','2024-01-12 01:00:36'),
(4,1,NULL,NULL,NULL,1,'2024-01-12 01:01:00',NULL,NULL,'2024-01-12 01:00:36','2024-01-12 15:12:05'),
(5,1,NULL,NULL,NULL,1,'2024-01-12 01:00:00',NULL,NULL,'2024-01-12 01:00:44','2024-01-12 01:00:44'),
(6,1,NULL,NULL,NULL,1,'2024-01-12 01:00:00',NULL,NULL,'2024-01-12 01:00:44','2024-01-12 01:00:52'),
(7,1,NULL,NULL,NULL,1,'2024-01-12 01:00:00',NULL,NULL,'2024-01-12 01:00:52','2024-01-12 01:00:52'),
(9,1,NULL,NULL,NULL,1,'2024-01-12 01:01:00',NULL,NULL,'2024-01-12 15:12:05','2024-01-12 15:12:05'),
(10,1,NULL,NULL,NULL,1,'2024-01-12 01:02:00',NULL,NULL,'2024-01-12 15:12:11','2024-01-12 15:12:11'),
(25,1,NULL,NULL,NULL,1,'2024-02-18 14:52:00',NULL,0,'2024-02-18 14:52:15','2024-02-18 14:52:15'),
(26,1,NULL,NULL,NULL,1,'2024-02-18 14:52:00',NULL,NULL,'2024-02-18 14:52:15','2024-02-18 14:52:15'),
(27,1,NULL,NULL,NULL,1,'2024-02-18 14:52:00',NULL,0,'2024-02-18 14:52:52','2024-02-18 14:52:52'),
(28,1,NULL,NULL,NULL,1,'2024-02-18 14:52:00',NULL,NULL,'2024-02-18 14:52:52','2024-02-18 14:52:52'),
(29,1,NULL,NULL,NULL,1,'2024-02-18 14:53:00',NULL,0,'2024-02-18 14:53:46','2024-02-18 14:53:46'),
(30,1,NULL,NULL,NULL,1,'2024-02-18 14:53:00',NULL,NULL,'2024-02-18 14:53:46','2024-02-18 14:53:46'),
(32,1,NULL,NULL,NULL,1,'2024-02-20 15:11:25',NULL,NULL,'2024-02-20 15:11:25','2024-02-20 15:11:25'),
(33,1,NULL,NULL,NULL,1,'2024-02-20 15:20:00',NULL,NULL,'2024-02-20 15:20:34','2024-02-20 15:20:34'),
(34,1,NULL,NULL,NULL,1,'2024-02-20 15:20:00',NULL,NULL,'2024-02-20 15:20:34','2024-02-20 15:20:34'),
(39,2,NULL,NULL,NULL,2,'2024-05-15 07:47:00',NULL,NULL,'2024-05-15 07:46:20','2024-05-15 07:47:03'),
(40,3,NULL,NULL,NULL,3,'2024-05-15 07:46:00',NULL,NULL,'2024-05-15 07:46:28','2024-05-15 07:46:46'),
(41,3,NULL,NULL,NULL,3,'2024-05-15 07:46:00',NULL,NULL,'2024-05-15 07:46:46','2024-05-15 07:46:46'),
(42,3,NULL,NULL,NULL,3,'2024-05-15 07:46:00',NULL,NULL,'2024-05-15 07:46:59','2024-05-15 07:46:59'),
(43,3,NULL,NULL,NULL,3,'2024-05-15 07:46:00',NULL,NULL,'2024-05-15 07:47:00','2024-05-15 07:47:00'),
(44,2,NULL,NULL,NULL,2,'2024-05-15 07:47:00',NULL,NULL,'2024-05-15 07:47:03','2024-05-15 07:47:03'),
(46,3,NULL,NULL,NULL,3,'2024-05-15 13:25:00',NULL,NULL,'2024-05-15 13:25:49','2024-05-15 13:25:58'),
(47,3,NULL,NULL,NULL,3,'2024-05-15 13:25:00',NULL,NULL,'2024-05-15 13:25:58','2024-05-15 13:25:58'),
(49,2,NULL,NULL,NULL,2,'2024-05-15 07:47:00',NULL,NULL,'2024-05-15 13:26:01','2024-05-15 13:26:01'),
(50,2,NULL,NULL,NULL,2,'2024-05-15 13:26:00',NULL,NULL,'2024-05-15 13:26:03','2024-05-15 13:26:19'),
(51,3,NULL,NULL,NULL,3,'2024-05-15 13:26:00',NULL,NULL,'2024-05-15 13:26:12','2024-05-15 13:26:16'),
(52,3,NULL,NULL,NULL,3,'2024-05-15 13:26:00',NULL,NULL,'2024-05-15 13:26:16','2024-05-15 13:26:16'),
(53,2,NULL,NULL,NULL,2,'2024-05-15 13:26:00',NULL,NULL,'2024-05-15 13:26:19','2024-05-15 13:26:19');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES
(2,1,1),
(3,1,1),
(4,1,1),
(5,1,1),
(6,1,1),
(7,1,1),
(9,1,1),
(10,1,1),
(25,1,1),
(26,1,1),
(27,1,1),
(28,1,1),
(29,1,1),
(30,1,1),
(32,1,1),
(33,1,1),
(34,1,1),
(39,1,1),
(40,1,1),
(41,1,1),
(42,1,1),
(43,1,1),
(44,1,1),
(46,1,1),
(47,1,1),
(49,1,1),
(50,1,1),
(51,1,1),
(52,1,1),
(53,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES
(1,1,'Default','default',NULL,NULL,1,'site',NULL,NULL,1,'site',NULL,1,'2024-01-12 00:59:58','2024-01-12 00:59:58',NULL,'b1797aea-7808-418c-a68b-1cb07b2b1c7c'),
(2,7,'Brand','brand','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-05-15 07:43:43','2024-05-15 07:43:43',NULL,'36cba068-6c7e-426b-9fad-d99775b88e98'),
(3,8,'Country','country','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-05-15 07:44:48','2024-05-15 07:47:53',NULL,'4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES
(1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"ae65bd66-20ea-461c-b432-6500f8040665\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"61f12749-7ee4-4498-8751-eff81c38a3ec\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"11208a81-822c-4a1f-9082-cf5377d61a06\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"0b2826e6-4b3f-47c6-a726-df613dcdd607\", \"required\": true, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-01-12 00:59:58','2024-05-12 20:20:54',NULL,'b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f'),
(2,'craft\\commerce\\elements\\Order',NULL,'2024-02-18 01:48:26','2024-02-18 01:48:26',NULL,'56a3b3f1-6f58-406f-a84e-9fc6384d4bd5'),
(3,'craft\\commerce\\elements\\Product','{\"tabs\": [{\"uid\": \"a7cd4d02-6bd5-412d-a716-8006b28c5a61\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"e72f9176-462e-488e-a563-2bbfab3987fe\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\ProductTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"c2b63f9e-e23e-47b6-8ac2-10e82f1ca371\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"eb6c8b6c-8a32-42a9-9ab0-97414e63933d\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"9993725b-6c75-43ae-aaaf-cf374499f2f4\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"57dcd468-699f-4123-94e0-7ef4f7c608fa\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"89927820-c649-4415-836e-5e969370d306\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"99d30c67-07aa-47f4-9559-744b5337fdfe\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"22de9eb7-2bce-4648-bcba-8a9a3e40b061\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"538464ce-c5c0-49ae-badb-fa161b18063c\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"49cdbf38-5e25-487e-8ce7-ea68f4246d80\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"0b2826e6-4b3f-47c6-a726-df613dcdd607\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"id\": null, \"tip\": null, \"uid\": \"cac72456-60b5-4587-849e-c2ee4c0943e7\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantsField\", \"label\": null, \"warning\": null, \"required\": false, \"attribute\": \"variants\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-02-18 01:49:10','2024-05-15 14:51:15',NULL,'be72b007-b301-4d30-82d7-53a0ed9a22ec'),
(4,'craft\\commerce\\elements\\Variant',NULL,'2024-02-18 01:51:06','2024-02-18 01:51:06','2024-02-18 01:51:40','db753ca5-cc9f-4885-8f89-e3033e464d55'),
(5,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"a9e0c9ae-8727-4326-92b0-85b1edd57abf\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"2050d249-feab-4399-b97a-8bdc5951c673\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-02-18 02:00:28','2024-05-12 20:20:54',NULL,'787bc790-e1ed-44a9-9bab-92640ab09ac5'),
(6,'craft\\commerce\\elements\\Variant','{\"tabs\": [{\"uid\": \"828f2570-6e7c-4ce8-b040-9b89c681cdde\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"tip\": null, \"uid\": \"d14286cf-7500-4425-b8ef-7c6337a87f5d\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableSkuField\", \"label\": \"SKU\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"sku\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"8cc97127-8745-46fe-819d-69c1c714fa05\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePriceField\", \"label\": \"__blank__\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"price\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"5fdf5628-f4bd-4391-a664-d76a878606af\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableStockField\", \"label\": \"Inventory\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"stock\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"2f4626e8-f395-42e6-a06f-0e6a2a4dce60\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAvailableForPurchaseField\", \"label\": \"Available for purchase\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"availableForPurchase\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"0665c2f7-18ce-4234-942d-8884701f9706\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAllowedQtyField\", \"label\": \"Allowed Qty\", \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"allowedQty\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"98632d73-8ecb-4989-8cc5-7639bc52e933\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableFreeShippingField\", \"label\": \"Free Shipping\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"freeShipping\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"6b619e57-50d0-42e6-b72f-dffe7c9bd78b\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePromotableField\", \"label\": \"Promotable\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"promotable\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"361617f4-467e-4ad6-aa76-377487e0fe48\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableDimensionsField\", \"label\": \"Dimensions\", \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"dimensions\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"c634bcb0-2396-4fb8-91b2-035173c74e46\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableWeightField\", \"label\": \"Weight\", \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"weight\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"86ffda5f-7f11-4604-bf87-2bbf7ddcb04f\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"6976c542-7895-445e-a7cc-984f83edc4db\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"57dcd468-699f-4123-94e0-7ef4f7c608fa\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-02-20 13:49:56','2024-05-15 14:51:15',NULL,'75e4f84e-390a-46aa-b1d5-3fd21ba50086'),
(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"5c332718-b9d0-4b5d-a691-03862e40a8db\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"1dbfaf23-e945-40cb-bc74-da94191889da\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"1668e7f7-53b1-4a9f-a4a1-36a0b320791f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"adf2df73-86b8-40d0-982b-46f2c3a1e194\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-15 07:43:43','2024-05-15 07:44:34',NULL,'a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f'),
(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"c59f0921-74df-4b6f-97fb-131c58a76106\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"a16eae21-8ee0-45f4-a654-0dc2430c0f39\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-15 07:44:48','2024-05-15 07:47:53',NULL,'5bba87f1-9337-4676-9e9f-909112c78304');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES
(1,'Description','description','global','rjoqbfzd',NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-01-12 01:00:11','2024-05-12 20:03:43','0b2826e6-4b3f-47c6-a726-df613dcdd607'),
(2,'Image','image','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:63787053-c58d-42f3-af9c-632e7dc01f35\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:63787053-c58d-42f3-af9c-632e7dc01f35\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:63787053-c58d-42f3-af9c-632e7dc01f35\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-02-18 02:00:55','2024-02-18 02:01:54','eb6c8b6c-8a32-42a9-9ab0-97414e63933d'),
(3,'Colour','colour','global','hpitsupp',NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Yellow\",\"value\":\"yellow\",\"default\":\"\"},{\"label\":\"White\",\"value\":\"white\",\"default\":\"\"},{\"label\":\"Black\",\"value\":\"black\",\"default\":\"\"}]}','2024-02-20 13:51:55','2024-05-12 20:27:48','57dcd468-699f-4123-94e0-7ef4f7c608fa'),
(4,'Countries','countries','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"sources\":[\"section:8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-05-15 07:44:27','2024-05-15 07:48:23','adf2df73-86b8-40d0-982b-46f2c3a1e194'),
(5,'Brand','brand','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"sources\":[\"section:f92b7543-93bd-4f80-a601-594f6cdfa370\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-05-15 07:45:40','2024-05-15 07:45:40','538464ce-c5c0-49ae-badb-fa161b18063c'),
(6,'Materials','materials','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Checkboxes','{\"options\":[{\"label\":\"Cotton\",\"value\":\"cotton\",\"default\":\"\"},{\"label\":\"Elastic\",\"value\":\"elastic\",\"default\":\"\"},{\"label\":\"Polysomething\",\"value\":\"polysomething\",\"default\":\"\"}]}','2024-05-15 14:50:50','2024-05-15 14:50:50','99d30c67-07aa-47f4-9559-744b5337fdfe');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES
(1,'5.1.3','5.0.0.20',0,'zojlyininuap','3@wekvasrczx','2024-01-12 00:57:57','2024-05-15 14:51:15','e404a195-47a6-4328-89e3-b81a86b808d0');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'craft','Install','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','071be15c-63cc-4f6f-9c47-29ef67945ba9'),
(2,'craft','m210121_145800_asset_indexing_changes','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','3de214be-9228-4cba-b1a2-23ece4daeea1'),
(3,'craft','m210624_222934_drop_deprecated_tables','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','9cf757d1-8bcf-4ffb-a801-fe3e71af0c0f'),
(4,'craft','m210724_180756_rename_source_cols','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','0303f0c8-98c4-4310-ab46-4c1e32189077'),
(5,'craft','m210809_124211_remove_superfluous_uids','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','7b55d445-ca29-45f5-8fad-d560089e8900'),
(6,'craft','m210817_014201_universal_users','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','3a8dc7a6-80c9-4efa-bb6b-5f5183643db0'),
(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','b575475b-35b9-4b35-8029-72bf71e57a2a'),
(8,'craft','m211115_135500_image_transformers','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','528df0c6-ea2e-45f0-b627-52f17869d091'),
(9,'craft','m211201_131000_filesystems','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','4e6035bd-6e4b-4938-8978-72670bdb5c50'),
(10,'craft','m220103_043103_tab_conditions','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','e5c36195-8400-49d6-a1ec-add481ffe91d'),
(11,'craft','m220104_003433_asset_alt_text','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','970dae92-ff73-4274-8a63-532198e27dc3'),
(12,'craft','m220123_213619_update_permissions','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','2117d72e-63bb-4fdf-9b7d-90df3c7ff15c'),
(13,'craft','m220126_003432_addresses','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','93fd485c-05db-483b-89de-16607105fbe2'),
(14,'craft','m220209_095604_add_indexes','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','4f2a194d-bde3-41d7-a45e-69275cfc42c1'),
(15,'craft','m220213_015220_matrixblocks_owners_table','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','e151076d-92e4-432f-b261-71331955bd7f'),
(16,'craft','m220214_000000_truncate_sessions','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','9d2a641e-f9f4-4624-89cf-c69fd097fe62'),
(17,'craft','m220222_122159_full_names','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','ddc0e415-7e06-48ad-96a8-ea7ac1467b4a'),
(18,'craft','m220223_180559_nullable_address_owner','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','99b21824-fbe6-4334-9340-20efea231dbf'),
(19,'craft','m220225_165000_transform_filesystems','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','37008ee7-d81e-45e5-bb52-52d5e202fe2f'),
(20,'craft','m220309_152006_rename_field_layout_elements','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','e2ad9193-1462-4706-9f48-e12d5ba18d89'),
(21,'craft','m220314_211928_field_layout_element_uids','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','49577e71-73fa-45a3-a113-ce07a0106071'),
(22,'craft','m220316_123800_transform_fs_subpath','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','833e9d46-28df-4f0c-8d5f-a47c2dda4878'),
(23,'craft','m220317_174250_release_all_jobs','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','ced585f7-7f84-4b88-8bed-8a471e666ae3'),
(24,'craft','m220330_150000_add_site_gql_schema_components','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','e077bf04-664b-43c7-8d4a-a8eca4512023'),
(25,'craft','m220413_024536_site_enabled_string','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','ce25c38e-1e24-434e-856a-7f036be943e4'),
(26,'craft','m221027_160703_add_image_transform_fill','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','1de01f78-7cce-4c8b-bbdb-c08c8465ab24'),
(27,'craft','m221028_130548_add_canonical_id_index','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','66c96759-bcc3-4bd1-95d3-51698ae45b46'),
(28,'craft','m221118_003031_drop_element_fks','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','c2e27ba4-86c6-40d0-8246-b52dee01821f'),
(29,'craft','m230131_120713_asset_indexing_session_new_options','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','474c9fb4-bd01-46ec-b904-9f64a078b4b6'),
(30,'craft','m230226_013114_drop_plugin_license_columns','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','e27af08f-8a8c-4232-b3fc-180c2b8467bf'),
(31,'craft','m230531_123004_add_entry_type_show_status_field','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','bb943bce-d820-424f-8bb1-263d0290762d'),
(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','bce1422b-dfcb-46a7-bd49-409cf757c305'),
(33,'craft','m230710_162700_element_activity','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','56f32e37-a438-4f0e-b69b-b461b354dfbc'),
(34,'craft','m230820_162023_fix_cache_id_type','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','bd2a001e-c6c1-4ae2-ba07-e4866902f6b1'),
(35,'craft','m230826_094050_fix_session_id_type','2024-01-12 00:57:57','2024-01-12 00:57:57','2024-01-12 00:57:57','19b23dcd-9a87-436d-9ed4-bc39bbacad62'),
(36,'plugin:sprig','Install','2024-01-12 00:58:56','2024-01-12 00:58:56','2024-01-12 00:58:56','7f7b4194-7921-4883-9529-6929cd6a1a0f'),
(37,'plugin:commerce','Install','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','937ae0a6-7367-4546-871d-ad9dc0a123e3'),
(38,'plugin:commerce','m210614_073359_detailed_permission','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','3b8e622d-3e46-495f-9115-d3ef195bc059'),
(39,'plugin:commerce','m210831_080542_rename_variant_title_format_field','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','22b5c321-087c-4dd5-8c6d-91f8d3a8c919'),
(40,'plugin:commerce','m210901_211323_not_null_booleans','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','87b82ca4-092c-45f2-a964-1b43c80baa53'),
(41,'plugin:commerce','m210922_133729_add_discount_order_condition_builder','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','70b8df9c-380d-4138-952f-f1d32909c40e'),
(42,'plugin:commerce','m211118_101920_split_coupon_codes','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','5802e2a7-eee9-4b94-ade9-e4e42cc503ec'),
(43,'plugin:commerce','m220301_022054_user_addresses','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','fb3d1cf9-ebe7-494b-be1c-35e9197f3876'),
(44,'plugin:commerce','m220302_133730_add_discount_user_addresses_condition_builders','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','6c317885-2037-476f-a4b2-3930df42759a'),
(45,'plugin:commerce','m220304_094835_discount_conditions','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','b291ff13-9618-4743-bc92-d52c6cacd6b2'),
(46,'plugin:commerce','m220308_221717_orderhistory_name','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','3c00eb52-fae4-49f3-ba72-bdb86b792b60'),
(47,'plugin:commerce','m220329_075053_convert_gateway_frontend_enabled_column','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','c9a0a6f9-e789-41e2-b70f-08c9b22dbc54'),
(48,'plugin:commerce','m220706_132118_add_purchasable_tax_type','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','1a586b63-0b93-4a54-8519-2ce089506397'),
(49,'plugin:commerce','m220812_104819_add_primary_payment_source_column','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','63eeb4d6-8087-4ebc-a820-c4c308822730'),
(50,'plugin:commerce','m220817_135050_add_purchase_total_back_if_missing','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','7537d573-fa4d-4636-b4f8-12ea29345b7e'),
(51,'plugin:commerce','m220912_111800_add_order_total_qty_column','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','8d3f45ad-f06c-4f60-89ca-415f3d06f637'),
(52,'plugin:commerce','m221027_070322_add_tax_shipping_category_soft_delete','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','3154313d-428a-4d3d-9337-e20d96be5000'),
(53,'plugin:commerce','m221027_074805_update_shipping_tax_category_indexes','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','f12a1bb7-c6b3-4c28-8406-c4535f74d656'),
(54,'plugin:commerce','m221028_192112_add_indexes_to_address_columns_on_orders','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','1e570dc9-0d42-42fb-b131-665457fbf722'),
(55,'plugin:commerce','m221122_155735_update_orders_shippingMethodHandle_default','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','fdda18cd-baf5-4b09-abee-2d8a2d22a358'),
(56,'plugin:commerce','m230530_100604_add_complete_email_column','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','3c7c865a-37e6-4e9b-97a4-7733b496d048'),
(57,'plugin:commerce','m230705_124845_add_save_address_columns','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','fdf37c5e-6d9d-48c0-b887-d74536ec17e8'),
(58,'plugin:commerce','m230719_082348_discount_nullable_conditions','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','5e073a14-bce6-4b8d-9569-30ac14a90677'),
(59,'plugin:commerce','m230724_080855_entrify_promotions','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','c329a0f0-748f-4efb-a4ef-b723b3d0b08b'),
(60,'plugin:commerce','m231006_034833_add_indexes_for_source_address_on_order','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','ff5044a7-0b2c-44c0-8636-612cacb7191f'),
(61,'plugin:commerce','m231220_103739_ensure_discount_sort_order','2024-02-18 01:48:26','2024-02-18 01:48:26','2024-02-18 01:48:26','cb02c8c7-49dd-43bc-b91d-0f259b2e45e9'),
(62,'plugin:commerce','m240226_002943_remove_lite','2024-05-12 20:01:41','2024-05-12 20:01:41','2024-05-12 20:01:41','d6bd5d48-8340-4de3-b38f-640699bda2fa'),
(63,'plugin:commerce','m240306_091057_move_element_ids_on_discount_to_columns','2024-05-12 20:01:41','2024-05-12 20:01:41','2024-05-12 20:01:41','7f6ae1bc-526b-48a0-9d50-3ab3cb3cdffa'),
(64,'plugin:commerce','m240430_161804_add_index_to_transaction_hash','2024-05-12 20:01:41','2024-05-12 20:01:41','2024-05-12 20:01:41','7175da1c-41b1-4b02-9828-fc1f9e43c780'),
(65,'craft','m221101_115859_create_entries_authors_table','2024-05-12 20:20:54','2024-05-12 20:20:54','2024-05-12 20:20:54','bd9cd65a-a84a-4580-b5b7-12eee2075e68'),
(66,'craft','m221107_112121_add_max_authors_to_sections','2024-05-12 20:20:54','2024-05-12 20:20:54','2024-05-12 20:20:54','8c9b1a6d-2461-4764-b0c3-1fe8c4baaf44'),
(67,'craft','m221205_082005_translatable_asset_alt_text','2024-05-12 20:20:54','2024-05-12 20:20:54','2024-05-12 20:20:54','afc2ce47-bdaf-454c-b12b-caaf4201167a'),
(68,'craft','m230314_110309_add_authenticator_table','2024-05-12 20:20:54','2024-05-12 20:20:54','2024-05-12 20:20:54','85fbc77d-c5d6-403d-ab9a-0ca08e405261'),
(69,'craft','m230314_111234_add_webauthn_table','2024-05-12 20:20:54','2024-05-12 20:20:54','2024-05-12 20:20:54','b29d463f-0150-4a76-b67e-e0d6d62d5fcd'),
(70,'craft','m230503_120303_add_recoverycodes_table','2024-05-12 20:20:54','2024-05-12 20:20:54','2024-05-12 20:20:54','006edb4a-bbe7-4fcb-b422-e512363ddd2f'),
(71,'craft','m230511_000000_field_layout_configs','2024-05-12 20:20:54','2024-05-12 20:20:54','2024-05-12 20:20:54','345c116f-3248-403e-bf23-7dfeaed12e68'),
(72,'craft','m230511_215903_content_refactor','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','0551aefb-871b-4d2e-8389-e542111a6132'),
(73,'craft','m230524_000000_add_entry_type_show_slug_field','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','587ed6ea-7a90-4435-9502-cf1220e318a9'),
(74,'craft','m230524_000001_entry_type_icons','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','b81e2cd2-32f2-4e85-9231-22c5be87549f'),
(75,'craft','m230524_000002_entry_type_colors','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','b4fd74bc-85da-4ae9-a7e3-8854bebcd409'),
(76,'craft','m230524_220029_global_entry_types','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','eb599760-71b0-472a-bacb-ef1bbb8f411f'),
(77,'craft','m230616_173810_kill_field_groups','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','867c6a5a-bc1b-4faf-bb20-78680b086906'),
(78,'craft','m230616_183820_remove_field_name_limit','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','5cdaa9b0-5e84-445d-a826-a4480a262749'),
(79,'craft','m230617_070415_entrify_matrix_blocks','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','4a67a367-19e4-4488-acbc-207d01d2697b'),
(80,'craft','m230904_190356_address_fields','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','8c53f57e-6e47-43cc-a110-3af5e59cda11'),
(81,'craft','m230928_144045_add_subpath_to_volumes','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','c1606c7c-04b4-401f-b100-ccf801295bab'),
(82,'craft','m231013_185640_changedfields_amend_primary_key','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','27a8d668-994e-4d8f-9766-f216a9551a2f'),
(83,'craft','m231213_030600_element_bulk_ops','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','3a22170c-e12e-4d93-b147-4caf5da74502'),
(84,'craft','m240129_150719_sites_language_amend_length','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','58b7254d-b136-4412-ae8b-fa0af8aaa1a2'),
(85,'craft','m240206_035135_convert_json_columns','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','8a25cd9b-4c1f-4cfb-9622-4d3cd83b0c63'),
(86,'craft','m240207_182452_address_line_3','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','50ad34c8-14ec-4043-acad-e116f334d1e9'),
(87,'craft','m240302_212719_solo_preview_targets','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','486e2cd4-796d-4faa-9555-ce180a65b5b1'),
(88,'plugin:commerce','m221025_083940_add_purchasables_stores_table','2024-05-12 20:20:55','2024-05-12 20:20:55','2024-05-12 20:20:55','3719a894-5181-4fb1-a665-1ba476711c3b'),
(89,'plugin:commerce','m221026_105212_add_catalog_pricing_table','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','93675322-4a76-4dd8-992f-48874d5b2c64'),
(90,'plugin:commerce','m221122_055724_move_general_settings_to_per_store_settings','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','46882221-e4f6-4508-aa20-2edeb938d367'),
(91,'plugin:commerce','m221122_055725_multi_store','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','1e2573e4-4ddc-450b-88f5-9f1841234856'),
(92,'plugin:commerce','m221124_114239_add_date_deleted_to_stores','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','be508779-479d-4217-90ff-8f57a41c14e2'),
(93,'plugin:commerce','m221206_094303_add_store_to_order','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','591cb7e5-c6b7-484d-a667-be7373b92bad'),
(94,'plugin:commerce','m221213_052623_drop_lite','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','801cb567-7e7e-4e7c-9266-8822e8fbe3c4'),
(95,'plugin:commerce','m221213_070807_initial_storeId_records_transition','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','2f754818-df2b-4e87-bd62-384a49520c54'),
(96,'plugin:commerce','m230103_122549_add_product_type_max_variants','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','5d331877-334b-4478-903b-bacf071a041d'),
(97,'plugin:commerce','m230110_052712_site_stores','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','a69726b4-ece9-40a0-bf73-bbed394c2e98'),
(98,'plugin:commerce','m230111_112916_update_lineitems_table','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','38174476-f6ed-4b97-a831-77cfb4856833'),
(99,'plugin:commerce','m230113_110914_remove_soft_delete','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','4e7a2624-7833-469a-8c74-dd8a4af0637c'),
(100,'plugin:commerce','m230118_114424_add_purchasables_stores_indexes','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','23eda7c3-121c-4694-9c9f-fbd7a055e725'),
(101,'plugin:commerce','m230126_105337_rename_discount_sales_references','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','faedc9ee-0c57-41f4-8487-e56a007770f2'),
(102,'plugin:commerce','m230126_114655_add_catalog_pricing_rule_metadata_column','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','2f14f23b-45bd-4703-a7e0-d9b3dcbdf2f6'),
(103,'plugin:commerce','m230208_130445_add_store_id_to_shipping_categories','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','7f996885-5036-4a72-855e-9932ccead56b'),
(104,'plugin:commerce','m230210_093749_add_store_id_to_shipping_methods','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','cf9291e6-6fed-43be-922f-95deacca433a'),
(105,'plugin:commerce','m230210_141514_add_store_id_to_shipping_zones','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','3bd20007-e2a5-4936-a7dd-9a55e802677c'),
(106,'plugin:commerce','m230214_094122_add_total_weight_column_to_orders','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','c5a2c085-4c06-4e9d-8888-61b5b106c4f9'),
(107,'plugin:commerce','m230214_095055_update_name_index_on_shipping_zones','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','c9a06df2-5234-4676-93de-c1911939f922'),
(108,'plugin:commerce','m230215_083820_add_order_condition_to_shipping_rules','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','c25481a1-e9d8-4ce2-bfcb-441cc7f1c23b'),
(109,'plugin:commerce','m230215_114552_migrate_shipping_rule_conditions_to_condition_builder','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','b7b3c502-19ce-4010-a0cd-6fda5ea7ac99'),
(110,'plugin:commerce','m230217_095845_remove_shipping_rules_columns','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','69eec058-d908-4944-ad9e-6830326ab944'),
(111,'plugin:commerce','m230217_143255_add_shipping_method_order_condition','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','9866fa49-2ae7-4cee-8dbe-3b5d864828a0'),
(112,'plugin:commerce','m230220_075106_add_store_id_to_tax_rates','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','328f4ef8-3269-4ee4-969d-d9865f3710ff'),
(113,'plugin:commerce','m230220_080107_add_store_id_to_tax_zones','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','e3b027e4-bc87-417c-afda-e95664375e5a'),
(114,'plugin:commerce','m230307_091520_add_sort_order_to_stores','2024-05-12 20:20:56','2024-05-12 20:20:56','2024-05-12 20:20:56','9c3e78ba-997d-4d25-94b7-c0ed09d2a1ab'),
(115,'plugin:commerce','m230308_084340_add_store_id_to_order_statuses','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','73b3f162-8564-4373-b896-f67b96ff976f'),
(116,'plugin:commerce','m230310_102639_add_store_id_to_line_item_statuses','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','fa31253d-2d9a-415c-b7bc-66fd7df48d05'),
(117,'plugin:commerce','m230313_095359_add_store_id_to_emails','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','9a603e2f-011a-4244-85b0-f85a5d31b826'),
(118,'plugin:commerce','m230317_102521_add_store_id_to_pdfs','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','58f8f83b-c53c-4bfd-a976-10bab71ea6d2'),
(119,'plugin:commerce','m230322_091615_move_email_settings_to_model','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','7bbc71e4-e98f-4c76-8360-4c825bb5031b'),
(120,'plugin:commerce','m230328_130343_move_pdf_settings_to_model','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','b91085bc-4ed9-43cd-a73c-eaf16115f9fa'),
(121,'plugin:commerce','m230525_081243_add_has_update_pending_property','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','0aaffb88-a859-4d96-8777-ee27f6adc3ce'),
(122,'plugin:commerce','m230920_051125_move_primary_currency_to_store_settings','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','110c5d23-eac7-4510-a7c6-3697df3a7205'),
(123,'plugin:commerce','m230928_095544_fix_unique_on_some_tables','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','06320e7e-78d7-443e-a10d-cd349f1d69bf'),
(124,'plugin:commerce','m230928_155052_move_shipping_category_id_to_purchasable_stores','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','84061f53-74c7-4624-b545-d310fce9d5af'),
(125,'plugin:commerce','m231019_110814_update_variant_ownership','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','8f24cd51-bbf3-4aa9-9ee8-cacf8b4f0662'),
(126,'plugin:commerce','m231110_081143_inventory_movement_table','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','93c465a8-49f7-486b-a8b9-6e6deda9c957'),
(127,'plugin:commerce','m231201_100454_update_discount_base_discount_type','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','06174a52-58ca-4138-a8d3-d57854526850'),
(128,'plugin:commerce','m240119_073924_content_refactor_elements','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','86a796fa-7b00-4af0-8958-e51592e1f407'),
(129,'plugin:commerce','m240119_075036_content_refactor_subscription_elements','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','cfa6d760-fc88-4858-896c-fe1e51fdadc8'),
(130,'plugin:commerce','m240208_083054_add_purchasable_stores_purchasable_fk','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','15f98d84-50ad-4b3c-8c66-7f18b460a696'),
(131,'plugin:commerce','m240219_194855_donation_multi_store','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','4b3ecdf6-b846-4fa8-8d1a-ce7986b910d8'),
(132,'plugin:commerce','m240220_045806_product_versioning','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','49a30062-d455-49ad-8927-04951ebd31d6'),
(133,'plugin:commerce','m240220_105746_remove_store_from_donations_table','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','8cfd59f8-4d28-403e-8adb-c7f18d9e7de5'),
(134,'plugin:commerce','m240221_030027_transfer_items','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','d92c23b8-277d-4a33-8fdb-5885eb193941'),
(135,'plugin:commerce','m240223_101158_update_recent_orders_widget_settings','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','64356d7e-dc8a-4ea5-8b8a-b8976195762e'),
(136,'plugin:commerce','m240228_054005_rename_movements_table','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','49177a89-e3f3-4ff8-8662-65b8e58464b1'),
(137,'plugin:commerce','m240228_060604_add_fufilled_type_to_inventorytransactions','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','f73166b4-f0c6-4014-91fe-2e553d31b761'),
(138,'plugin:commerce','m240228_120911_drop_order_id_and_make_line_item_cascade','2024-05-12 20:20:57','2024-05-12 20:20:57','2024-05-12 20:20:57','729a105a-e00c-4f54-abff-162b6f51ee83'),
(139,'plugin:commerce','m240308_133451_tidy_shipping_categories','2024-05-12 20:20:58','2024-05-12 20:20:58','2024-05-12 20:20:58','d2afa49b-cced-410a-a392-2389cb64452e'),
(140,'plugin:commerce','m240313_131445_tidy_shipping_methods','2024-05-12 20:20:58','2024-05-12 20:20:58','2024-05-12 20:20:58','b4ea9c89-3bb6-438f-8cef-d1b33496dcb2'),
(141,'plugin:commerce','m240315_072659_add_fk_cascade_fixes','2024-05-12 20:20:58','2024-05-12 20:20:58','2024-05-12 20:20:58','4a832928-c3a9-431c-84f8-313173189b35'),
(142,'plugin:commerce','m240507_081904_fix_store_pc_location','2024-05-12 20:20:58','2024-05-12 20:20:58','2024-05-12 20:20:58','6eb2f253-b8e8-46f3-a6fc-621ed88bdcea');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES
(1,'sprig','3.0.1','1.0.1','2024-01-12 00:58:56','2024-01-12 00:58:56','2024-05-12 20:08:25','ec6ebd83-a560-4fec-aa69-9b1a74a63af9'),
(2,'commerce','5.0.6','5.0.74','2024-02-18 01:48:24','2024-02-18 01:48:24','2024-05-15 17:24:59','9cb8883c-2c8a-49ac-b2d1-c181ec4d0e8a');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES
('commerce.gateways.78d705b6-3fee-471b-9451-847caf510cde.handle','\"dummy\"'),
('commerce.gateways.78d705b6-3fee-471b-9451-847caf510cde.isFrontendEnabled','true'),
('commerce.gateways.78d705b6-3fee-471b-9451-847caf510cde.name','\"Dummy\"'),
('commerce.gateways.78d705b6-3fee-471b-9451-847caf510cde.paymentType','\"purchase\"'),
('commerce.gateways.78d705b6-3fee-471b-9451-847caf510cde.settings','null'),
('commerce.gateways.78d705b6-3fee-471b-9451-847caf510cde.sortOrder','99'),
('commerce.gateways.78d705b6-3fee-471b-9451-847caf510cde.type','\"craft\\\\commerce\\\\gateways\\\\Dummy\"'),
('commerce.orderStatuses.a5992712-f8e7-40f9-a127-2b87b50eb960.color','\"green\"'),
('commerce.orderStatuses.a5992712-f8e7-40f9-a127-2b87b50eb960.default','true'),
('commerce.orderStatuses.a5992712-f8e7-40f9-a127-2b87b50eb960.description','null'),
('commerce.orderStatuses.a5992712-f8e7-40f9-a127-2b87b50eb960.handle','\"new\"'),
('commerce.orderStatuses.a5992712-f8e7-40f9-a127-2b87b50eb960.name','\"New\"'),
('commerce.orderStatuses.a5992712-f8e7-40f9-a127-2b87b50eb960.sortOrder','99'),
('commerce.orderStatuses.a5992712-f8e7-40f9-a127-2b87b50eb960.store','\"e7b0d812-496a-462a-b37a-b6ecee3ba260\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.descriptionFormat','\"{product.title} - {title}\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.enableVersioning','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.handle','\"products\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.hasDimensions','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.hasProductTitleField','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.hasVariantTitleField','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.maxVariants','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.name','\"Products\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.autocapitalize','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.autocomplete','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.autocorrect','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.class','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.disabled','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.inputType','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.max','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.min','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.name','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.placeholder','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.readonly','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.size','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.step','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.title','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\ProductTitleField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.uid','\"e72f9176-462e-488e-a563-2bbfab3987fe\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.0.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.fieldUid','\"eb6c8b6c-8a32-42a9-9ab0-97414e63933d\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.handle','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.uid','\"c2b63f9e-e23e-47b6-8ac2-10e82f1ca371\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.1.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.fieldUid','\"57dcd468-699f-4123-94e0-7ef4f7c608fa\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.handle','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.uid','\"9993725b-6c75-43ae-aaaf-cf374499f2f4\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.2.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.fieldUid','\"99d30c67-07aa-47f4-9559-744b5337fdfe\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.handle','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.uid','\"89927820-c649-4415-836e-5e969370d306\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.3.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.fieldUid','\"538464ce-c5c0-49ae-badb-fa161b18063c\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.handle','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.uid','\"22de9eb7-2bce-4648-bcba-8a9a3e40b061\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.4.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.fieldUid','\"0b2826e6-4b3f-47c6-a726-df613dcdd607\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.handle','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.uid','\"49cdbf38-5e25-487e-8ce7-ea68f4246d80\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.5.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.attribute','\"variants\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantsField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.uid','\"cac72456-60b5-4587-849e-c2ee4c0943e7\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.elements.6.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.name','\"Content\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.uid','\"a7cd4d02-6bd5-412d-a716-8006b28c5a61\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productFieldLayouts.be72b007-b301-4d30-82d7-53a0ed9a22ec.tabs.0.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.productTitleFormat','\"\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.hasUrls','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.template','\"\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.uriFormat','\"products/{slug}\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.skuFormat','\"\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.attribute','\"sku\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.label','\"SKU\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.required','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableSkuField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.uid','\"d14286cf-7500-4425-b8ef-7c6337a87f5d\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.0.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.attribute','\"price\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.label','\"__blank__\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.required','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePriceField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.uid','\"8cc97127-8745-46fe-819d-69c1c714fa05\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.1.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.fieldUid','\"57dcd468-699f-4123-94e0-7ef4f7c608fa\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.handle','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.uid','\"6976c542-7895-445e-a7cc-984f83edc4db\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.10.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.attribute','\"stock\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.label','\"Inventory\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.required','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableStockField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.uid','\"5fdf5628-f4bd-4391-a664-d76a878606af\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.2.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.attribute','\"availableForPurchase\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.label','\"Available for purchase\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.required','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAvailableForPurchaseField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.uid','\"2f4626e8-f395-42e6-a06f-0e6a2a4dce60\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.3.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.attribute','\"allowedQty\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.label','\"Allowed Qty\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAllowedQtyField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.uid','\"0665c2f7-18ce-4234-942d-8884701f9706\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.4.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.attribute','\"freeShipping\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.label','\"Free Shipping\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.required','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableFreeShippingField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.uid','\"98632d73-8ecb-4989-8cc5-7639bc52e933\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.5.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.attribute','\"promotable\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.label','\"Promotable\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.required','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePromotableField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.uid','\"6b619e57-50d0-42e6-b72f-dffe7c9bd78b\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.6.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.attribute','\"dimensions\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.label','\"Dimensions\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableDimensionsField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.uid','\"361617f4-467e-4ad6-aa76-377487e0fe48\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.7.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.attribute','\"weight\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.label','\"Weight\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.mandatory','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.required','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.translatable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableWeightField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.uid','\"c634bcb0-2396-4fb8-91b2-035173c74e46\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.8.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.autocapitalize','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.autocomplete','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.autocorrect','true'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.class','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.disabled','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.elementCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.id','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.includeInCards','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.inputType','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.instructions','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.label','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.max','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.min','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.name','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.orientation','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.placeholder','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.providesThumbs','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.readonly','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.requirable','false'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.size','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.step','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.tip','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.title','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantTitleField\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.uid','\"86ffda5f-7f11-4604-bf87-2bbf7ddcb04f\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.warning','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.elements.9.width','100'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.name','\"Content\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.uid','\"828f2570-6e7c-4ce8-b040-9b89c681cdde\"'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantFieldLayouts.75e4f84e-390a-46aa-b1d5-3fd21ba50086.tabs.0.userCondition','null'),
('commerce.productTypes.76ceebcf-6e96-4ed0-8792-e33851d9b8f1.variantTitleFormat','\"{product.title}\"'),
('commerce.sitestores.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.store','\"e7b0d812-496a-462a-b37a-b6ecee3ba260\"'),
('commerce.stores.e7b0d812-496a-462a-b37a-b6ecee3ba260.currency','\"USD\"'),
('commerce.stores.e7b0d812-496a-462a-b37a-b6ecee3ba260.handle','\"primaryStore\"'),
('commerce.stores.e7b0d812-496a-462a-b37a-b6ecee3ba260.name','\"Primary Store\"'),
('commerce.stores.e7b0d812-496a-462a-b37a-b6ecee3ba260.primary','true'),
('dateModified','1715784675'),
('elementSources.craft\\commerce\\elements\\Product.0.key','\"*\"'),
('elementSources.craft\\commerce\\elements\\Product.0.type','\"native\"'),
('elementSources.craft\\commerce\\elements\\Product.1.heading','\"Product Types\"'),
('elementSources.craft\\commerce\\elements\\Product.1.type','\"heading\"'),
('elementSources.craft\\commerce\\elements\\Product.2.defaultSort.0','\"title\"'),
('elementSources.craft\\commerce\\elements\\Product.2.defaultSort.1','\"asc\"'),
('elementSources.craft\\commerce\\elements\\Product.2.disabled','false'),
('elementSources.craft\\commerce\\elements\\Product.2.key','\"productType:76ceebcf-6e96-4ed0-8792-e33851d9b8f1\"'),
('elementSources.craft\\commerce\\elements\\Product.2.tableAttributes.0','\"defaultSku\"'),
('elementSources.craft\\commerce\\elements\\Product.2.tableAttributes.1','\"defaultPrice\"'),
('elementSources.craft\\commerce\\elements\\Product.2.tableAttributes.2','\"availableForPurchase\"'),
('elementSources.craft\\commerce\\elements\\Product.2.tableAttributes.3','\"stock\"'),
('elementSources.craft\\commerce\\elements\\Product.2.tableAttributes.4','\"link\"'),
('elementSources.craft\\commerce\\elements\\Product.2.type','\"native\"'),
('email.fromEmail','\"ben@putyourlightson.com\"'),
('email.fromName','\"Sprig Training\"'),
('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.color','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elementCondition','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.autocomplete','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.autocorrect','true'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.class','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.disabled','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.elementCondition','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.id','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.includeInCards','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.inputType','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.instructions','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.label','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.max','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.min','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.name','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.orientation','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.placeholder','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.readonly','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.requirable','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.size','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.step','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.tip','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.title','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.uid','\"1dbfaf23-e945-40cb-bc74-da94191889da\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.userCondition','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.warning','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.0.width','100'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.elementCondition','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.fieldUid','\"adf2df73-86b8-40d0-982b-46f2c3a1e194\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.handle','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.includeInCards','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.instructions','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.label','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.providesThumbs','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.required','false'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.tip','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.uid','\"1668e7f7-53b1-4a9f-a4a1-36a0b320791f\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.userCondition','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.warning','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.elements.1.width','100'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.name','\"Content\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.uid','\"5c332718-b9d0-4b5d-a691-03862e40a8db\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.fieldLayouts.a740fa96-aa3c-4cf8-afbe-da0fe8e56a3f.tabs.0.userCondition','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.handle','\"brand\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.hasTitleField','true'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.icon','\"\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.name','\"Brand\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.showSlugField','true'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.showStatusField','true'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.slugTranslationKeyFormat','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.slugTranslationMethod','\"site\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.titleFormat','\"\"'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.titleTranslationKeyFormat','null'),
('entryTypes.36cba068-6c7e-426b-9fad-d99775b88e98.titleTranslationMethod','\"site\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.color','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elementCondition','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.autocomplete','false'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.autocorrect','true'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.class','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.disabled','false'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.elementCondition','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.id','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.includeInCards','false'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.inputType','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.instructions','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.label','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.max','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.min','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.name','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.orientation','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.placeholder','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.providesThumbs','false'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.readonly','false'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.requirable','false'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.size','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.step','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.tip','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.title','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.uid','\"a16eae21-8ee0-45f4-a654-0dc2430c0f39\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.userCondition','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.warning','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.elements.0.width','100'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.name','\"Content\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.uid','\"c59f0921-74df-4b6f-97fb-131c58a76106\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.fieldLayouts.5bba87f1-9337-4676-9e9f-909112c78304.tabs.0.userCondition','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.handle','\"country\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.hasTitleField','true'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.icon','\"\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.name','\"Country\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.showSlugField','true'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.showStatusField','true'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.slugTranslationKeyFormat','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.slugTranslationMethod','\"site\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.titleFormat','\"\"'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.titleTranslationKeyFormat','null'),
('entryTypes.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1.titleTranslationMethod','\"site\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elementCondition','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.autocomplete','false'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.autocorrect','true'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.class','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.disabled','false'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.elementCondition','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.id','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.inputType','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.instructions','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.label','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.max','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.min','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.name','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.orientation','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.placeholder','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.readonly','false'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.requirable','false'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.size','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.step','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.tip','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.title','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.uid','\"61f12749-7ee4-4498-8751-eff81c38a3ec\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.userCondition','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.warning','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.0.width','100'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.elementCondition','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.fieldUid','\"0b2826e6-4b3f-47c6-a726-df613dcdd607\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.instructions','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.label','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.required','true'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.tip','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.uid','\"11208a81-822c-4a1f-9082-cf5377d61a06\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.userCondition','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.warning','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.elements.1.width','100'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.name','\"Content\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.uid','\"ae65bd66-20ea-461c-b432-6500f8040665\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.fieldLayouts.b7f5b1e3-ed79-4985-a6b3-7e2e5cf83b9f.tabs.0.userCondition','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.handle','\"default\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.hasTitleField','true'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.name','\"Default\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.showStatusField','true'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.slugTranslationKeyFormat','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.slugTranslationMethod','\"site\"'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.sortOrder','1'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.titleFormat','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.titleTranslationKeyFormat','null'),
('entryTypes.b1797aea-7808-418c-a68b-1cb07b2b1c7c.titleTranslationMethod','\"site\"'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.columnSuffix','\"rjoqbfzd\"'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.contentColumnType','\"text\"'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.handle','\"description\"'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.instructions','null'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.name','\"Description\"'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.searchable','true'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.byteLimit','null'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.charLimit','null'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.code','false'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.columnType','null'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.initialRows','4'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.multiline','true'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.placeholder','null'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.settings.uiMode','\"normal\"'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.translationKeyFormat','null'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.translationMethod','\"none\"'),
('fields.0b2826e6-4b3f-47c6-a726-df613dcdd607.type','\"craft\\\\fields\\\\PlainText\"'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.columnSuffix','null'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.handle','\"brand\"'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.instructions','null'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.name','\"Brand\"'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.searchable','false'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.allowSelfRelations','false'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.branchLimit','null'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.localizeRelations','false'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.maintainHierarchy','false'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.maxRelations','1'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.minRelations','null'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.selectionLabel','null'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.showCardsInGrid','false'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.showSiteMenu','false'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.sources.0','\"section:f92b7543-93bd-4f80-a601-594f6cdfa370\"'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.targetSiteId','null'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.validateRelatedElements','false'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.settings.viewMode','\"list\"'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.translationKeyFormat','null'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.translationMethod','\"site\"'),
('fields.538464ce-c5c0-49ae-badb-fa161b18063c.type','\"craft\\\\fields\\\\Entries\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.columnSuffix','\"hpitsupp\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.handle','\"colour\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.instructions','null'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.name','\"Colour\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.searchable','false'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.0.__assoc__.0.0','\"label\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.0.__assoc__.0.1','\"Yellow\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.0.__assoc__.1.0','\"value\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.0.__assoc__.1.1','\"yellow\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.0.__assoc__.2.0','\"default\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.0.__assoc__.2.1','\"\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.1.__assoc__.0.0','\"label\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.1.__assoc__.0.1','\"White\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.1.__assoc__.1.0','\"value\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.1.__assoc__.1.1','\"white\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.1.__assoc__.2.0','\"default\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.1.__assoc__.2.1','\"\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.2.__assoc__.0.0','\"label\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.2.__assoc__.0.1','\"Black\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.2.__assoc__.1.0','\"value\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.2.__assoc__.1.1','\"black\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.2.__assoc__.2.0','\"default\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.settings.options.2.__assoc__.2.1','\"\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.translationKeyFormat','null'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.translationMethod','\"none\"'),
('fields.57dcd468-699f-4123-94e0-7ef4f7c608fa.type','\"craft\\\\fields\\\\Dropdown\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.columnSuffix','null'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.handle','\"materials\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.instructions','null'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.name','\"Materials\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.searchable','false'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.0.__assoc__.0.0','\"label\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.0.__assoc__.0.1','\"Cotton\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.0.__assoc__.1.0','\"value\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.0.__assoc__.1.1','\"cotton\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.0.__assoc__.2.0','\"default\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.0.__assoc__.2.1','\"\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.1.__assoc__.0.0','\"label\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.1.__assoc__.0.1','\"Elastic\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.1.__assoc__.1.0','\"value\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.1.__assoc__.1.1','\"elastic\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.1.__assoc__.2.0','\"default\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.1.__assoc__.2.1','\"\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.2.__assoc__.0.0','\"label\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.2.__assoc__.0.1','\"Polysomething\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.2.__assoc__.1.0','\"value\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.2.__assoc__.1.1','\"polysomething\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.2.__assoc__.2.0','\"default\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.settings.options.2.__assoc__.2.1','\"\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.translationKeyFormat','null'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.translationMethod','\"none\"'),
('fields.99d30c67-07aa-47f4-9559-744b5337fdfe.type','\"craft\\\\fields\\\\Checkboxes\"'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.columnSuffix','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.handle','\"countries\"'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.instructions','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.name','\"Countries\"'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.searchable','false'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.allowSelfRelations','false'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.branchLimit','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.localizeRelations','false'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.maintainHierarchy','false'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.maxRelations','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.minRelations','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.selectionLabel','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.showCardsInGrid','false'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.showSiteMenu','true'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.sources.0','\"section:8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686\"'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.targetSiteId','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.validateRelatedElements','false'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.settings.viewMode','\"list\"'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.translationKeyFormat','null'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.translationMethod','\"site\"'),
('fields.adf2df73-86b8-40d0-982b-46f2c3a1e194.type','\"craft\\\\fields\\\\Entries\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.columnSuffix','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.contentColumnType','\"string\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.handle','\"image\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.instructions','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.name','\"Image\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.searchable','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.allowedKinds','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.allowSelfRelations','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.allowSubfolders','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.allowUploads','true'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.branchLimit','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.defaultUploadLocationSource','\"volume:63787053-c58d-42f3-af9c-632e7dc01f35\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.defaultUploadLocationSubpath','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.localizeRelations','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.maintainHierarchy','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.maxRelations','1'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.minRelations','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.previewMode','\"full\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.restrictedDefaultUploadSubpath','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.restrictedLocationSource','\"volume:63787053-c58d-42f3-af9c-632e7dc01f35\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.restrictedLocationSubpath','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.restrictFiles','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.restrictLocation','true'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.selectionLabel','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.showSiteMenu','true'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.showUnpermittedFiles','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.showUnpermittedVolumes','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.sources.0','\"volume:63787053-c58d-42f3-af9c-632e7dc01f35\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.targetSiteId','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.validateRelatedElements','false'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.settings.viewMode','\"large\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.translationKeyFormat','null'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.translationMethod','\"site\"'),
('fields.eb6c8b6c-8a32-42a9-9ab0-97414e63933d.type','\"craft\\\\fields\\\\Assets\"'),
('fs.images.hasUrls','true'),
('fs.images.name','\"Images\"'),
('fs.images.settings.path','\"@webroot/assets/images\"'),
('fs.images.type','\"craft\\\\fs\\\\Local\"'),
('fs.images.url','\"/assets/images\"'),
('graphql.publicToken.enabled','false'),
('graphql.publicToken.expiryDate','null'),
('meta.__names__.0b2826e6-4b3f-47c6-a726-df613dcdd607','\"Description\"'),
('meta.__names__.36cba068-6c7e-426b-9fad-d99775b88e98','\"Brand\"'),
('meta.__names__.4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1','\"Country\"'),
('meta.__names__.538464ce-c5c0-49ae-badb-fa161b18063c','\"Brand\"'),
('meta.__names__.57dcd468-699f-4123-94e0-7ef4f7c608fa','\"Colour\"'),
('meta.__names__.63787053-c58d-42f3-af9c-632e7dc01f35','\"Images\"'),
('meta.__names__.76ceebcf-6e96-4ed0-8792-e33851d9b8f1','\"Products\"'),
('meta.__names__.78d705b6-3fee-471b-9451-847caf510cde','\"Dummy\"'),
('meta.__names__.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686','\"Countries\"'),
('meta.__names__.99d30c67-07aa-47f4-9559-744b5337fdfe','\"Materials\"'),
('meta.__names__.a5992712-f8e7-40f9-a127-2b87b50eb960','\"New\"'),
('meta.__names__.adf2df73-86b8-40d0-982b-46f2c3a1e194','\"Countries\"'),
('meta.__names__.b1797aea-7808-418c-a68b-1cb07b2b1c7c','\"Default\"'),
('meta.__names__.b9be22a6-6ef5-4a3a-9c8f-163610685d49','\"Articles\"'),
('meta.__names__.bd3a4e55-c4e4-473f-8a85-dd23d31febdf','\"Sprig Training\"'),
('meta.__names__.d495a9f4-ec12-4552-b53e-346065fabeaa','\"Sprig Training\"'),
('meta.__names__.e7b0d812-496a-462a-b37a-b6ecee3ba260','\"Primary Store\"'),
('meta.__names__.eb6c8b6c-8a32-42a9-9ab0-97414e63933d','\"Image\"'),
('meta.__names__.f92b7543-93bd-4f80-a601-594f6cdfa370','\"Brands\"'),
('plugins.commerce.edition','\"pro\"'),
('plugins.commerce.enabled','true'),
('plugins.commerce.licenseKey','\"W6R0XCZJ5VIQJ99V8UTTA2LQ\"'),
('plugins.commerce.schemaVersion','\"5.0.74\"'),
('plugins.sprig.edition','\"standard\"'),
('plugins.sprig.enabled','true'),
('plugins.sprig.schemaVersion','\"1.0.1\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.defaultPlacement','\"end\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.enableVersioning','true'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.entryTypes.0','\"4990dcf7-9b86-489e-a06a-2bc0c0f2b3d1\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.handle','\"countries\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.maxAuthors','1'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.name','\"Countries\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.propagationMethod','\"all\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.enabledByDefault','true'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.hasUrls','true'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.template','\"locations/_entry\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.uriFormat','\"locations/{slug}\"'),
('sections.8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686.type','\"channel\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.defaultPlacement','\"end\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.enableVersioning','true'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.entryTypes.0','\"b1797aea-7808-418c-a68b-1cb07b2b1c7c\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.handle','\"articles\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.name','\"Articles\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.propagationMethod','\"all\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.enabledByDefault','true'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.hasUrls','true'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.template','\"articles/_entry\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.uriFormat','\"articles/{slug}\"'),
('sections.b9be22a6-6ef5-4a3a-9c8f-163610685d49.type','\"channel\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.defaultPlacement','\"end\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.enableVersioning','true'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.entryTypes.0','\"36cba068-6c7e-426b-9fad-d99775b88e98\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.handle','\"brands\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.maxAuthors','1'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.name','\"Brands\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.previewTargets.0.__assoc__.0.0','\"label\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.previewTargets.0.__assoc__.1.1','\"{url}\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.previewTargets.0.__assoc__.2.0','\"refresh\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.previewTargets.0.__assoc__.2.1','\"1\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.propagationMethod','\"all\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.enabledByDefault','true'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.hasUrls','true'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.template','\"brands/_entry\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.siteSettings.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.uriFormat','\"brands/{slug}\"'),
('sections.f92b7543-93bd-4f80-a601-594f6cdfa370.type','\"channel\"'),
('siteGroups.d495a9f4-ec12-4552-b53e-346065fabeaa.name','\"Sprig Training\"'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.baseUrl','\"$PRIMARY_SITE_URL\"'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.enabled','true'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.handle','\"default\"'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.hasUrls','true'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.language','\"en-US\"'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.name','\"Sprig Training\"'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.primary','true'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.siteGroup','\"d495a9f4-ec12-4552-b53e-346065fabeaa\"'),
('sites.bd3a4e55-c4e4-473f-8a85-dd23d31febdf.sortOrder','1'),
('system.edition','\"pro\"'),
('system.live','true'),
('system.name','\"Sprig Training\"'),
('system.schemaVersion','\"5.0.0.20\"'),
('system.timeZone','\"America/Los_Angeles\"'),
('users.allowPublicRegistration','false'),
('users.defaultGroup','null'),
('users.photoSubpath','null'),
('users.photoVolumeUid','null'),
('users.requireEmailVerification','true'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elementCondition','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.autocapitalize','true'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.autocomplete','false'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.autocorrect','true'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.class','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.disabled','false'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.elementCondition','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.id','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.inputType','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.instructions','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.label','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.max','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.min','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.name','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.orientation','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.placeholder','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.readonly','false'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.requirable','false'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.size','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.step','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.tip','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.title','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.uid','\"2050d249-feab-4399-b97a-8bdc5951c673\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.userCondition','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.warning','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.elements.0.width','100'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.name','\"Content\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.uid','\"a9e0c9ae-8727-4326-92b0-85b1edd57abf\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fieldLayouts.787bc790-e1ed-44a9-9bab-92640ab09ac5.tabs.0.userCondition','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.fs','\"images\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.handle','\"images\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.name','\"Images\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.sortOrder','1'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.titleTranslationKeyFormat','null'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.titleTranslationMethod','\"site\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.transformFs','\"\"'),
('volumes.63787053-c58d-42f3-af9c-632e7dc01f35.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES
(1,2,17,NULL,22,1,'2024-02-18 02:01:45','2024-02-18 02:01:45','3e244921-df7b-4206-acee-396843552a4e'),
(2,2,19,NULL,23,1,'2024-02-18 02:02:11','2024-02-18 02:02:11','be6c8fce-d341-4d38-88fb-bcb401b1cb68'),
(3,2,15,NULL,21,1,'2024-02-18 02:02:18','2024-02-18 02:02:18','772d3dfe-43a9-4829-b361-ad0e23d07053'),
(7,4,39,NULL,40,1,'2024-05-15 07:46:50','2024-05-15 07:46:50','b186eaca-25fa-40bb-bd13-a1bf7aa6fd50'),
(8,4,44,NULL,40,1,'2024-05-15 07:47:03','2024-05-15 07:47:03','29785536-dffa-4a9f-99a7-fc9e7b5b96df'),
(11,5,15,NULL,39,1,'2024-05-15 07:47:08','2024-05-15 07:47:08','376e0e77-657e-407c-82c9-24b0f5439949'),
(14,4,39,NULL,46,2,'2024-05-15 13:26:01','2024-05-15 13:26:01','497992be-8092-485f-a8c4-a46b20b14d34'),
(15,4,49,NULL,40,1,'2024-05-15 13:26:01','2024-05-15 13:26:01','7500150b-e669-4436-9625-d3cc2df39c0d'),
(16,4,49,NULL,46,2,'2024-05-15 13:26:01','2024-05-15 13:26:01','fd9e1627-5a71-4a05-bd13-287018103b3c'),
(17,4,50,NULL,51,1,'2024-05-15 13:26:18','2024-05-15 13:26:18','8e4b871b-d632-41d9-8914-b48c69992452'),
(18,4,53,NULL,51,1,'2024-05-15 13:26:19','2024-05-15 13:26:19','2e4aa82d-1bdc-45e1-89b1-692e6e93e5cc');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES
(1,2,1,1,''),
(2,4,1,1,''),
(3,6,1,1,''),
(4,4,1,2,'Applied “Draft 1”'),
(5,2,1,2,''),
(7,25,1,1,NULL),
(8,27,1,1,NULL),
(9,29,1,1,NULL),
(10,33,1,1,NULL),
(11,40,1,1,''),
(12,40,1,2,''),
(13,39,1,1,''),
(14,46,1,1,''),
(15,39,1,2,'Applied “Draft 1”'),
(16,51,1,1,''),
(17,50,1,1,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES
(1,'email',0,1,' support putyourlightson com '),
(1,'firstname',0,1,''),
(1,'fullname',0,1,''),
(1,'lastname',0,1,''),
(1,'slug',0,1,''),
(1,'username',0,1,' admin '),
(2,'slug',0,1,' introducing blitz diagnostics '),
(2,'title',0,1,' introducing blitz diagnostics '),
(4,'slug',0,1,' queue runners and custom queues in craft cms '),
(4,'title',0,1,' queue runners and custom queues in craft cms '),
(6,'slug',0,1,' htmx has a javascript api btw '),
(6,'title',0,1,' htmx has a javascript api btw '),
(13,'slug',0,1,''),
(14,'addressline1',0,1,''),
(14,'addressline2',0,1,''),
(14,'administrativearea',0,1,''),
(14,'countrycode',0,1,' us '),
(14,'dependentlocality',0,1,''),
(14,'fullname',0,1,''),
(14,'locality',0,1,''),
(14,'organization',0,1,''),
(14,'organizationtaxid',0,1,''),
(14,'postalcode',0,1,''),
(14,'slug',0,1,''),
(14,'sortingcode',0,1,''),
(14,'title',0,1,' store '),
(15,'defaultsku',0,1,' 001 1 '),
(15,'sku',0,1,''),
(15,'slug',0,1,' basic tee '),
(15,'title',0,1,' basic tee '),
(16,'hasunlimitedstock',0,1,''),
(16,'height',0,1,' 0 '),
(16,'length',0,1,' 0 '),
(16,'maxqty',0,1,''),
(16,'minqty',0,1,''),
(16,'price',0,1,' 32 '),
(16,'producttitle',0,1,' basic tee '),
(16,'sku',0,1,' 001 1 '),
(16,'slug',0,1,''),
(16,'stock',0,1,' 100 '),
(16,'title',0,1,' basic tee '),
(16,'weight',0,1,' 0 '),
(16,'width',0,1,' 0 '),
(17,'defaultsku',0,1,' 002 '),
(17,'sku',0,1,''),
(17,'slug',0,1,' daily journal '),
(17,'title',0,1,' daily journal '),
(18,'hasunlimitedstock',0,1,''),
(18,'height',0,1,' 0 '),
(18,'length',0,1,' 0 '),
(18,'maxqty',0,1,''),
(18,'minqty',0,1,''),
(18,'price',0,1,' 50 '),
(18,'producttitle',0,1,' daily journal '),
(18,'sku',0,1,' 002 '),
(18,'slug',0,1,''),
(18,'stock',0,1,' 0 '),
(18,'title',0,1,' daily journal '),
(18,'weight',0,1,' 0 '),
(18,'width',0,1,' 0 '),
(19,'defaultsku',0,1,' 003 '),
(19,'sku',0,1,''),
(19,'slug',0,1,' nomad tumbler '),
(19,'title',0,1,' nomad tumbler '),
(20,'hasunlimitedstock',0,1,''),
(20,'height',0,1,' 0 '),
(20,'length',0,1,' 0 '),
(20,'maxqty',0,1,''),
(20,'minqty',0,1,''),
(20,'price',0,1,' 35 '),
(20,'producttitle',0,1,' nomad tumbler '),
(20,'sku',0,1,' 003 '),
(20,'slug',0,1,''),
(20,'stock',0,1,' 50 '),
(20,'title',0,1,' nomad tumbler '),
(20,'weight',0,1,' 0 '),
(20,'width',0,1,' 0 '),
(21,'alt',0,1,''),
(21,'extension',0,1,' jpg '),
(21,'filename',0,1,' shopping cart page 01 product 01 jpg '),
(21,'kind',0,1,' image '),
(21,'slug',0,1,''),
(21,'title',0,1,' shopping cart page 01 product 01 '),
(22,'alt',0,1,''),
(22,'extension',0,1,' jpg '),
(22,'filename',0,1,' shopping cart page 01 product 02 jpg '),
(22,'kind',0,1,' image '),
(22,'slug',0,1,''),
(22,'title',0,1,' shopping cart page 01 product 02 '),
(23,'alt',0,1,''),
(23,'extension',0,1,' jpg '),
(23,'filename',0,1,' shopping cart page 01 product 03 jpg '),
(23,'kind',0,1,' image '),
(23,'slug',0,1,''),
(23,'title',0,1,' shopping cart page 01 product 03 '),
(24,'billingfirstname',0,1,''),
(24,'billingfullname',0,1,''),
(24,'billinglastname',0,1,''),
(24,'customername',0,1,''),
(24,'email',0,1,' support putyourlightson com '),
(24,'lineitemdescriptions',0,1,' basic tee basic tee nomad tumbler nomad tumbler '),
(24,'number',0,1,' 2ad073f27e61ec9415dd089d229b3eab '),
(24,'reference',0,1,''),
(24,'shippingfirstname',0,1,''),
(24,'shippingfullname',0,1,''),
(24,'shippinglastname',0,1,''),
(24,'shortnumber',0,1,' 2ad073f '),
(24,'skus',0,1,' 001 003 '),
(24,'slug',0,1,''),
(24,'transactionreference',0,1,''),
(24,'username',0,1,' admin '),
(25,'slug',0,1,' sd '),
(25,'title',0,1,' sd '),
(27,'slug',0,1,' sd 2 '),
(27,'title',0,1,' sd '),
(29,'slug',0,1,' www '),
(29,'title',0,1,' www '),
(31,'hasunlimitedstock',0,1,''),
(31,'height',0,1,' 0 '),
(31,'length',0,1,' 0 '),
(31,'maxqty',0,1,''),
(31,'minqty',0,1,''),
(31,'price',0,1,' 35 '),
(31,'producttitle',0,1,' basic tee '),
(31,'sku',0,1,' 001 2 '),
(31,'slug',0,1,''),
(31,'stock',0,1,' 100 '),
(31,'title',0,1,' basic tee '),
(31,'weight',0,1,' 0 '),
(31,'width',0,1,' 0 '),
(32,'slug',0,1,' temp yssakckqgqgfmndqnvbziqqpzsqroysjekwn '),
(32,'title',0,1,''),
(33,'slug',0,1,' hola '),
(33,'title',0,1,' hola '),
(35,'billingfirstname',0,1,''),
(35,'billingfullname',0,1,''),
(35,'billinglastname',0,1,''),
(35,'customername',0,1,''),
(35,'email',0,1,' support putyourlightson com '),
(35,'lineitemdescriptions',0,1,' nomad tumbler nomad tumbler '),
(35,'number',0,1,' 188d68f4059df6d83747de07503873f5 '),
(35,'reference',0,1,''),
(35,'shippingfirstname',0,1,''),
(35,'shippingfullname',0,1,''),
(35,'shippinglastname',0,1,''),
(35,'shortnumber',0,1,' 188d68f '),
(35,'skus',0,1,' 003 '),
(35,'slug',0,1,''),
(35,'transactionreference',0,1,''),
(35,'username',0,1,' admin '),
(39,'slug',0,1,' no name '),
(39,'title',0,1,' no name '),
(40,'slug',0,1,' paris france '),
(40,'title',0,1,' france '),
(43,'slug',0,1,' paris france '),
(43,'title',0,1,' france '),
(46,'slug',0,1,' poland '),
(46,'title',0,1,' poland '),
(50,'slug',0,1,' fashionista '),
(50,'title',0,1,' fashionista '),
(51,'slug',0,1,' italy '),
(51,'title',0,1,' italy ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES
(1,NULL,'Articles','articles','channel',1,1,'all','end',NULL,'2024-01-12 00:59:58','2024-01-12 00:59:58',NULL,'b9be22a6-6ef5-4a3a-9c8f-163610685d49'),
(2,NULL,'Brands','brands','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-05-15 07:44:38','2024-05-15 07:44:38',NULL,'f92b7543-93bd-4f80-a601-594f6cdfa370'),
(3,NULL,'Countries','countries','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-05-15 07:44:50','2024-05-15 07:47:41',NULL,'8afd4ad2-0e16-4ff9-8b3e-95a64f2ec686');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES
(1,1,1),
(2,2,1),
(3,3,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES
(1,1,1,1,'articles/{slug}','articles/_entry',1,'2024-01-12 00:59:58','2024-01-12 00:59:58','ec2085a1-a1b5-479a-84de-816b8a9a36fa'),
(2,2,1,1,'brands/{slug}','brands/_entry',1,'2024-05-15 07:44:38','2024-05-15 07:44:38','eed77914-1776-46a1-86de-27569d40ba5d'),
(3,3,1,1,'locations/{slug}','locations/_entry',1,'2024-05-15 07:44:50','2024-05-15 07:44:50','8443088e-de3f-406b-b7d5-c5214ad9bcb7');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES
(1,'Sprig Training','2024-01-12 00:57:57','2024-01-12 00:57:57',NULL,'d495a9f4-ec12-4552-b53e-346065fabeaa');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES
(1,1,1,'true','Sprig Training','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-01-12 00:57:57','2024-01-12 00:57:57',NULL,'bd3a4e55-c4e4-473f-8a85-dd23d31febdf');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sprig_playgrounds`
--

LOCK TABLES `sprig_playgrounds` WRITE;
/*!40000 ALTER TABLE `sprig_playgrounds` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sprig_playgrounds` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tokens` VALUES
(1,'j24qBqlmWNlFf1IAs2ugu8UkNXA7Ofwx','[\"users\\/impersonate-with-token\",{\"userId\":1,\"prevUserId\":1}]',1,0,'2024-01-13 03:19:15','2024-01-13 02:19:15','2024-01-13 02:19:15','411d8c2e-0e78-4a20-a161-5c7b2756ddd1');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES
(1,'{\"locale\": null, \"language\": \"en-US\", \"useShapes\": false, \"weekStartDay\": \"1\", \"underlineLinks\": false, \"disableAutofocus\": \"\", \"profileTemplates\": false, \"showFieldHandles\": true, \"showExceptionView\": false, \"alwaysShowFocusRings\": false, \"notificationDuration\": \"5000\", \"enableDebugToolbarForCp\": false, \"enableDebugToolbarForSite\": false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,NULL,1,0,0,0,1,'admin','',NULL,NULL,'support@putyourlightson.com','$2y$13$gTbXD6wjQmQlxZJehpOd5elnjP0Fj35pcuBsk3xkgvc8bFHDYEhGy','2024-05-15 07:38:42',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-01-12 00:57:57','2024-01-12 00:57:57','2024-05-15 07:38:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES
(1,NULL,1,'Images','','2024-02-18 02:00:28','2024-02-18 02:00:28','ebef95c2-8749-4ec4-a022-9c1af0288c92'),
(2,NULL,NULL,'Temporary filesystem',NULL,'2024-02-18 02:01:14','2024-02-18 02:01:14','e4d7300a-797f-4d70-acd7-9d97472ba8f7'),
(3,2,NULL,'user_1','user_1/','2024-02-18 02:01:14','2024-02-18 02:01:14','75ee06dd-6860-48fe-a965-1ba09a844158');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES
(1,5,'Images','images','images',NULL,'','','site',NULL,'site',NULL,1,'2024-02-18 02:00:28','2024-02-18 02:00:28',NULL,'63787053-c58d-42f3-af9c-632e7dc01f35');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES
(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-01-12 00:58:26','2024-01-12 00:58:26','e9eefafc-149a-417e-b17e-ac320ec9c7bb'),
(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-01-12 00:58:26','2024-01-12 00:58:26','68c82d07-75c5-46ec-8003-b934e2fa0cb2'),
(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-01-12 00:58:26','2024-01-12 00:58:26','9e3eea48-6b59-4677-b20f-f68c5a53e17e'),
(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-01-12 00:58:26','2024-01-12 00:58:26','0a56c91a-f636-43eb-9679-a7d699fd17dc');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-15 17:25:03
